# Déploiement d'EDT-Pro sur un VPS Ubuntu

Guide pas à pas pour déployer l'application complète (API + PostgreSQL +
Redis + worker + frontend web) sur un VPS Ubuntu avec un nom de domaine,
en HTTPS via Let's Encrypt.

**Architecture cible :**
```
                         ┌─────────────────────────┐
Internet ── HTTPS:443 ──▶│   Nginx (reverse proxy)  │
                         └───────────┬──────────────┘
                    app.mondomaine.fr│api.mondomaine.fr
                    (frontend statique)│(proxy → Docker :8000)
                                      ▼
                         ┌─────────────────────────┐
                         │  Docker Compose          │
                         │  ├─ api (FastAPI)        │
                         │  ├─ worker (RQ)          │
                         │  ├─ db (PostgreSQL)       │
                         │  └─ redis                  │
                         └─────────────────────────┘
```

Deux sous-domaines sont utilisés : un pour l'interface web statique
(`app.mondomaine.fr`) et un pour l'API (`api.mondomaine.fr`) — plus
simple à sécuriser et à faire évoluer qu'un chemin unique.

---

## 0. Prérequis

- Un VPS Ubuntu 22.04/24.04 avec accès root (ou sudo) en SSH.
- Un nom de domaine dont vous contrôlez la zone DNS.
- Environ 30-45 minutes.

---

## 1. Configurer le DNS

Chez votre registrar/hébergeur DNS, créez deux enregistrements **A**
pointant vers l'adresse IP de votre VPS :

| Type | Nom | Valeur |
|---|---|---|
| A | `app.mondomaine.fr` | `IP_DE_VOTRE_VPS` |
| A | `api.mondomaine.fr` | `IP_DE_VOTRE_VPS` |

Vérifiez la propagation avant de continuer :
```bash
dig +short app.mondomaine.fr
dig +short api.mondomaine.fr
```

---

## 2. Préparation initiale du serveur

Connectez-vous en SSH, puis :

```bash
# Mise à jour du système
sudo apt update && sudo apt upgrade -y

# Créer un utilisateur non-root dédié (si vous êtes en root)
adduser edtpro
usermod -aG sudo edtpro
su - edtpro

# Pare-feu : n'ouvrir que SSH, HTTP et HTTPS
sudo apt install -y ufw
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status
```

⚠️ Les ports de PostgreSQL (5432) et Redis (6379) ne doivent **jamais**
être exposés publiquement — ils resteront internes à Docker (voir
section 5).

---

## 3. Installer Docker et Docker Compose

```bash
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER
newgrp docker   # applique le groupe sans se reconnecter

docker --version
docker compose version
```

---

## 4. Déployer le code

```bash
sudo apt install -y git unzip
mkdir -p ~/apps && cd ~/apps

# Option A — via git (si vous avez poussé le projet sur un dépôt)
git clone <url-de-votre-depot> edt-pro

# Option B — via upload direct du zip (scp depuis votre machine)
# scp edt-pro.zip edtpro@IP_DU_VPS:~/apps/
# unzip edt-pro.zip

cd ~/apps/edt-pro
```

---

## 5. Configurer les secrets de production

Créez un fichier `.env` à la racine du projet (**ne jamais** le
committer dans git) :

```bash
cat > .env <<'EOF'
JWT_SECRET_KEY=REMPLACEZ_PAR_UNE_VALEUR_ALEATOIRE
POSTGRES_PASSWORD=REMPLACEZ_PAR_UN_MOT_DE_PASSE_FORT
ALLOWED_ORIGINS=https://app.mondomaine.fr
EOF

# Génère une clé JWT aléatoire forte et l'insère automatiquement
sed -i "s#REMPLACEZ_PAR_UNE_VALEUR_ALEATOIRE#$(openssl rand -hex 32)#" .env
sed -i "s#REMPLACEZ_PAR_UN_MOT_DE_PASSE_FORT#$(openssl rand -hex 16)#" .env

cat .env   # vérifiez le résultat
```

Adaptez ensuite `docker-compose.yml` pour :
1. utiliser `${POSTGRES_PASSWORD}` au lieu du mot de passe en dur,
2. **ne plus publier** les ports de `db` et `redis` sur l'hôte (retirez
   les blocs `ports:` de ces deux services — seul `api` doit rester
   accessible, et uniquement en local, voir étape 6),
3. transmettre `ALLOWED_ORIGINS` au service `api`.

```yaml
services:
  db:
    # ports: ...        <-- à supprimer
    environment:
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      # ...

  redis:
    # ports: ...        <-- à supprimer

  api:
    environment:
      DATABASE_URL: postgresql+psycopg2://edt_user:${POSTGRES_PASSWORD}@db:5432/edt_pro
      ALLOWED_ORIGINS: ${ALLOWED_ORIGINS}
      # ...
    ports:
      - "127.0.0.1:8000:8000"   # n'écoute que localement, Nginx fait le proxy
```

---

## 6. Lancer la stack

```bash
docker compose up -d --build
docker compose ps          # les 4 services doivent être "healthy"/"running"
docker compose exec api python -m app.seed   # données + comptes de démonstration
```

Vérifiez que l'API répond en local :
```bash
curl http://127.0.0.1:8000/
# {"status":"ok","service":"EDT-Pro API","version":"3.0.0",...}
```

---

## 7. Installer et configurer Nginx

```bash
sudo apt install -y nginx
```

Créez `/etc/nginx/sites-available/edt-pro` :

```nginx
# --- API (proxy vers le conteneur Docker) ---
server {
    listen 80;
    server_name api.mondomaine.fr;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Nécessaire pour les exports volumineux et la génération longue
        proxy_read_timeout 300s;
        client_max_body_size 20M;
    }
}

# --- Frontend (fichiers statiques) ---
server {
    listen 80;
    server_name app.mondomaine.fr;
    root /home/edtpro/apps/edt-pro/frontend;
    index index.html;

    location / {
        try_files $uri $uri/ =404;
    }
}
```

Activez le site puis testez :

```bash
sudo ln -s /etc/nginx/sites-available/edt-pro /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
```

À ce stade, `http://api.mondomaine.fr` et `http://app.mondomaine.fr`
doivent déjà répondre (sans HTTPS).

---

## 8. Activer HTTPS (Let's Encrypt / Certbot)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d app.mondomaine.fr -d api.mondomaine.fr
```

Certbot modifie automatiquement la config Nginx pour rediriger le HTTP
vers le HTTPS et configure le renouvellement automatique (vérifiable
avec `sudo certbot renew --dry-run`).

---

## 9. Pointer le frontend vers l'API en production

Éditez `frontend/config.js` sur le serveur :

```bash
cat > ~/apps/edt-pro/frontend/config.js <<'EOF'
window.EDT_API_BASE_URL = "https://api.mondomaine.fr";
EOF
```

Aucun rebuild nécessaire (fichier statique servi directement par
Nginx). Rendez-vous sur `https://app.mondomaine.fr` : l'interface doit
se charger et interroger l'API en HTTPS.

---

## 10. Version mobile et desktop en production

- **Mobile** (`mobile/config.js`) : remplacez
  `API_BASE_URL = "http://localhost:8000"` par
  `"https://api.mondomaine.fr"`, puis publiez via
  `eas build` (Expo Application Services) pour générer les binaires
  iOS/Android — hors du périmètre de ce guide serveur.
- **Desktop** : chaque poste continue de fonctionner en local (base
  SQLite embarquée) ; si vous voulez qu'il utilise l'API centrale au
  lieu du mode 100% local, adaptez `desktop/app.py` pour pointer vers
  `https://api.mondomaine.fr` plutôt que de lancer l'API en local.

---

## 11. Vérifications post-déploiement

```bash
# Génération asynchrone opérationnelle (worker + Redis)
docker compose logs worker --tail 20

# Sauvegardes automatiques bien planifiées
docker compose logs api | grep "Planificateur"

# Accès HTTPS
curl -I https://api.mondomaine.fr/
curl -I https://app.mondomaine.fr/
```

Connectez-vous ensuite sur `https://app.mondomaine.fr` avec un compte
de démonstration et lancez une génération pour valider le parcours
complet de bout en bout.

**⚠️ Sécurité avant mise en service réelle** :
- Changez immédiatement les mots de passe des comptes de démonstration
  (ou supprimez-les et créez vos propres comptes via `/users`).
- `ALLOWED_ORIGINS` doit lister uniquement `https://app.mondomaine.fr`
  (pas `*`) — déjà fait à l'étape 5 si vous avez suivi le guide.
- Limitez l'accès SSH par clé uniquement (`PasswordAuthentication no`
  dans `/etc/ssh/sshd_config`).

---

## 12. Maintenance courante

**Mettre à jour l'application** (après un `git pull` ou un nouvel
upload) :
```bash
cd ~/apps/edt-pro
docker compose up -d --build
```

**Consulter les logs** :
```bash
docker compose logs -f api
docker compose logs -f worker
```

**Absorber une charge plus importante** (établissement de grande
taille) :
```bash
docker compose up -d --scale worker=3
```

**Sauvegardes** : générées automatiquement chaque nuit dans le volume
Docker `edt_backups` (voir `app/scheduler.py`). Pensez à les copier
régulièrement hors du VPS (ex: `rsync`/`rclone` vers un stockage
distant) — un VPS perdu = les sauvegardes locales perdues avec lui :
```bash
docker compose cp api:/app/backups ./backups-locales
rsync -avz ./backups-locales/ utilisateur@autre-serveur:/chemin/de/sauvegarde/
```

**Redémarrage après reboot du VPS** : `restart: unless-stopped` est déjà
configuré dans `docker-compose.yml`, les conteneurs redémarrent
automatiquement. Vérifiez simplement que le service Docker démarre au
boot :
```bash
sudo systemctl enable docker
```

---

## Alternative plus simple : Caddy au lieu de Nginx + Certbot

Si vous préférez éviter la configuration manuelle de Certbot, **Caddy**
gère le HTTPS automatiquement (renouvellement inclus, zéro config) :

```bash
sudo apt install -y caddy
```

`/etc/caddy/Caddyfile` :
```
api.mondomaine.fr {
    reverse_proxy 127.0.0.1:8000
}

app.mondomaine.fr {
    root * /home/edtpro/apps/edt-pro/frontend
    file_server
}
```

```bash
sudo systemctl reload caddy
```

C'est tout — Caddy obtient et renouvelle automatiquement les
certificats Let's Encrypt dès que le DNS pointe correctement vers le
serveur.
