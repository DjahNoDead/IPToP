"""
Configuration de la connexion à la base de données.

Par défaut, utilise SQLite (fichier local edt_pro.db) pour un démarrage
sans configuration. Pour PostgreSQL en production, définir la variable
d'environnement DATABASE_URL, par exemple :

    postgresql+psycopg2://user:password@localhost:5432/edt_pro
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./edt_pro.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}

engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Dépendance FastAPI fournissant une session de base de données."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
