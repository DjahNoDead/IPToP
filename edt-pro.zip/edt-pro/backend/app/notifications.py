"""
Envoi de notifications push vers l'application mobile via le service
Expo Push Notifications (https://exp.host/--/api/v2/push/send), utilisé
par les apps Expo/React Native sans nécessiter de compte Firebase/APNs
séparé.

Déclenché automatiquement lors d'un changement de créneau affectant un
ou plusieurs enseignants (création, modification, suppression, échange
de séance, régénération complète) — voir les appels à
`notifier_enseignants` dans app/main.py.

Ne lève jamais d'exception bloquante : l'échec d'envoi d'une
notification (Expo indisponible, token invalide/expiré, absence de
connexion) ne doit jamais faire échouer l'opération métier associée.
"""
import logging
from typing import Iterable, List, Optional

import requests
from sqlalchemy.orm import Session

from . import models

EXPO_PUSH_URL = "https://exp.host/--/api/v2/push/send"
logger = logging.getLogger("edt_pro.notifications")


def label_creneau(creneau: Optional[models.CreneauHoraire]) -> str:
    """Libellé court d'un créneau pour le corps d'une notification,
    ex: 'Lundi 08:00'."""
    if not creneau:
        return ""
    return f"{creneau.jour} {creneau.heure_debut}"


def _utilisateurs_pour_enseignants(db: Session, enseignant_ids: Iterable[int]) -> List[models.Utilisateur]:
    enseignant_ids = [e for e in set(enseignant_ids) if e is not None]
    if not enseignant_ids:
        return []
    return db.query(models.Utilisateur).filter(
        models.Utilisateur.enseignant_id.in_(enseignant_ids)
    ).all()


def notifier_enseignants(db: Session, enseignant_ids: Iterable[int], titre: str, corps: str,
                          data: Optional[dict] = None) -> None:
    """Envoie une notification push à tous les enseignants de la liste
    (uniquement ceux ayant enregistré au moins un appareil mobile via
    POST /notifications/register-token).

    Le compteur `badge_count` de chaque utilisateur concerné est
    incrémenté en base et transmis dans le payload push (champ `badge`) :
    c'est ce mécanisme — et non un comptage local côté app — qui permet à
    l'icône d'afficher le bon nombre même si l'application était fermée
    au moment de la notification (comportement standard iOS/Android).
    Remis à zéro via POST /notifications/reset-badge.

    Échoue silencieusement (journalisé en warning) en l'absence de
    connectivité vers le service Expo — ne doit jamais bloquer l'opération
    métier associée (création/modification/suppression de séance)."""
    utilisateurs = _utilisateurs_pour_enseignants(db, enseignant_ids)
    if not utilisateurs:
        return

    messages = []
    for user in utilisateurs:
        tokens = db.query(models.PushToken).filter(models.PushToken.utilisateur_id == user.id).all()
        if not tokens:
            continue
        user.badge_count = (user.badge_count or 0) + 1
        for t in tokens:
            messages.append({
                "to": t.token, "sound": "default", "title": titre, "body": corps,
                "data": data or {}, "badge": user.badge_count,
            })
    db.commit()

    if not messages:
        return

    try:
        res = requests.post(
            EXPO_PUSH_URL, json=messages, timeout=5,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        if res.status_code >= 400:
            logger.warning(f"Réponse Expo Push inattendue ({res.status_code}) : {res.text[:200]}")
    except requests.RequestException as e:
        # Le mode hors-ligne / une panne du service Expo ne doit jamais
        # faire échouer la mutation de l'emploi du temps elle-même.
        logger.warning(f"Échec d'envoi de notification push : {e}")
