"""
Catalogue des permissions granulaires (table `permissions`) et
affectation par défaut aux rôles (table `role_permissions`).

Ce catalogue remplace le contrôle d'accès "par rôle en dur" par un
système à la carte : un administrateur peut, via
POST /roles/{role_id}/permissions, retirer ou ajouter des permissions à
un rôle (ou créer un nouveau rôle personnalisé, ex. "coordonnateur de
niveau") sans toucher au code de l'application.
"""

PERMISSIONS_CATALOG = [
    # code                          libelle
    ("referentiels.manage",   "Gérer classes, matières, salles, volumes horaires, créneaux"),
    ("disponibilites.manage_own", "Déclarer ses propres disponibilités"),
    ("disponibilites.manage_all", "Gérer les disponibilités de tous les enseignants"),
    ("schedule.generate",     "Lancer la génération automatique de l'emploi du temps"),
    ("schedule.edit",         "Modifier manuellement l'emploi du temps"),
    ("schedule.view",         "Consulter les emplois du temps"),
    ("dashboard.view",        "Consulter le tableau de bord et les statistiques"),
    ("exports.use",           "Exporter les emplois du temps (PDF/Excel)"),
    ("journal.view",          "Consulter le journal d'activité"),
    ("users.manage",          "Gérer les comptes utilisateurs"),
    ("roles.manage",          "Gérer les rôles et permissions"),
    ("backup.manage",         "Effectuer des sauvegardes et restaurations"),
]

# Rôles standards créés automatiquement (globaux, partagés entre tous les
# établissements) — utilisé par app/seed.py et par l'onboarding d'un
# nouvel établissement (POST /etablissements/onboard) pour garantir que
# ces rôles existent avant d'y rattacher un utilisateur.
ROLES_STANDARDS = [
    ("admin", "Administrateur système"),
    ("proviseur", "Chef d'établissement"),
    ("censeur", "Censeur / Surveillant général"),
    ("secretaire", "Secrétaire / Gestionnaire scolarité"),
    ("enseignant", "Enseignant"),
]


def garantir_catalogue_global(db):
    """Crée le catalogue de permissions et les rôles standards s'ils
    n'existent pas encore (idempotent) — appelé au premier onboarding
    d'établissement ou par app/seed.py. Ces objets sont globaux : ils ne
    sont créés qu'une seule fois pour toute la plateforme, pas par
    établissement."""
    from . import models

    if db.query(models.Permission).count() == 0:
        for code, libelle in PERMISSIONS_CATALOG:
            db.add(models.Permission(code=code, libelle=libelle))
        db.commit()

    permissions_par_code = {p.code: p for p in db.query(models.Permission).all()}

    for libelle, description in ROLES_STANDARDS:
        role = db.query(models.Role).filter(models.Role.libelle == libelle).first()
        if not role:
            role = models.Role(libelle=libelle, description=description)
            role.permissions = [
                permissions_par_code[code] for code in DEFAULT_ROLE_PERMISSIONS.get(libelle, [])
                if code in permissions_par_code
            ]
            db.add(role)
    db.commit()
