"""
EDT-Pro — API REST principale.

Lancement (développement) :
    uvicorn app.main:app --reload --port 8000

Pour la génération asynchrone, lancez également un worker dans un
processus séparé :
    python -m app.worker

Documentation interactive auto-générée : http://localhost:8000/docs

Sécurité & cloisonnement multi-établissements :
- Tous les endpoints de mutation sont protégés par JWT + permissions
  granulaires (app/auth.py::require_permission, app/permissions_catalog.py).
- **Tous** les endpoints de lecture exigent désormais une authentification
  (Depends(get_current_user)) — les référentiels et emplois du temps
  n'ont jamais été publics, mais le devenir explicitement nécessaire
  avec le multi-tenant : c'est l'utilisateur connecté qui détermine
  l'établissement dont les données sont renvoyées.
- Aucun endpoint n'accepte `etablissement_id` en entrée : il est
  systématiquement dérivé de `current_user.etablissement_id`, jamais
  fourni par le client (empêche toute tentative d'accès croisé entre
  établissements).
- Les accès par identifiant (GET/PUT/DELETE .../{id}) vérifient que
  l'objet appartient bien à l'établissement de l'utilisateur avant de le
  renvoyer ou de le modifier — 404 (jamais 403, pour ne pas confirmer
  l'existence d'une ressource d'un autre établissement) en cas d'écart.
"""
import os
import shutil
from typing import List, Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
import io

from . import models, schemas, conflicts, exports as exports_module, backup as backup_module, notifications
from .database import engine, get_db, Base
from .engine import generate_schedule
from .permissions_catalog import garantir_catalogue_global
from .auth import (
    hash_password, verify_password, create_access_token, create_refresh_token,
    decode_token, get_current_user, require_permission, log_activity,
)
from .queue_config import get_queue, is_redis_available, fetch_job
from .tasks import run_generation_task
from .scheduler import start_scheduler, stop_scheduler

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="EDT-Pro API",
    description="API de gestion et de génération automatique des emplois du temps d'un lycée (multi-établissements).",
    version="4.0.0",
)

_allowed_origins = os.getenv("ALLOWED_ORIGINS", "*")
ALLOWED_ORIGINS = ["*"] if _allowed_origins == "*" else [o.strip() for o in _allowed_origins.split(",")]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    start_scheduler()


@app.on_event("shutdown")
def on_shutdown():
    stop_scheduler()


# ===========================================================================
# HELPERS — cloisonnement multi-établissements & pagination
# ===========================================================================
def get_owned_or_404(db: Session, model, obj_id: int, etablissement_id: int, label: str = "Ressource"):
    """Récupère un objet par id en vérifiant qu'il appartient bien à
    l'établissement donné. Renvoie 404 (jamais 403) s'il appartient à un
    autre établissement, pour ne jamais confirmer son existence."""
    obj = db.query(model).filter(
        model.id == obj_id, model.etablissement_id == etablissement_id
    ).first()
    if not obj:
        raise HTTPException(404, f"{label} introuvable")
    return obj


def paginate(response: Response, query, skip: int = 0, limit: int = 200):
    """Applique une pagination cohérente à une requête de liste et expose
    le total via l'en-tête `X-Total-Count` (le corps de la réponse reste
    un tableau simple, pour ne pas casser les clients existants qui
    attendent un tableau plutôt qu'un objet {items, total})."""
    limit = min(limit, 1000)
    total = query.count()
    response.headers["X-Total-Count"] = str(total)
    return query.offset(skip).limit(limit).all()


# ===========================================================================
# ONBOARDING D'UN ÉTABLISSEMENT (endpoint public — équivalent d'une inscription)
# ===========================================================================
@app.post("/etablissements/onboard", response_model=schemas.UserOut, tags=["Établissements"])
def onboarder_etablissement(data: schemas.OnboardingIn, db: Session = Depends(get_db)):
    """Crée un nouvel établissement et son premier compte administrateur,
    en une seule opération (endpoint public, sans authentification —
    équivalent d'une inscription). Les comptes suivants se créent ensuite
    via POST /users, réservé aux administrateurs de CET établissement.

    Garantit au passage l'existence du catalogue de permissions et des 5
    rôles standards (globaux, partagés entre tous les établissements) —
    idempotent, ne les recrée pas s'ils existent déjà."""
    if db.query(models.Etablissement).filter(models.Etablissement.code == data.etablissement_code).first():
        raise HTTPException(400, "Ce code d'établissement est déjà utilisé")
    if db.query(models.Utilisateur).filter(models.Utilisateur.email == data.admin_email).first():
        raise HTTPException(400, "Cet email est déjà utilisé")

    garantir_catalogue_global(db)

    etablissement = models.Etablissement(nom=data.etablissement_nom, code=data.etablissement_code)
    db.add(etablissement)
    db.commit()
    db.refresh(etablissement)

    role_admin = db.query(models.Role).filter(models.Role.libelle == "admin").first()
    user = models.Utilisateur(
        etablissement_id=etablissement.id, email=data.admin_email,
        mot_de_passe_hash=hash_password(data.admin_mot_de_passe),
        nom=data.admin_nom, prenom=data.admin_prenom, role_id=role_admin.id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@app.get("/etablissements/me", response_model=schemas.EtablissementOut, tags=["Établissements"])
def mon_etablissement(current_user: models.Utilisateur = Depends(get_current_user),
                       db: Session = Depends(get_db)):
    return db.query(models.Etablissement).get(current_user.etablissement_id)


# ===========================================================================
# AUTHENTIFICATION
# ===========================================================================
@app.post("/auth/login", response_model=schemas.TokenOut, tags=["Authentification"])
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.Utilisateur).filter(models.Utilisateur.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.mot_de_passe_hash):
        raise HTTPException(401, "Email ou mot de passe incorrect")
    if user.statut != "actif":
        raise HTTPException(403, "Compte suspendu")
    log_activity(db, user, "LOGIN", "Utilisateur", user.id)
    return schemas.TokenOut(
        access_token=create_access_token(user),
        refresh_token=create_refresh_token(user),
    )


@app.post("/auth/refresh", response_model=schemas.TokenOut, tags=["Authentification"])
def refresh_token(data: schemas.RefreshIn, db: Session = Depends(get_db)):
    payload = decode_token(data.refresh_token, expected_type="refresh")
    user = db.query(models.Utilisateur).get(int(payload["sub"]))
    if not user or user.statut != "actif":
        raise HTTPException(401, "Utilisateur invalide")
    return schemas.TokenOut(
        access_token=create_access_token(user),
        refresh_token=create_refresh_token(user),
    )


@app.get("/auth/me", response_model=schemas.UserOut, tags=["Authentification"])
def me(current_user: models.Utilisateur = Depends(get_current_user)):
    return current_user


@app.post("/notifications/register-token", tags=["Notifications"])
def enregistrer_token_push(data: schemas.PushTokenRegister, db: Session = Depends(get_db),
                            current_user: models.Utilisateur = Depends(get_current_user)):
    """Enregistre (ou réattribue) un token de notification push Expo pour
    l'utilisateur connecté. Appelé par l'app mobile au démarrage et après
    chaque connexion."""
    existing = db.query(models.PushToken).filter(models.PushToken.token == data.token).first()
    if existing:
        existing.utilisateur_id = current_user.id
        existing.plateforme = data.plateforme
    else:
        db.add(models.PushToken(
            utilisateur_id=current_user.id, token=data.token, plateforme=data.plateforme,
        ))
    db.commit()
    return {"ok": True}


@app.delete("/notifications/unregister-token", tags=["Notifications"])
def desenregistrer_token_push(token: str, db: Session = Depends(get_db),
                               current_user: models.Utilisateur = Depends(get_current_user)):
    """Supprime un token (déconnexion de l'app mobile, pour ne plus
    recevoir de notifications sur cet appareil)."""
    db.query(models.PushToken).filter(
        models.PushToken.token == token, models.PushToken.utilisateur_id == current_user.id,
    ).delete()
    db.commit()
    return {"ok": True}


@app.post("/notifications/reset-badge", tags=["Notifications"])
def reinitialiser_badge(db: Session = Depends(get_db),
                         current_user: models.Utilisateur = Depends(get_current_user)):
    """Remet à zéro le compteur de badge de l'utilisateur connecté."""
    current_user.badge_count = 0
    db.commit()
    return {"ok": True, "badge_count": 0}


# ===========================================================================
# UTILISATEURS (réservé : permission users.manage, scopé à l'établissement)
# ===========================================================================
@app.post("/users", response_model=schemas.UserOut, tags=["Utilisateurs"],
          dependencies=[Depends(require_permission("users.manage"))])
def creer_utilisateur(data: schemas.UserCreate, db: Session = Depends(get_db),
                       current_user: models.Utilisateur = Depends(get_current_user)):
    role = db.query(models.Role).filter(models.Role.libelle == data.role).first()
    if not role:
        raise HTTPException(400, f"Rôle inconnu : {data.role}")
    if db.query(models.Utilisateur).filter(models.Utilisateur.email == data.email).first():
        raise HTTPException(400, "Cet email est déjà utilisé")
    if data.enseignant_id:
        get_owned_or_404(db, models.Enseignant, data.enseignant_id, current_user.etablissement_id, "Enseignant")
    user = models.Utilisateur(
        etablissement_id=current_user.etablissement_id,
        email=data.email, mot_de_passe_hash=hash_password(data.mot_de_passe),
        nom=data.nom, prenom=data.prenom, role_id=role.id, enseignant_id=data.enseignant_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    log_activity(db, current_user, "CREATE", "Utilisateur", user.id, f"Création du compte {user.email}")
    return user


@app.get("/users", response_model=List[schemas.UserOut], tags=["Utilisateurs"],
         dependencies=[Depends(require_permission("users.manage"))])
def lister_utilisateurs(response: Response, skip: int = 0, limit: int = 200,
                         db: Session = Depends(get_db),
                         current_user: models.Utilisateur = Depends(get_current_user)):
    q = db.query(models.Utilisateur).filter(models.Utilisateur.etablissement_id == current_user.etablissement_id)
    return paginate(response, q, skip, limit)


@app.delete("/users/{user_id}", tags=["Utilisateurs"],
            dependencies=[Depends(require_permission("users.manage"))])
def supprimer_utilisateur(user_id: int, db: Session = Depends(get_db),
                           current_user: models.Utilisateur = Depends(get_current_user)):
    user = get_owned_or_404(db, models.Utilisateur, user_id, current_user.etablissement_id, "Utilisateur")
    user.statut = "suspendu"
    db.commit()
    log_activity(db, current_user, "SUSPEND", "Utilisateur", user_id)
    return {"ok": True}


# ===========================================================================
# RÔLES & PERMISSIONS GRANULAIRES
# (globaux — partagés entre établissements, voir models.py pour le choix)
# ===========================================================================
@app.get("/permissions", response_model=List[schemas.PermissionOut], tags=["Rôles & permissions"],
         dependencies=[Depends(require_permission("roles.manage"))])
def lister_permissions(db: Session = Depends(get_db)):
    return db.query(models.Permission).all()


@app.get("/roles", response_model=List[schemas.RoleDetailOut], tags=["Rôles & permissions"],
         dependencies=[Depends(require_permission("roles.manage"))])
def lister_roles(db: Session = Depends(get_db)):
    return db.query(models.Role).all()


@app.post("/roles", response_model=schemas.RoleDetailOut, tags=["Rôles & permissions"],
          dependencies=[Depends(require_permission("roles.manage"))])
def creer_role(libelle: str, description: Optional[str] = None, db: Session = Depends(get_db)):
    """Crée un rôle personnalisé (ex: 'coordonnateur_niveau'). ⚠️ Les
    rôles sont globaux (partagés par tous les établissements de la
    plateforme) — un rôle créé ici est visible et réutilisable par
    n'importe quel administrateur d'un autre établissement. Voir
    README.md pour la limite documentée et la piste d'évolution
    (rôles scopés par établissement)."""
    if db.query(models.Role).filter(models.Role.libelle == libelle).first():
        raise HTTPException(400, "Ce rôle existe déjà")
    role = models.Role(libelle=libelle, description=description)
    db.add(role)
    db.commit()
    db.refresh(role)
    return role


@app.put("/roles/{role_id}/permissions", response_model=schemas.RoleDetailOut, tags=["Rôles & permissions"],
         dependencies=[Depends(require_permission("roles.manage"))])
def definir_permissions_role(role_id: int, data: schemas.RolePermissionsUpdate, db: Session = Depends(get_db),
                              current_user: models.Utilisateur = Depends(get_current_user)):
    role = db.query(models.Role).get(role_id)
    if not role:
        raise HTTPException(404, "Rôle introuvable")
    permissions = db.query(models.Permission).filter(models.Permission.code.in_(data.permission_codes)).all()
    found_codes = {p.code for p in permissions}
    inconnues = set(data.permission_codes) - found_codes
    if inconnues:
        raise HTTPException(400, f"Permissions inconnues : {', '.join(inconnues)}")
    role.permissions = permissions
    db.commit()
    db.refresh(role)
    log_activity(db, current_user, "UPDATE", "Role", role_id, f"Permissions -> {', '.join(found_codes)}")
    return role


# ===========================================================================
# RÉFÉRENTIELS (réservé : permission referentiels.manage pour l'écriture ;
# lecture ouverte à tout utilisateur authentifié de l'établissement)
# ===========================================================================
@app.post("/annees-scolaires", response_model=schemas.AnneeScolaireOut, tags=["Années scolaires"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_annee_scolaire(data: schemas.AnneeScolaireCreate, db: Session = Depends(get_db),
                          current_user: models.Utilisateur = Depends(get_current_user)):
    if db.query(models.AnneeScolaire).filter(
        models.AnneeScolaire.etablissement_id == current_user.etablissement_id,
        models.AnneeScolaire.libelle == data.libelle,
    ).first():
        raise HTTPException(400, "Cette année scolaire existe déjà pour votre établissement")
    obj = models.AnneeScolaire(etablissement_id=current_user.etablissement_id, libelle=data.libelle)
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/annees-scolaires", response_model=List[schemas.AnneeScolaireOut], tags=["Années scolaires"])
def lister_annees_scolaires(db: Session = Depends(get_db),
                             current_user: models.Utilisateur = Depends(get_current_user)):
    return db.query(models.AnneeScolaire).filter(
        models.AnneeScolaire.etablissement_id == current_user.etablissement_id
    ).all()


@app.post("/niveaux", response_model=schemas.NiveauOut, tags=["Niveaux"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_niveau(data: schemas.NiveauCreate, db: Session = Depends(get_db),
                  current_user: models.Utilisateur = Depends(get_current_user)):
    obj = models.Niveau(etablissement_id=current_user.etablissement_id, **data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/niveaux", response_model=List[schemas.NiveauOut], tags=["Niveaux"])
def lister_niveaux(db: Session = Depends(get_db),
                    current_user: models.Utilisateur = Depends(get_current_user)):
    return db.query(models.Niveau).filter(
        models.Niveau.etablissement_id == current_user.etablissement_id
    ).order_by(models.Niveau.ordre).all()


@app.post("/classes", response_model=schemas.ClasseOut, tags=["Classes"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_classe(data: schemas.ClasseCreate, db: Session = Depends(get_db),
                  current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.AnneeScolaire, data.annee_scolaire_id, current_user.etablissement_id, "Année scolaire")
    get_owned_or_404(db, models.Niveau, data.niveau_id, current_user.etablissement_id, "Niveau")
    obj = models.Classe(etablissement_id=current_user.etablissement_id, **data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    log_activity(db, current_user, "CREATE", "Classe", obj.id, obj.libelle)
    return obj


@app.get("/classes", response_model=List[schemas.ClasseOut], tags=["Classes"])
def lister_classes(response: Response, annee_scolaire_id: Optional[int] = None,
                    skip: int = 0, limit: int = 200, db: Session = Depends(get_db),
                    current_user: models.Utilisateur = Depends(get_current_user)):
    q = db.query(models.Classe).filter(models.Classe.etablissement_id == current_user.etablissement_id)
    if annee_scolaire_id:
        q = q.filter(models.Classe.annee_scolaire_id == annee_scolaire_id)
    return paginate(response, q, skip, limit)


@app.delete("/classes/{classe_id}", tags=["Classes"],
            dependencies=[Depends(require_permission("referentiels.manage"))])
def supprimer_classe(classe_id: int, db: Session = Depends(get_db),
                      current_user: models.Utilisateur = Depends(get_current_user)):
    obj = get_owned_or_404(db, models.Classe, classe_id, current_user.etablissement_id, "Classe")
    db.delete(obj)
    db.commit()
    log_activity(db, current_user, "DELETE", "Classe", classe_id)
    return {"ok": True}


@app.post("/matieres", response_model=schemas.MatiereOut, tags=["Matières"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_matiere(data: schemas.MatiereCreate, db: Session = Depends(get_db),
                   current_user: models.Utilisateur = Depends(get_current_user)):
    obj = models.Matiere(etablissement_id=current_user.etablissement_id, **data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/matieres", response_model=List[schemas.MatiereOut], tags=["Matières"])
def lister_matieres(response: Response, skip: int = 0, limit: int = 200,
                     db: Session = Depends(get_db),
                     current_user: models.Utilisateur = Depends(get_current_user)):
    q = db.query(models.Matiere).filter(models.Matiere.etablissement_id == current_user.etablissement_id)
    return paginate(response, q, skip, limit)


@app.post("/enseignants", response_model=schemas.EnseignantOut, tags=["Enseignants"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_enseignant(data: schemas.EnseignantCreate, db: Session = Depends(get_db),
                      current_user: models.Utilisateur = Depends(get_current_user)):
    obj = models.Enseignant(
        etablissement_id=current_user.etablissement_id,
        nom=data.nom, prenom=data.prenom, email=data.email,
        volume_max_hebdo=data.volume_max_hebdo,
    )
    if data.matiere_ids:
        obj.matieres = db.query(models.Matiere).filter(
            models.Matiere.id.in_(data.matiere_ids),
            models.Matiere.etablissement_id == current_user.etablissement_id,
        ).all()
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/enseignants", response_model=List[schemas.EnseignantOut], tags=["Enseignants"])
def lister_enseignants(response: Response, skip: int = 0, limit: int = 200,
                        db: Session = Depends(get_db),
                        current_user: models.Utilisateur = Depends(get_current_user)):
    """Pagination importante ici pour les grands établissements (200+
    enseignants) : `limit` par défaut à 200, plafonné à 1000. Le total
    exact est disponible dans l'en-tête `X-Total-Count` de la réponse."""
    q = db.query(models.Enseignant).filter(models.Enseignant.etablissement_id == current_user.etablissement_id)
    return paginate(response, q, skip, limit)


@app.post("/salles", response_model=schemas.SalleOut, tags=["Salles"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_salle(data: schemas.SalleCreate, db: Session = Depends(get_db),
                 current_user: models.Utilisateur = Depends(get_current_user)):
    obj = models.Salle(etablissement_id=current_user.etablissement_id, **data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/salles", response_model=List[schemas.SalleOut], tags=["Salles"])
def lister_salles(response: Response, skip: int = 0, limit: int = 200,
                   db: Session = Depends(get_db),
                   current_user: models.Utilisateur = Depends(get_current_user)):
    q = db.query(models.Salle).filter(models.Salle.etablissement_id == current_user.etablissement_id)
    return paginate(response, q, skip, limit)


@app.post("/volumes-horaires", response_model=schemas.VolumeHoraireOut, tags=["Volumes horaires"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_volume_horaire(data: schemas.VolumeHoraireCreate, db: Session = Depends(get_db),
                          current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.Classe, data.classe_id, current_user.etablissement_id, "Classe")
    get_owned_or_404(db, models.Matiere, data.matiere_id, current_user.etablissement_id, "Matière")
    obj = models.VolumeHoraire(etablissement_id=current_user.etablissement_id, **data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/volumes-horaires", response_model=List[schemas.VolumeHoraireOut], tags=["Volumes horaires"])
def lister_volumes_horaires(classe_id: Optional[int] = None, db: Session = Depends(get_db),
                             current_user: models.Utilisateur = Depends(get_current_user)):
    q = db.query(models.VolumeHoraire).filter(
        models.VolumeHoraire.etablissement_id == current_user.etablissement_id
    )
    if classe_id:
        q = q.filter(models.VolumeHoraire.classe_id == classe_id)
    return q.all()


@app.post("/creneaux", response_model=schemas.CreneauOut, tags=["Créneaux"],
          dependencies=[Depends(require_permission("referentiels.manage"))])
def creer_creneau(data: schemas.CreneauCreate, db: Session = Depends(get_db),
                   current_user: models.Utilisateur = Depends(get_current_user)):
    obj = models.CreneauHoraire(etablissement_id=current_user.etablissement_id, **data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/creneaux", response_model=List[schemas.CreneauOut], tags=["Créneaux"])
def lister_creneaux(db: Session = Depends(get_db),
                     current_user: models.Utilisateur = Depends(get_current_user)):
    return db.query(models.CreneauHoraire).filter(
        models.CreneauHoraire.etablissement_id == current_user.etablissement_id
    ).order_by(models.CreneauHoraire.ordre).all()


@app.post("/disponibilites", response_model=schemas.DisponibiliteOut, tags=["Disponibilités"],
          dependencies=[Depends(require_permission("disponibilites.manage_own", "disponibilites.manage_all"))])
def creer_disponibilite(data: schemas.DisponibiliteCreate, db: Session = Depends(get_db),
                         current_user: models.Utilisateur = Depends(get_current_user)):
    user_codes = {p.code for p in current_user.role.permissions}
    if "disponibilites.manage_all" not in user_codes and current_user.enseignant_id != data.enseignant_id:
        raise HTTPException(403, "Vous ne pouvez déclarer que vos propres disponibilités")
    get_owned_or_404(db, models.Enseignant, data.enseignant_id, current_user.etablissement_id, "Enseignant")
    get_owned_or_404(db, models.CreneauHoraire, data.creneau_id, current_user.etablissement_id, "Créneau")
    obj = models.Disponibilite(**data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@app.get("/disponibilites", response_model=List[schemas.DisponibiliteOut], tags=["Disponibilités"])
def lister_disponibilites(enseignant_id: Optional[int] = None, db: Session = Depends(get_db),
                           current_user: models.Utilisateur = Depends(get_current_user)):
    q = db.query(models.Disponibilite).join(models.Enseignant).filter(
        models.Enseignant.etablissement_id == current_user.etablissement_id
    )
    if enseignant_id:
        q = q.filter(models.Disponibilite.enseignant_id == enseignant_id)
    return q.all()


# ===========================================================================
# GÉNÉRATION AUTOMATIQUE (synchrone ou asynchrone via Redis/RQ)
# ===========================================================================
@app.post("/schedules/generate/{annee_scolaire_id}", response_model=schemas.GenerationJobOut, tags=["Génération"],
          dependencies=[Depends(require_permission("schedule.generate"))])
def lancer_generation(annee_scolaire_id: int, max_time_seconds: int = 60, mode: str = "auto",
                       db: Session = Depends(get_db),
                       current_user: models.Utilisateur = Depends(get_current_user)):
    """Lance la génération de l'emploi du temps.

    - `mode=async` (ou `auto` avec Redis disponible) : la tâche est
      déposée dans la file RQ et traitée par un worker séparé.
    - `mode=sync` (ou `auto` sans Redis disponible) : la génération
      s'exécute dans la requête et le rapport est retourné directement.
    """
    get_owned_or_404(db, models.AnneeScolaire, annee_scolaire_id, current_user.etablissement_id, "Année scolaire")

    use_async = (mode == "async") or (mode == "auto" and is_redis_available())

    if use_async:
        queue = get_queue()
        job = queue.enqueue(
            run_generation_task, annee_scolaire_id, max_time_seconds, current_user.id,
            job_timeout=max(max_time_seconds + 30, 120),
        )
        log_activity(db, current_user, "GENERATE_ENQUEUE", "EmploiDuTemps", annee_scolaire_id,
                     f"Tâche asynchrone déposée (job_id={job.id})")
        return schemas.GenerationJobOut(job_id=job.id, mode="async", status="queued")

    report = generate_schedule(db, annee_scolaire_id, max_time_seconds=max_time_seconds)
    log_activity(db, current_user, "GENERATE", "EmploiDuTemps", annee_scolaire_id,
                 f"(sync) {report['seances_planifiees']}/{report['seances_totales']} séances — {report['status']}")

    if report["seances_planifiees"] > 0:
        enseignant_ids = [
            row[0] for row in db.query(models.EmploiDuTemps.enseignant_id)
            .filter(models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id).distinct().all()
        ]
        notifications.notifier_enseignants(
            db, enseignant_ids, "Emploi du temps mis à jour",
            "Votre emploi du temps a été régénéré automatiquement. Consultez les nouveaux créneaux.",
            data={"type": "generation", "annee_scolaire_id": annee_scolaire_id},
        )

    return schemas.GenerationJobOut(mode="sync", status=report["status"], report=report)


@app.get("/schedules/generate/status/{job_id}", response_model=schemas.GenerationJobOut, tags=["Génération"],
         dependencies=[Depends(require_permission("schedule.generate"))])
def statut_generation(job_id: str):
    """Interroge l'avancement d'une génération asynchrone."""
    try:
        job = fetch_job(job_id)
    except Exception:
        raise HTTPException(404, "Tâche introuvable (identifiant invalide ou expiré)")

    if job.is_finished:
        return schemas.GenerationJobOut(job_id=job_id, mode="async", status="finished", report=job.result)
    if job.is_failed:
        return schemas.GenerationJobOut(job_id=job_id, mode="async", status="failed")
    if job.is_started:
        return schemas.GenerationJobOut(job_id=job_id, mode="async", status="started")
    return schemas.GenerationJobOut(job_id=job_id, mode="async", status="queued")


# ===========================================================================
# CONSULTATION DE L'EMPLOI DU TEMPS (permission schedule.view)
# ===========================================================================
@app.get("/schedules/classe/{classe_id}", response_model=List[schemas.SeanceOut], tags=["Emploi du temps"],
         dependencies=[Depends(require_permission("schedule.view"))])
def edt_classe(classe_id: int, db: Session = Depends(get_db),
               current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.Classe, classe_id, current_user.etablissement_id, "Classe")
    return db.query(models.EmploiDuTemps).filter(models.EmploiDuTemps.classe_id == classe_id).all()


@app.get("/schedules/enseignant/{enseignant_id}", response_model=List[schemas.SeanceOut], tags=["Emploi du temps"],
         dependencies=[Depends(require_permission("schedule.view"))])
def edt_enseignant(enseignant_id: int, db: Session = Depends(get_db),
                    current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.Enseignant, enseignant_id, current_user.etablissement_id, "Enseignant")
    return db.query(models.EmploiDuTemps).filter(models.EmploiDuTemps.enseignant_id == enseignant_id).all()


@app.get("/schedules/{annee_scolaire_id}", response_model=List[schemas.SeanceOut], tags=["Emploi du temps"],
         dependencies=[Depends(require_permission("schedule.view"))])
def edt_complet(annee_scolaire_id: int, response: Response, skip: int = 0, limit: int = 500,
                 db: Session = Depends(get_db),
                 current_user: models.Utilisateur = Depends(get_current_user)):
    """Pagination importante ici pour les grands établissements : un
    établissement de 200 enseignants peut avoir plusieurs milliers de
    séances par semaine. `limit` par défaut 500, plafonné à 1000 ; total
    exact dans l'en-tête `X-Total-Count`."""
    get_owned_or_404(db, models.AnneeScolaire, annee_scolaire_id, current_user.etablissement_id, "Année scolaire")
    q = db.query(models.EmploiDuTemps).filter(models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id)
    return paginate(response, q, skip, limit)


# ===========================================================================
# ÉDITION MANUELLE & DÉTECTION DE CONFLITS (permission schedule.edit)
# ===========================================================================
@app.post("/schedules/seance/valider", response_model=schemas.SeanceValidationOut, tags=["Édition manuelle"],
          dependencies=[Depends(require_permission("schedule.edit"))])
def valider_seance(data: schemas.SeanceCreate, db: Session = Depends(get_db),
                    current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.AnneeScolaire, data.annee_scolaire_id, current_user.etablissement_id, "Année scolaire")
    conflits = conflicts.detecter_conflits(
        db, data.annee_scolaire_id, data.classe_id, data.enseignant_id,
        data.matiere_id, data.salle_id, data.creneau_id,
    )
    bloquants = [c for c in conflits if c.gravite == "bloquant"]
    return schemas.SeanceValidationOut(conflits=conflits, peut_enregistrer=len(bloquants) == 0)


@app.post("/schedules/seance", response_model=schemas.SeanceOut, tags=["Édition manuelle"],
          dependencies=[Depends(require_permission("schedule.edit"))])
def creer_seance(data: schemas.SeanceCreate, force: bool = False, db: Session = Depends(get_db),
                  current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.AnneeScolaire, data.annee_scolaire_id, current_user.etablissement_id, "Année scolaire")
    conflits = conflicts.detecter_conflits(
        db, data.annee_scolaire_id, data.classe_id, data.enseignant_id,
        data.matiere_id, data.salle_id, data.creneau_id,
    )
    bloquants = [c for c in conflits if c.gravite == "bloquant"]
    if bloquants and not force:
        raise HTTPException(409, detail={
            "message": "Conflits bloquants détectés. Utilisez force=true pour outrepasser (déconseillé).",
            "conflits": [c.model_dump() for c in conflits],
        })
    obj = models.EmploiDuTemps(etablissement_id=current_user.etablissement_id, **data.model_dump(), statut="manuel")
    db.add(obj)
    db.commit()
    db.refresh(obj)
    log_activity(db, current_user, "CREATE", "EmploiDuTemps", obj.id, "Ajout manuel")

    creneau = db.query(models.CreneauHoraire).get(obj.creneau_id)
    matiere = db.query(models.Matiere).get(obj.matiere_id)
    notifications.notifier_enseignants(
        db, [obj.enseignant_id], "Nouveau cours ajouté",
        f"{matiere.libelle} ajouté à votre emploi du temps ({notifications.label_creneau(creneau)}).",
        data={"type": "seance_creee", "seance_id": obj.id},
    )
    return obj


@app.put("/schedules/seance/{seance_id}", response_model=schemas.SeanceOut, tags=["Édition manuelle"],
         dependencies=[Depends(require_permission("schedule.edit"))])
def modifier_seance(seance_id: int, data: schemas.SeanceUpdate, db: Session = Depends(get_db),
                     current_user: models.Utilisateur = Depends(get_current_user)):
    seance = get_owned_or_404(db, models.EmploiDuTemps, seance_id, current_user.etablissement_id, "Séance")
    if seance.statut == "verrouille":
        raise HTTPException(423, "Cette séance est verrouillée et ne peut être modifiée")

    nouvel_enseignant = data.enseignant_id if data.enseignant_id is not None else seance.enseignant_id
    nouvelle_matiere = data.matiere_id if data.matiere_id is not None else seance.matiere_id
    nouvelle_salle = data.salle_id if data.salle_id is not None else seance.salle_id
    nouveau_creneau = data.creneau_id if data.creneau_id is not None else seance.creneau_id

    conflits = conflicts.detecter_conflits(
        db, seance.annee_scolaire_id, seance.classe_id, nouvel_enseignant,
        nouvelle_matiere, nouvelle_salle, nouveau_creneau, exclude_seance_id=seance_id,
    )
    bloquants = [c for c in conflits if c.gravite == "bloquant"]
    if bloquants and not data.force:
        raise HTTPException(409, detail={
            "message": "Conflits bloquants détectés. Renvoyez force=true pour outrepasser (déconseillé).",
            "conflits": [c.model_dump() for c in conflits],
        })

    ancien_enseignant_id = seance.enseignant_id

    seance.enseignant_id = nouvel_enseignant
    seance.matiere_id = nouvelle_matiere
    seance.salle_id = nouvelle_salle
    seance.creneau_id = nouveau_creneau
    seance.statut = "manuel"
    db.commit()
    db.refresh(seance)
    log_activity(db, current_user, "UPDATE", "EmploiDuTemps", seance_id, "Modification manuelle")

    creneau = db.query(models.CreneauHoraire).get(seance.creneau_id)
    matiere = db.query(models.Matiere).get(seance.matiere_id)
    enseignants_a_notifier = {ancien_enseignant_id, seance.enseignant_id}
    notifications.notifier_enseignants(
        db, enseignants_a_notifier, "Emploi du temps modifié",
        f"Une séance de {matiere.libelle} a été modifiée ({notifications.label_creneau(creneau)}).",
        data={"type": "seance_modifiee", "seance_id": seance.id},
    )
    return seance


@app.patch("/schedules/seance/{seance_id}/verrouiller", tags=["Édition manuelle"],
           dependencies=[Depends(require_permission("schedule.edit"))])
def verrouiller_seance(seance_id: int, verrouille: bool = True, db: Session = Depends(get_db),
                        current_user: models.Utilisateur = Depends(get_current_user)):
    seance = get_owned_or_404(db, models.EmploiDuTemps, seance_id, current_user.etablissement_id, "Séance")
    seance.statut = "verrouille" if verrouille else "manuel"
    db.commit()
    log_activity(db, current_user, "LOCK" if verrouille else "UNLOCK", "EmploiDuTemps", seance_id)
    return {"ok": True, "statut": seance.statut}


@app.delete("/schedules/seance/{seance_id}", tags=["Édition manuelle"],
            dependencies=[Depends(require_permission("schedule.edit"))])
def supprimer_seance(seance_id: int, db: Session = Depends(get_db),
                      current_user: models.Utilisateur = Depends(get_current_user)):
    seance = get_owned_or_404(db, models.EmploiDuTemps, seance_id, current_user.etablissement_id, "Séance")

    enseignant_id = seance.enseignant_id
    creneau = db.query(models.CreneauHoraire).get(seance.creneau_id)
    matiere = db.query(models.Matiere).get(seance.matiere_id)

    db.delete(seance)
    db.commit()
    log_activity(db, current_user, "DELETE", "EmploiDuTemps", seance_id)

    notifications.notifier_enseignants(
        db, [enseignant_id], "Cours supprimé",
        f"{matiere.libelle} retiré de votre emploi du temps ({notifications.label_creneau(creneau)}).",
        data={"type": "seance_supprimee", "seance_id": seance_id},
    )
    return {"ok": True}


@app.post("/schedules/seance/swap", response_model=List[schemas.SeanceOut], tags=["Édition manuelle"],
          dependencies=[Depends(require_permission("schedule.edit"))])
def echanger_seances(data: schemas.SeanceSwap, db: Session = Depends(get_db),
                      current_user: models.Utilisateur = Depends(get_current_user)):
    """Échange les créneaux de deux séances (glisser-déposer d'une séance
    sur une case déjà occupée)."""
    seance_1 = get_owned_or_404(db, models.EmploiDuTemps, data.seance_id_1, current_user.etablissement_id, "Séance")
    seance_2 = get_owned_or_404(db, models.EmploiDuTemps, data.seance_id_2, current_user.etablissement_id, "Séance")
    if seance_1.id == seance_2.id:
        raise HTTPException(400, "Impossible d'échanger une séance avec elle-même")
    if seance_1.statut == "verrouille" or seance_2.statut == "verrouille":
        raise HTTPException(423, "Une des deux séances est verrouillée et ne peut être déplacée")

    creneau_1, creneau_2 = seance_1.creneau_id, seance_2.creneau_id
    exclude_ids = [seance_1.id, seance_2.id]

    conflits_1 = conflicts.detecter_conflits(
        db, seance_1.annee_scolaire_id, seance_1.classe_id, seance_1.enseignant_id,
        seance_1.matiere_id, seance_1.salle_id, creneau_2, exclude_seance_ids=exclude_ids,
    )
    conflits_2 = conflicts.detecter_conflits(
        db, seance_2.annee_scolaire_id, seance_2.classe_id, seance_2.enseignant_id,
        seance_2.matiere_id, seance_2.salle_id, creneau_1, exclude_seance_ids=exclude_ids,
    )
    tous_conflits = conflits_1 + conflits_2
    bloquants = [c for c in tous_conflits if c.gravite == "bloquant"]
    if bloquants and not data.force:
        raise HTTPException(409, detail={
            "message": "Conflits bloquants détectés lors de l'échange. Renvoyez force=true pour outrepasser (déconseillé).",
            "conflits": [c.model_dump() for c in tous_conflits],
        })

    seance_1.creneau_id, seance_2.creneau_id = creneau_2, creneau_1
    seance_1.statut = "manuel"
    seance_2.statut = "manuel"
    db.commit()
    db.refresh(seance_1)
    db.refresh(seance_2)
    log_activity(db, current_user, "SWAP", "EmploiDuTemps", seance_1.id,
                 f"Échange avec séance #{seance_2.id}")

    notifications.notifier_enseignants(
        db, [seance_1.enseignant_id, seance_2.enseignant_id], "Emploi du temps modifié",
        "Deux séances ont échangé leur créneau dans votre emploi du temps.",
        data={"type": "seances_echangees", "seance_ids": [seance_1.id, seance_2.id]},
    )
    return [seance_1, seance_2]


@app.get("/schedules/conflits/{annee_scolaire_id}", tags=["Édition manuelle"],
         dependencies=[Depends(require_permission("schedule.view"))])
def scanner_conflits(annee_scolaire_id: int, db: Session = Depends(get_db),
                      current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.AnneeScolaire, annee_scolaire_id, current_user.etablissement_id, "Année scolaire")
    return conflicts.scanner_conflits_annee(db, annee_scolaire_id)


# ===========================================================================
# EXPORTS PDF / EXCEL (permission exports.use)
# ===========================================================================
@app.get("/exports/pdf/classe/{classe_id}", tags=["Exports"],
         dependencies=[Depends(require_permission("exports.use"))])
def export_pdf_classe(classe_id: int, db: Session = Depends(get_db),
                       current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.Classe, classe_id, current_user.etablissement_id, "Classe")
    pdf_bytes = exports_module.export_pdf_classe(db, classe_id)
    return StreamingResponse(
        io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=edt_classe_{classe_id}.pdf"},
    )


@app.get("/exports/pdf/enseignant/{enseignant_id}", tags=["Exports"],
         dependencies=[Depends(require_permission("exports.use"))])
def export_pdf_enseignant(enseignant_id: int, db: Session = Depends(get_db),
                           current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.Enseignant, enseignant_id, current_user.etablissement_id, "Enseignant")
    pdf_bytes = exports_module.export_pdf_enseignant(db, enseignant_id)
    return StreamingResponse(
        io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=edt_enseignant_{enseignant_id}.pdf"},
    )


@app.get("/exports/excel/{annee_scolaire_id}", tags=["Exports"],
         dependencies=[Depends(require_permission("exports.use"))])
def export_excel(annee_scolaire_id: int, db: Session = Depends(get_db),
                  current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.AnneeScolaire, annee_scolaire_id, current_user.etablissement_id, "Année scolaire")
    xlsx_bytes = exports_module.export_excel_annee(db, annee_scolaire_id)
    return StreamingResponse(
        io.BytesIO(xlsx_bytes),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename=edt_{annee_scolaire_id}.xlsx"},
    )


# ===========================================================================
# TABLEAU DE BORD & STATISTIQUES (permission dashboard.view)
# ===========================================================================
@app.get("/dashboard/{annee_scolaire_id}", response_model=schemas.DashboardStats, tags=["Tableau de bord"],
         dependencies=[Depends(require_permission("dashboard.view"))])
def dashboard_stats(annee_scolaire_id: int, db: Session = Depends(get_db),
                     current_user: models.Utilisateur = Depends(get_current_user)):
    get_owned_or_404(db, models.AnneeScolaire, annee_scolaire_id, current_user.etablissement_id, "Année scolaire")

    classes = db.query(models.Classe).filter(models.Classe.annee_scolaire_id == annee_scolaire_id).all()
    enseignants = db.query(models.Enseignant).filter(
        models.Enseignant.etablissement_id == current_user.etablissement_id
    ).count()
    salles = db.query(models.Salle).filter(
        models.Salle.etablissement_id == current_user.etablissement_id
    ).all()
    creneaux_total = db.query(models.CreneauHoraire).filter(
        models.CreneauHoraire.etablissement_id == current_user.etablissement_id
    ).count()

    volumes = db.query(models.VolumeHoraire).filter(
        models.VolumeHoraire.classe_id.in_([c.id for c in classes])
    ).all()
    seances_totales = sum(v.heures_semaine for v in volumes)

    seances_planifiees = db.query(models.EmploiDuTemps).filter(
        models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id
    ).count()

    # scanner_conflits_annee est déjà optimisé (6 requêtes fixes, voir
    # app/conflicts.py) — safe à appeler ici même pour un grand établissement.
    conflits = conflicts.scanner_conflits_annee(db, annee_scolaire_id)

    capacite_totale = len(salles) * creneaux_total if salles and creneaux_total else 1
    taux_occupation = round(100 * seances_planifiees / capacite_totale, 1)

    return schemas.DashboardStats(
        nb_classes=len(classes),
        nb_enseignants=enseignants,
        nb_salles=len(salles),
        nb_seances_planifiees=seances_planifiees,
        nb_seances_totales=seances_totales,
        taux_couverture=round(100 * seances_planifiees / seances_totales, 1) if seances_totales else 0.0,
        nb_conflits=len(conflits),
        taux_occupation_salles=taux_occupation,
    )


@app.get("/journal", response_model=List[schemas.JournalOut], tags=["Journal d'activité"],
         dependencies=[Depends(require_permission("journal.view"))])
def lister_journal(limit: int = 100, db: Session = Depends(get_db),
                    current_user: models.Utilisateur = Depends(get_current_user)):
    entries = db.query(models.JournalActivite).filter(
        models.JournalActivite.etablissement_id == current_user.etablissement_id
    ).order_by(models.JournalActivite.date_heure.desc()).limit(limit).all()
    return [schemas.JournalOut.from_orm_dt(e) for e in entries]


# ===========================================================================
# SAUVEGARDE & RESTAURATION (permission backup.manage, scopées à l'établissement)
# ===========================================================================
@app.post("/admin/backup", tags=["Sauvegarde"],
          dependencies=[Depends(require_permission("backup.manage"))])
def creer_sauvegarde(db: Session = Depends(get_db),
                      current_user: models.Utilisateur = Depends(get_current_user)):
    """Déclenche une sauvegarde immédiate des données de VOTRE établissement
    uniquement, et retourne le fichier JSON à télécharger."""
    filepath = backup_module.create_backup(db, current_user.etablissement_id)
    log_activity(db, current_user, "BACKUP", "Systeme", None, os.path.basename(filepath))
    return FileResponse(filepath, media_type="application/json", filename=os.path.basename(filepath))


@app.get("/admin/backups", tags=["Sauvegarde"],
         dependencies=[Depends(require_permission("backup.manage"))])
def lister_sauvegardes(current_user: models.Utilisateur = Depends(get_current_user)):
    return {
        "backups": backup_module.list_backups(current_user.etablissement_id),
        "backup_dir": backup_module.BACKUP_DIR,
    }


@app.post("/admin/restore", tags=["Sauvegarde"],
          dependencies=[Depends(require_permission("backup.manage"))])
async def restaurer_sauvegarde(file: UploadFile = File(...), db: Session = Depends(get_db),
                                current_user: models.Utilisateur = Depends(get_current_user)):
    """⚠️ Opération destructive : remplace les données de VOTRE
    établissement par celles du fichier fourni. Refuse si le fichier
    appartient à un autre établissement."""
    tmp_path = f"/tmp/{file.filename}"
    with open(tmp_path, "wb") as f:
        shutil.copyfileobj(file.file, f)
    try:
        result = backup_module.restore_backup(db, tmp_path, current_user.etablissement_id)
    except ValueError as e:
        raise HTTPException(403, str(e))
    except Exception as e:
        raise HTTPException(400, f"Fichier de sauvegarde invalide : {e}")
    finally:
        os.remove(tmp_path)
    log_activity(db, current_user, "RESTORE", "Systeme", None, file.filename)
    return {"ok": True, **result}


@app.get("/", tags=["Santé"])
def health_check():
    return {
        "status": "ok",
        "service": "EDT-Pro API",
        "version": "4.0.0",
        "redis_disponible": is_redis_available(),
    }
