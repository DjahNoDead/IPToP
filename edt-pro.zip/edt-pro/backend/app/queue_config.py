"""
Configuration de la file de messages pour la génération asynchrone.

Utilise Redis + RQ (Redis Queue), une solution légère et éprouvée pour
déporter les traitements longs (calcul CP-SAT) hors du cycle de requête
HTTP, conformément à l'architecture cible (voir cahier des charges,
section 2 — microservice de génération découplé via file de messages).

Variable d'environnement : REDIS_URL (défaut : redis://localhost:6379/0)
"""
import os
from redis import Redis
from rq import Queue
from rq.job import Job

REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")

_redis_conn = None
_queue = None


def get_redis_connection() -> Redis:
    global _redis_conn
    if _redis_conn is None:
        _redis_conn = Redis.from_url(REDIS_URL)
    return _redis_conn


def get_queue() -> Queue:
    global _queue
    if _queue is None:
        _queue = Queue("generation", connection=get_redis_connection(), default_timeout=600)
    return _queue


def is_redis_available() -> bool:
    """Permet un repli en mode synchrone si aucun worker/Redis n'est
    disponible (pratique en développement local sans infrastructure)."""
    try:
        get_redis_connection().ping()
        return True
    except Exception:
        return False


def fetch_job(job_id: str) -> Job:
    return Job.fetch(job_id, connection=get_redis_connection())
