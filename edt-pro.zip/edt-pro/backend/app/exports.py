"""
Génération des exports PDF et Excel de l'emploi du temps.

PDF  : mise en page grille hebdomadaire par classe ou par enseignant
       (ReportLab), au format A4 paysage, prête à l'impression.
Excel : classeur multi-feuilles (une feuille par classe et par enseignant)
       avec mise en forme et couleurs par matière (OpenPyXL).
"""
import io
from collections import defaultdict
from typing import List

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from sqlalchemy.orm import Session

from . import models


def _build_grid(seances: List[models.EmploiDuTemps], creneaux: List[models.CreneauHoraire]):
    """Construit une matrice [heure][jour] -> séance (ou None)."""
    jours = list(dict.fromkeys(c.jour for c in creneaux))
    heures = list(dict.fromkeys((c.heure_debut, c.heure_fin) for c in creneaux))

    par_creneau = {c.id: c for c in creneaux}
    grille = defaultdict(dict)
    for s in seances:
        c = par_creneau.get(s.creneau_id)
        if c:
            grille[(c.heure_debut, c.heure_fin)][c.jour] = s

    return jours, heures, grille


def _label_seance(s: models.EmploiDuTemps) -> List[str]:
    return [
        s.matiere.libelle,
        f"{s.enseignant.prenom[0]}. {s.enseignant.nom}",
        s.salle.libelle,
    ]


# ---------------------------------------------------------------------------
# Export PDF
# ---------------------------------------------------------------------------
def export_pdf_grille(titre: str, seances: List[models.EmploiDuTemps],
                       creneaux: List[models.CreneauHoraire]) -> bytes:
    jours, heures, grille = _build_grid(seances, creneaux)

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(A4),
        leftMargin=1 * cm, rightMargin=1 * cm, topMargin=1 * cm, bottomMargin=1 * cm,
    )
    styles = getSampleStyleSheet()
    elements = [Paragraph(f"<b>{titre}</b>", styles["Title"]), Spacer(1, 12)]

    header = ["Horaire"] + jours
    data = [header]
    for (hd, hf) in heures:
        row = [f"{hd} - {hf}"]
        for jour in jours:
            s = grille.get((hd, hf), {}).get(jour)
            if s:
                row.append("\n".join(_label_seance(s)))
            else:
                row.append("")
        data.append(row)

    col_widths = [2.5 * cm] + [4.2 * cm] * len(jours)
    table = Table(data, colWidths=col_widths, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1e293b")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f8fafc")]),
    ]))
    elements.append(table)
    doc.build(elements)
    return buffer.getvalue()


def export_pdf_classe(db: Session, classe_id: int) -> bytes:
    classe = db.query(models.Classe).get(classe_id)
    seances = db.query(models.EmploiDuTemps).filter(models.EmploiDuTemps.classe_id == classe_id).all()
    creneaux = db.query(models.CreneauHoraire).filter(
        models.CreneauHoraire.etablissement_id == classe.etablissement_id
    ).order_by(models.CreneauHoraire.ordre).all()
    return export_pdf_grille(f"Emploi du temps — Classe {classe.libelle}", seances, creneaux)


def export_pdf_enseignant(db: Session, enseignant_id: int) -> bytes:
    e = db.query(models.Enseignant).get(enseignant_id)
    seances = db.query(models.EmploiDuTemps).filter(models.EmploiDuTemps.enseignant_id == enseignant_id).all()
    creneaux = db.query(models.CreneauHoraire).filter(
        models.CreneauHoraire.etablissement_id == e.etablissement_id
    ).order_by(models.CreneauHoraire.ordre).all()
    return export_pdf_grille(f"Emploi du temps — {e.prenom} {e.nom}", seances, creneaux)


# ---------------------------------------------------------------------------
# Export Excel
# ---------------------------------------------------------------------------
def _write_sheet(ws, titre: str, seances: List[models.EmploiDuTemps], creneaux: List[models.CreneauHoraire]):
    jours, heures, grille = _build_grid(seances, creneaux)

    ws.title = titre[:31]  # limite Excel
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="FF1E293B", end_color="FF1E293B", fill_type="solid")
    border = Border(*(Side(style="thin", color="CBD5E1"),) * 4)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)

    ws.cell(row=1, column=1, value="Horaire").font = header_font
    ws.cell(row=1, column=1).fill = header_fill
    for j, jour in enumerate(jours, start=2):
        c = ws.cell(row=1, column=j, value=jour)
        c.font = header_font
        c.fill = header_fill
        c.alignment = center

    for i, (hd, hf) in enumerate(heures, start=2):
        ws.cell(row=i, column=1, value=f"{hd} - {hf}").alignment = center
        for j, jour in enumerate(jours, start=2):
            s = grille.get((hd, hf), {}).get(jour)
            cell = ws.cell(row=i, column=j)
            cell.alignment = center
            cell.border = border
            if s:
                cell.value = f"{s.matiere.libelle}\n{s.enseignant.prenom[0]}. {s.enseignant.nom}\n{s.salle.libelle}"
                couleur = "FF" + (s.matiere.couleur or "#3B82F6").lstrip("#").upper()
                cell.fill = PatternFill(start_color=couleur, end_color=couleur, fill_type="solid")

    ws.column_dimensions["A"].width = 16
    for j in range(2, len(jours) + 2):
        ws.column_dimensions[get_column_letter(j)].width = 22
    for i in range(2, len(heures) + 2):
        ws.row_dimensions[i].height = 45


def export_excel_annee(db: Session, annee_scolaire_id: int) -> bytes:
    """Classeur complet : une feuille par classe, une feuille par enseignant."""
    annee = db.query(models.AnneeScolaire).get(annee_scolaire_id)
    etablissement_id = annee.etablissement_id

    creneaux = db.query(models.CreneauHoraire).filter(
        models.CreneauHoraire.etablissement_id == etablissement_id
    ).order_by(models.CreneauHoraire.ordre).all()
    classes = db.query(models.Classe).filter(
        models.Classe.annee_scolaire_id == annee_scolaire_id,
        models.Classe.etablissement_id == etablissement_id,
    ).all()
    enseignants = db.query(models.Enseignant).filter(
        models.Enseignant.etablissement_id == etablissement_id
    ).all()

    wb = Workbook()
    first = True
    for classe in classes:
        seances = db.query(models.EmploiDuTemps).filter(models.EmploiDuTemps.classe_id == classe.id).all()
        ws = wb.active if first else wb.create_sheet()
        first = False
        _write_sheet(ws, f"Classe {classe.libelle}", seances, creneaux)

    for e in enseignants:
        seances = db.query(models.EmploiDuTemps).filter(
            models.EmploiDuTemps.enseignant_id == e.id,
            models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id,
        ).all()
        if not seances:
            continue
        ws = wb.create_sheet()
        _write_sheet(ws, f"{e.prenom} {e.nom}", seances, creneaux)

    buffer = io.BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
