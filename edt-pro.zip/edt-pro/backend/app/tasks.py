"""
Tâche asynchrone de génération de l'emploi du temps, exécutée par un
processus worker RQ séparé (voir app/worker.py), indépendant du processus
API. Chaque tâche ouvre sa propre session de base de données (les objets
ne peuvent pas être partagés entre processus).
"""
from .database import SessionLocal
from .engine import generate_schedule
from . import models, notifications


def run_generation_task(annee_scolaire_id: int, max_time_seconds: int = 120,
                         utilisateur_id: int = None) -> dict:
    """Point d'entrée exécuté par le worker. Retourne le rapport de
    génération (sérialisable en JSON par RQ) et journalise l'action."""
    db = SessionLocal()
    try:
        report = generate_schedule(db, annee_scolaire_id, max_time_seconds=max_time_seconds)
        entry = models.JournalActivite(
            utilisateur_id=utilisateur_id,
            action="GENERATE",
            entite="EmploiDuTemps",
            entite_id=annee_scolaire_id,
            details=f"(async) {report['seances_planifiees']}/{report['seances_totales']} séances — {report['status']}",
        )
        db.add(entry)
        db.commit()

        if report["seances_planifiees"] > 0:
            enseignant_ids = [
                row[0] for row in db.query(models.EmploiDuTemps.enseignant_id)
                .filter(models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id).distinct().all()
            ]
            notifications.notifier_enseignants(
                db, enseignant_ids, "Emploi du temps mis à jour",
                "Votre emploi du temps a été régénéré automatiquement. Consultez les nouveaux créneaux.",
                data={"type": "generation", "annee_scolaire_id": annee_scolaire_id},
            )

        return report
    finally:
        db.close()
