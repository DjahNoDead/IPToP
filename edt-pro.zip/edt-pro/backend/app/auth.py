"""
Authentification JWT et contrôle d'accès basé sur les rôles (RBAC).

- Les mots de passe sont hachés avec bcrypt (jamais stockés en clair).
- Un access token (courte durée) et un refresh token (longue durée) sont
  délivrés à la connexion, conformément aux bonnes pratiques décrites
  dans le cahier des charges (section Sécurité).
- `require_roles(...)` est une dépendance FastAPI réutilisable pour
  protéger un endpoint à un sous-ensemble de rôles.

⚠️ SECRET_KEY : en production, définir la variable d'environnement
JWT_SECRET_KEY avec une valeur longue et aléatoire (ex: `openssl rand -hex 32`).
Ne jamais utiliser la valeur par défaut ci-dessous en production.
"""
import os
from datetime import datetime, timedelta
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from . import models
from .database import get_db

SECRET_KEY = os.getenv("JWT_SECRET_KEY", "INSECURE_DEV_SECRET_CHANGE_ME")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
REFRESH_TOKEN_EXPIRE_DAYS = 7

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def _create_token(data: dict, expires_delta: timedelta, token_type: str) -> str:
    to_encode = data.copy()
    to_encode.update({"exp": datetime.utcnow() + expires_delta, "type": token_type})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def create_access_token(user: models.Utilisateur) -> str:
    return _create_token(
        {"sub": str(user.id), "role": user.role.libelle},
        timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES),
        "access",
    )


def create_refresh_token(user: models.Utilisateur) -> str:
    return _create_token(
        {"sub": str(user.id)},
        timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS),
        "refresh",
    )


def decode_token(token: str, expected_type: str = "access") -> dict:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Identifiants invalides ou expirés",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != expected_type:
            raise credentials_exception
        return payload
    except JWTError:
        raise credentials_exception


def get_current_user(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)
) -> models.Utilisateur:
    payload = decode_token(token, expected_type="access")
    user_id = payload.get("sub")
    if user_id is None:
        raise HTTPException(status_code=401, detail="Token invalide")
    user = db.query(models.Utilisateur).get(int(user_id))
    if user is None or user.statut != "actif":
        raise HTTPException(status_code=401, detail="Compte introuvable ou suspendu")
    return user


def require_roles(*roles: str):
    """Dépendance FastAPI : autorise uniquement les utilisateurs dont le
    rôle figure dans `roles`. Conservée pour les cas simples (ex:
    bootstrap, gestion des comptes) ; préférer `require_permission` pour
    le contrôle d'accès métier granulaire.
    """
    def checker(current_user: models.Utilisateur = Depends(get_current_user)) -> models.Utilisateur:
        if current_user.role.libelle not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Accès réservé aux rôles : {', '.join(roles)}",
            )
        return current_user
    return checker


def require_permission(*codes: str):
    """Dépendance FastAPI : autorise l'utilisateur si son rôle possède AU
    MOINS UNE des permissions listées (table `permissions`/`role_permissions`).
    C'est le mécanisme de contrôle d'accès granulaire recommandé : les
    permissions d'un rôle peuvent être modifiées en base sans redéploiement.
    """
    def checker(current_user: models.Utilisateur = Depends(get_current_user)) -> models.Utilisateur:
        user_codes = {p.code for p in current_user.role.permissions}
        if not user_codes.intersection(codes):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission refusée. Requiert l'une de : {', '.join(codes)}",
            )
        return current_user
    return checker


def log_activity(
    db: Session,
    user: Optional[models.Utilisateur],
    action: str,
    entite: str,
    entite_id: Optional[int] = None,
    details: Optional[str] = None,
) -> None:
    """Enregistre une entrée dans le journal d'activité (traçabilité RGPD /
    sécurité). Ne doit jamais lever d'exception bloquante pour l'opération
    métier en cours."""
    try:
        entry = models.JournalActivite(
            utilisateur_id=user.id if user else None,
            action=action,
            entite=entite,
            entite_id=entite_id,
            details=details,
        )
        db.add(entry)
        db.commit()
    except Exception:
        db.rollback()
