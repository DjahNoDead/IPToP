"""Schémas Pydantic (validation des entrées/sorties de l'API REST)."""
from typing import Optional, List
from pydantic import BaseModel, ConfigDict


# --- Établissements (multi-tenant) ---
class EtablissementOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    nom: str
    code: str
    adresse: Optional[str] = None
    statut: str


class OnboardingIn(BaseModel):
    """Création d'un nouvel établissement + de son premier compte
    administrateur, en une seule opération (endpoint public, équivalent
    d'une inscription). Les comptes suivants se créent ensuite via
    POST /users, réservé aux administrateurs de CET établissement."""
    etablissement_nom: str
    etablissement_code: str          # identifiant court unique, ex: "lycee-jean-moulin"
    admin_email: str
    admin_mot_de_passe: str
    admin_nom: str
    admin_prenom: str


class AnneeScolaireCreate(BaseModel):
    libelle: str


class AnneeScolaireOut(AnneeScolaireCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int
    statut: str


class NiveauCreate(BaseModel):
    libelle: str
    ordre: int = 0


class NiveauOut(NiveauCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int


class ClasseCreate(BaseModel):
    libelle: str
    effectif: int = 30
    niveau_id: int
    filiere_id: Optional[int] = None
    annee_scolaire_id: int


class ClasseOut(ClasseCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int


class MatiereCreate(BaseModel):
    libelle: str
    code: Optional[str] = None
    couleur: str = "#3B82F6"
    necessite_salle_specialisee: bool = False
    type_salle_requis: Optional[str] = None


class MatiereOut(MatiereCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int


class EnseignantCreate(BaseModel):
    nom: str
    prenom: str
    email: Optional[str] = None
    volume_max_hebdo: int = 18
    matiere_ids: List[int] = []


class EnseignantOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int
    nom: str
    prenom: str
    email: Optional[str]
    volume_max_hebdo: int


class SalleCreate(BaseModel):
    libelle: str
    capacite: int = 35
    type: str = "standard"


class SalleOut(SalleCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int


class VolumeHoraireCreate(BaseModel):
    classe_id: int
    matiere_id: int
    heures_semaine: int


class VolumeHoraireOut(VolumeHoraireCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int


class CreneauCreate(BaseModel):
    jour: str
    heure_debut: str
    heure_fin: str
    ordre: int


class CreneauOut(CreneauCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int


class DisponibiliteCreate(BaseModel):
    enseignant_id: int
    creneau_id: int
    type: str = "indisponible"


class DisponibiliteOut(DisponibiliteCreate):
    model_config = ConfigDict(from_attributes=True)
    id: int


class SeanceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int
    classe_id: int
    enseignant_id: int
    matiere_id: int
    salle_id: int
    creneau_id: int
    statut: str


class GenerationReport(BaseModel):
    status: str                 # "OPTIMAL" | "FEASIBLE" | "INFEASIBLE"
    seances_planifiees: int
    seances_totales: int
    temps_calcul_s: float
    message: str


class GenerationJobOut(BaseModel):
    job_id: Optional[str] = None
    mode: str                     # "async" | "sync"
    status: str                    # "queued" | "started" | "finished" | "failed" | statut du rapport si sync
    report: Optional[GenerationReport] = None


# --- Authentification ---
class RoleOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    libelle: str
    description: Optional[str] = None


class UserCreate(BaseModel):
    email: str
    mot_de_passe: str
    nom: str
    prenom: str
    role: str                       # "admin" | "proviseur" | "censeur" | "secretaire" | "enseignant"
    enseignant_id: Optional[int] = None


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    etablissement_id: int
    email: str
    nom: str
    prenom: str
    statut: str
    role: RoleOut
    enseignant_id: Optional[int] = None
    badge_count: int = 0


class TokenOut(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class RefreshIn(BaseModel):
    refresh_token: str


# --- Édition manuelle & conflits ---
class SeanceCreate(BaseModel):
    annee_scolaire_id: int
    classe_id: int
    enseignant_id: int
    matiere_id: int
    salle_id: int
    creneau_id: int


class SeanceUpdate(BaseModel):
    enseignant_id: Optional[int] = None
    matiere_id: Optional[int] = None
    salle_id: Optional[int] = None
    creneau_id: Optional[int] = None
    force: bool = False   # si True, enregistre malgré les avertissements (non bloquants)


class SeanceSwap(BaseModel):
    seance_id_1: int
    seance_id_2: int
    force: bool = False


# --- Notifications push ---
class PushTokenRegister(BaseModel):
    token: str
    plateforme: str = "expo"


class ConflitOut(BaseModel):
    type: str            # "enseignant_double_reservation" | "salle_double_reservation" | ...
    gravite: str          # "bloquant" | "avertissement"
    message: str


class SeanceValidationOut(BaseModel):
    conflits: List[ConflitOut]
    peut_enregistrer: bool


# --- Permissions granulaires ---
class PermissionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    code: str
    libelle: str


class RoleDetailOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    libelle: str
    description: Optional[str] = None
    permissions: List[PermissionOut] = []


class RolePermissionsUpdate(BaseModel):
    permission_codes: List[str]   # remplace l'intégralité des permissions du rôle


# --- Journal d'activité ---
class JournalOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    utilisateur_id: Optional[int]
    action: str
    entite: str
    entite_id: Optional[int]
    details: Optional[str]
    date_heure: str

    @staticmethod
    def from_orm_dt(obj):
        return JournalOut(
            id=obj.id,
            utilisateur_id=obj.utilisateur_id,
            action=obj.action,
            entite=obj.entite,
            entite_id=obj.entite_id,
            details=obj.details,
            date_heure=obj.date_heure.isoformat() if obj.date_heure else "",
        )


# --- Tableau de bord ---
class DashboardStats(BaseModel):
    nb_classes: int
    nb_enseignants: int
    nb_salles: int
    nb_seances_planifiees: int
    nb_seances_totales: int
    taux_couverture: float          # % de séances effectivement placées
    nb_conflits: int
    taux_occupation_salles: float   # % moyen d'occupation des salles sur la semaine
