"""
Détection de conflits pour l'édition manuelle de l'emploi du temps.

Utilisé par l'endpoint PUT /schedules/seance/{id} et POST /schedules/seance
avant tout enregistrement, ainsi que par le scan global
GET /schedules/conflits/{annee_scolaire_id} qui audite l'ensemble d'un
emploi du temps (utile après un import, une génération partielle, ou
pour un contrôle périodique).

Deux niveaux de gravité :
- "bloquant"    : viole une contrainte dure (double réservation, etc.) —
                  l'enregistrement est refusé sauf si `force=True` est
                  explicitement demandé par un utilisateur habilité.
- "avertissement" : viole une contrainte souple ou une bonne pratique
                  (ex. salle non spécialisée pour une matière qui le
                  recommande) — n'empêche pas l'enregistrement.
"""
from typing import List, Optional

from sqlalchemy.orm import Session

from . import models, schemas


def _seance_existe(db: Session, **kwargs) -> Optional[models.EmploiDuTemps]:
    q = db.query(models.EmploiDuTemps)
    for k, v in kwargs.items():
        q = q.filter(getattr(models.EmploiDuTemps, k) == v)
    return q.first()


def detecter_conflits(
    db: Session,
    annee_scolaire_id: int,
    classe_id: int,
    enseignant_id: int,
    matiere_id: int,
    salle_id: int,
    creneau_id: int,
    exclude_seance_id: Optional[int] = None,
    exclude_seance_ids: Optional[List[int]] = None,
) -> List[schemas.ConflitOut]:
    """Retourne la liste des conflits détectés pour une séance
    (existante ou à créer) avant son enregistrement.

    `exclude_seance_id` (rétro-compatibilité) et `exclude_seance_ids`
    (liste, utilisée notamment pour valider un échange entre deux
    séances) peuvent être combinés."""
    conflits: List[schemas.ConflitOut] = []

    excluded_ids = set(exclude_seance_ids or [])
    if exclude_seance_id:
        excluded_ids.add(exclude_seance_id)

    def _autre_seance(**kwargs):
        s = _seance_existe(db, annee_scolaire_id=annee_scolaire_id, **kwargs)
        if s and s.id in excluded_ids:
            return None
        return s

    # 1. Double réservation enseignant
    conflit = _autre_seance(enseignant_id=enseignant_id, creneau_id=creneau_id)
    if conflit:
        conflits.append(schemas.ConflitOut(
            type="enseignant_double_reservation",
            gravite="bloquant",
            message=f"L'enseignant est déjà affecté à une autre séance (classe #{conflit.classe_id}) sur ce créneau.",
        ))

    # 2. Double réservation salle
    conflit = _autre_seance(salle_id=salle_id, creneau_id=creneau_id)
    if conflit:
        conflits.append(schemas.ConflitOut(
            type="salle_double_reservation",
            gravite="bloquant",
            message=f"La salle est déjà occupée par une autre séance (classe #{conflit.classe_id}) sur ce créneau.",
        ))

    # 3. Double réservation classe
    conflit = _autre_seance(classe_id=classe_id, creneau_id=creneau_id)
    if conflit:
        conflits.append(schemas.ConflitOut(
            type="classe_double_reservation",
            gravite="bloquant",
            message="La classe a déjà un cours sur ce créneau.",
        ))

    # 4. Indisponibilité de l'enseignant
    indispo = db.query(models.Disponibilite).filter(
        models.Disponibilite.enseignant_id == enseignant_id,
        models.Disponibilite.creneau_id == creneau_id,
        models.Disponibilite.type == "indisponible",
    ).first()
    if indispo:
        conflits.append(schemas.ConflitOut(
            type="enseignant_indisponible",
            gravite="bloquant",
            message="L'enseignant a déclaré ce créneau comme indisponible.",
        ))

    # 5. Habilitation de l'enseignant sur la matière
    enseignant = db.query(models.Enseignant).get(enseignant_id)
    matiere = db.query(models.Matiere).get(matiere_id)
    if enseignant and matiere and matiere not in enseignant.matieres:
        conflits.append(schemas.ConflitOut(
            type="enseignant_non_habilite",
            gravite="avertissement",
            message=f"{enseignant.prenom} {enseignant.nom} n'est pas déclaré habilité pour enseigner {matiere.libelle}.",
        ))

    # 6. Compatibilité de la salle
    salle = db.query(models.Salle).get(salle_id)
    if matiere and salle and matiere.necessite_salle_specialisee:
        if matiere.type_salle_requis and salle.type != matiere.type_salle_requis:
            conflits.append(schemas.ConflitOut(
                type="salle_incompatible",
                gravite="avertissement",
                message=f"{matiere.libelle} recommande une salle de type '{matiere.type_salle_requis}', "
                        f"la salle sélectionnée est de type '{salle.type}'.",
            ))

    # 7. Capacité de la salle
    classe = db.query(models.Classe).get(classe_id)
    if classe and salle and classe.effectif > salle.capacite:
        conflits.append(schemas.ConflitOut(
            type="capacite_insuffisante",
            gravite="avertissement",
            message=f"L'effectif de la classe ({classe.effectif}) dépasse la capacité de la salle ({salle.capacite}).",
        ))

    return conflits


def scanner_conflits_annee(db: Session, annee_scolaire_id: int) -> List[dict]:
    """Audite l'intégralité de l'emploi du temps d'une année scolaire et
    retourne, pour chaque séance concernée, la liste des conflits détectés.

    Version optimisée pour les grands établissements (200+ enseignants) :
    la version naïve appelait `detecter_conflits` séance par séance, ce
    qui déclenchait ~6 requêtes SQL par séance (problème "N+1" — pour un
    établissement avec ~900 séances/semaine, cela représentait plusieurs
    milliers de requêtes à chaque appel du tableau de bord). Cette version
    charge l'intégralité des référentiels nécessaires en **6 requêtes au
    total**, quel que soit le nombre de séances, puis effectue toute la
    détection en mémoire."""
    from collections import defaultdict

    seances = db.query(models.EmploiDuTemps).filter(
        models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id
    ).all()
    if not seances:
        return []

    enseignant_ids = {s.enseignant_id for s in seances}
    matiere_ids = {s.matiere_id for s in seances}
    salle_ids = {s.salle_id for s in seances}
    classe_ids = {s.classe_id for s in seances}

    enseignants = {e.id: e for e in db.query(models.Enseignant).filter(models.Enseignant.id.in_(enseignant_ids)).all()}
    matieres = {m.id: m for m in db.query(models.Matiere).filter(models.Matiere.id.in_(matiere_ids)).all()}
    salles = {s.id: s for s in db.query(models.Salle).filter(models.Salle.id.in_(salle_ids)).all()}
    classes = {c.id: c for c in db.query(models.Classe).filter(models.Classe.id.in_(classe_ids)).all()}

    habilitations = {
        (row.enseignant_id, row.matiere_id)
        for row in db.execute(
            models.enseignant_matiere.select().where(
                models.enseignant_matiere.c.enseignant_id.in_(enseignant_ids)
            )
        ).fetchall()
    }

    indispos = {
        (d.enseignant_id, d.creneau_id)
        for d in db.query(models.Disponibilite).filter(
            models.Disponibilite.enseignant_id.in_(enseignant_ids),
            models.Disponibilite.type == "indisponible",
        ).all()
    }

    par_enseignant_creneau = defaultdict(list)
    par_salle_creneau = defaultdict(list)
    par_classe_creneau = defaultdict(list)
    for s in seances:
        par_enseignant_creneau[(s.enseignant_id, s.creneau_id)].append(s)
        par_salle_creneau[(s.salle_id, s.creneau_id)].append(s)
        par_classe_creneau[(s.classe_id, s.creneau_id)].append(s)

    resultats = []
    for s in seances:
        conflits = []

        autres = [o for o in par_enseignant_creneau[(s.enseignant_id, s.creneau_id)] if o.id != s.id]
        if autres:
            conflits.append({
                "type": "enseignant_double_reservation", "gravite": "bloquant",
                "message": f"L'enseignant est déjà affecté à une autre séance (classe #{autres[0].classe_id}) sur ce créneau.",
            })

        autres = [o for o in par_salle_creneau[(s.salle_id, s.creneau_id)] if o.id != s.id]
        if autres:
            conflits.append({
                "type": "salle_double_reservation", "gravite": "bloquant",
                "message": f"La salle est déjà occupée par une autre séance (classe #{autres[0].classe_id}) sur ce créneau.",
            })

        autres = [o for o in par_classe_creneau[(s.classe_id, s.creneau_id)] if o.id != s.id]
        if autres:
            conflits.append({
                "type": "classe_double_reservation", "gravite": "bloquant",
                "message": "La classe a déjà un cours sur ce créneau.",
            })

        if (s.enseignant_id, s.creneau_id) in indispos:
            conflits.append({
                "type": "enseignant_indisponible", "gravite": "bloquant",
                "message": "L'enseignant a déclaré ce créneau comme indisponible.",
            })

        enseignant = enseignants.get(s.enseignant_id)
        matiere = matieres.get(s.matiere_id)
        if enseignant and matiere and (s.enseignant_id, s.matiere_id) not in habilitations:
            conflits.append({
                "type": "enseignant_non_habilite", "gravite": "avertissement",
                "message": f"{enseignant.prenom} {enseignant.nom} n'est pas déclaré habilité pour enseigner {matiere.libelle}.",
            })

        salle = salles.get(s.salle_id)
        if matiere and salle and matiere.necessite_salle_specialisee and matiere.type_salle_requis and salle.type != matiere.type_salle_requis:
            conflits.append({
                "type": "salle_incompatible", "gravite": "avertissement",
                "message": f"{matiere.libelle} recommande une salle de type '{matiere.type_salle_requis}', "
                           f"la salle sélectionnée est de type '{salle.type}'.",
            })

        classe = classes.get(s.classe_id)
        if classe and salle and classe.effectif > salle.capacite:
            conflits.append({
                "type": "capacite_insuffisante", "gravite": "avertissement",
                "message": f"L'effectif de la classe ({classe.effectif}) dépasse la capacité de la salle ({salle.capacite}).",
            })

        if conflits:
            resultats.append({
                "seance_id": s.id, "classe_id": s.classe_id, "creneau_id": s.creneau_id,
                "conflits": conflits,
            })

    return resultats
