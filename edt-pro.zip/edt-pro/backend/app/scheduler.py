"""
Planification des sauvegardes automatiques (tous les jours à 02h00 par
défaut) et purge des sauvegardes obsolètes. Démarré au lancement de
l'API (voir événement `startup` dans app/main.py).

Multi-établissements : une sauvegarde est générée **par établissement**
(les sauvegardes sont cloisonnées, voir app/backup.py) — ce job itère
sur tous les établissements actifs de la plateforme.

Variables d'environnement :
- BACKUP_SCHEDULE_HOUR (défaut : 2)
- BACKUP_RETENTION_COUNT (défaut : 30, par établissement)
"""
import os
from apscheduler.schedulers.background import BackgroundScheduler

from .database import SessionLocal
from . import models
from .backup import create_backup, prune_old_backups

BACKUP_HOUR = int(os.getenv("BACKUP_SCHEDULE_HOUR", "2"))
BACKUP_RETENTION = int(os.getenv("BACKUP_RETENTION_COUNT", "30"))

_scheduler = None


def _job_sauvegarde_automatique():
    db = SessionLocal()
    try:
        etablissements = db.query(models.Etablissement).filter(
            models.Etablissement.statut == "actif"
        ).all()
        for etab in etablissements:
            try:
                path = create_backup(db, etab.id)
                print(f"🗄️  Sauvegarde automatique effectuée pour {etab.nom} : {path}")
            except Exception as e:
                print(f"⚠️  Échec de la sauvegarde automatique pour {etab.nom} : {e}")
        prune_old_backups(keep_per_etablissement=BACKUP_RETENTION)
    except Exception as e:
        print(f"⚠️  Échec du job de sauvegarde automatique : {e}")
    finally:
        db.close()


def start_scheduler():
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    _scheduler = BackgroundScheduler()
    _scheduler.add_job(
        _job_sauvegarde_automatique,
        trigger="cron",
        hour=BACKUP_HOUR,
        minute=0,
        id="sauvegarde_quotidienne",
        replace_existing=True,
    )
    _scheduler.start()
    print(f"⏰ Planificateur de sauvegardes démarré (quotidienne à {BACKUP_HOUR:02d}:00, rétention {BACKUP_RETENTION})")
    return _scheduler


def stop_scheduler():
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
