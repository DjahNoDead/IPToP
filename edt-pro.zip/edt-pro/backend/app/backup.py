"""
Sauvegarde et restauration de la base de données au format JSON
(portable entre SQLite et PostgreSQL, contrairement à un dump binaire).

**Cloisonnement multi-établissements** : une sauvegarde ne contient que
les données de l'établissement de l'administrateur qui la déclenche, et
une restauration ne touche que les données de CET établissement — un
administrateur ne peut jamais lire ni écraser les données d'un autre
établissement via ce mécanisme. `Role`/`Permission`/`role_permissions`
sont des tables globales partagées (taxonomie du RBAC, pas des données
métier d'un établissement) : elles ne sont ni sauvegardées ni restaurées
par ce module — elles sont initialisées une fois par `app/seed.py` ou au
premier `POST /etablissements/onboard`.

Pour un établissement en production sur PostgreSQL, `pg_dump`/`pg_restore`
(avec RLS ou un schéma dédié par tenant) restent recommandés pour une
sauvegarde binaire complète à grande échelle ; ce module fournit une
solution applicative portable, suffisante pour la reprise après incident
sur les données métier d'un établissement.
"""
import json
import os
from datetime import datetime

from sqlalchemy import inspect
from sqlalchemy.orm import Session

from . import models

BACKUP_DIR = os.getenv("BACKUP_DIR", "./backups")

# Ordre d'export/import respectant les dépendances de clés étrangères.
# Toutes ces tables portent une colonne etablissement_id (directe ou,
# pour PushToken, via utilisateur_id) — voir _filtre_etablissement.
TABLES_ORDER = [
    models.Utilisateur,
    models.AnneeScolaire,
    models.Niveau,
    models.Filiere,
    models.Classe,
    models.Matiere,
    models.Enseignant,
    models.Salle,
    models.VolumeHoraire,
    models.CreneauHoraire,
    models.Disponibilite,
    models.EmploiDuTemps,
    models.JournalActivite,
    models.PushToken,
]


def _filtre_etablissement(db: Session, model, etablissement_id: int):
    """Retourne la requête de `model` restreinte à l'établissement donné,
    quelle que soit la façon dont la table s'y rattache (colonne directe,
    ou indirecte via une relation pour les tables qui n'en ont pas)."""
    q = db.query(model)
    if hasattr(model, "etablissement_id"):
        return q.filter(model.etablissement_id == etablissement_id)
    if model is models.Disponibilite:
        enseignant_ids = db.query(models.Enseignant.id).filter(
            models.Enseignant.etablissement_id == etablissement_id
        )
        return q.filter(model.enseignant_id.in_(enseignant_ids))
    if model is models.PushToken:
        utilisateur_ids = db.query(models.Utilisateur.id).filter(
            models.Utilisateur.etablissement_id == etablissement_id
        )
        return q.filter(model.utilisateur_id.in_(utilisateur_ids))
    raise ValueError(f"Impossible de restreindre {model.__name__} à un établissement")


def _serialize_row(obj) -> dict:
    mapper = inspect(obj.__class__)
    data = {}
    for column in mapper.columns:
        value = getattr(obj, column.name)
        if isinstance(value, datetime):
            value = value.isoformat()
        data[column.name] = value
    return data


def _serialize_enseignant_matieres(db: Session, etablissement_id: int):
    """La table d'association enseignant_matieres n'a pas de modèle ORM
    dédié ni de colonne etablissement_id directe : on la restreint via
    les enseignants de l'établissement."""
    enseignant_ids = [
        row[0] for row in db.query(models.Enseignant.id).filter(
            models.Enseignant.etablissement_id == etablissement_id
        ).all()
    ]
    if not enseignant_ids:
        return []
    rows = db.execute(
        models.enseignant_matiere.select().where(
            models.enseignant_matiere.c.enseignant_id.in_(enseignant_ids)
        )
    ).fetchall()
    return [dict(row._mapping) for row in rows]


def create_backup(db: Session, etablissement_id: int) -> str:
    """Crée un fichier de sauvegarde JSON horodaté (données de
    l'établissement donné uniquement) et retourne son chemin."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(BACKUP_DIR, f"edt_pro_backup_etab{etablissement_id}_{timestamp}.json")

    payload = {
        "version": 2,
        "etablissement_id": etablissement_id,
        "created_at": datetime.utcnow().isoformat(),
        "tables": {},
        "associations": {"enseignant_matieres": _serialize_enseignant_matieres(db, etablissement_id)},
    }
    for model in TABLES_ORDER:
        rows = _filtre_etablissement(db, model, etablissement_id).all()
        payload["tables"][model.__tablename__] = [_serialize_row(r) for r in rows]

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)

    return filepath


def prune_old_backups(keep_per_etablissement: int = 30) -> None:
    """Conserve uniquement les `keep_per_etablissement` sauvegardes les
    plus récentes **par établissement** (appelé automatiquement par le
    planificateur — voir app/scheduler.py)."""
    if not os.path.isdir(BACKUP_DIR):
        return
    fichiers = [f for f in os.listdir(BACKUP_DIR) if f.startswith("edt_pro_backup_")]

    par_etablissement = {}
    for f in fichiers:
        # format : edt_pro_backup_etab{id}_{timestamp}.json
        cle = f.split("_")[3] if f.startswith("edt_pro_backup_etab") else "legacy"
        par_etablissement.setdefault(cle, []).append(f)

    for cle, groupe in par_etablissement.items():
        for old_file in sorted(groupe, reverse=True)[keep_per_etablissement:]:
            try:
                os.remove(os.path.join(BACKUP_DIR, old_file))
            except OSError:
                pass


def restore_backup(db: Session, filepath: str, etablissement_id: int) -> dict:
    """Restaure une sauvegarde JSON. ⚠️ Opération destructive : vide les
    données de CET établissement avant réimport. Refuse si le fichier
    fourni appartient à un autre établissement (protection contre une
    restauration croisée accidentelle ou malveillante)."""
    with open(filepath, "r", encoding="utf-8") as f:
        payload = json.load(f)

    fichier_etablissement_id = payload.get("etablissement_id")
    if fichier_etablissement_id is not None and fichier_etablissement_id != etablissement_id:
        raise ValueError(
            f"Ce fichier de sauvegarde appartient à l'établissement #{fichier_etablissement_id}, "
            f"pas au vôtre (#{etablissement_id}). Restauration refusée."
        )

    # Suppression dans l'ordre inverse pour respecter les contraintes FK,
    # restreinte aux seules données de cet établissement.
    for model in reversed(TABLES_ORDER):
        _filtre_etablissement(db, model, etablissement_id).delete(synchronize_session=False)
    enseignant_ids = [
        row[0] for row in db.query(models.Enseignant.id).filter(
            models.Enseignant.etablissement_id == etablissement_id
        ).all()
    ]
    if enseignant_ids:
        db.execute(
            models.enseignant_matiere.delete().where(
                models.enseignant_matiere.c.enseignant_id.in_(enseignant_ids)
            )
        )
    db.commit()

    counts = {}
    for model in TABLES_ORDER:
        rows = payload["tables"].get(model.__tablename__, [])
        for row in rows:
            db.add(model(**row))
        counts[model.__tablename__] = len(rows)
    db.commit()

    assoc_rows = payload.get("associations", {}).get("enseignant_matieres", [])
    if assoc_rows:
        db.execute(models.enseignant_matiere.insert(), assoc_rows)
    db.commit()

    return {"restored_at": datetime.utcnow().isoformat(), "counts": counts}


def list_backups(etablissement_id: int) -> list:
    """Liste uniquement les sauvegardes appartenant à cet établissement."""
    if not os.path.isdir(BACKUP_DIR):
        return []
    prefixe = f"edt_pro_backup_etab{etablissement_id}_"
    return sorted(
        (f for f in os.listdir(BACKUP_DIR) if f.startswith(prefixe)),
        reverse=True,
    )
