"""
Worker RQ — traite les tâches de génération de manière asynchrone.

Lancement (processus séparé du serveur API) :
    python -m app.worker

En production, plusieurs workers peuvent être lancés en parallèle
(scalabilité horizontale du moteur de calcul, indépendante de l'API —
voir architecture générale du cahier des charges).
"""
from rq import Worker
from .queue_config import get_queue, get_redis_connection

if __name__ == "__main__":
    queue = get_queue()
    worker = Worker([queue], connection=get_redis_connection())
    print("🚀 Worker EDT-Pro démarré — en attente de tâches de génération...")
    worker.work()
