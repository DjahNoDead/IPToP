"""
Modèles SQLAlchemy — implémentation du modèle relationnel décrit dans le
cahier des charges, en version **multi-établissements** (multi-tenant).

Cloisonnement des données : toute table métier propre à un établissement
porte une colonne `etablissement_id` (indexée), et toute requête de
lecture/écriture doit être filtrée par l'établissement de l'utilisateur
connecté — voir `app/main.py` (jamais fourni par le client, toujours
dérivé de `current_user.etablissement_id`).

Restent **globaux** (partagés entre tous les établissements), car il
s'agit d'une taxonomie structurelle et non de données métier :
`Role`, `Permission`, `role_permissions`.

Performance : des index explicites sont posés sur les colonnes de clé
étrangère systématiquement filtrées (etablissement_id, et les colonnes
utilisées par le moteur de détection de conflits) — voir le détail dans
chaque table ci-dessous, ainsi que `DEPLOYMENT.md` / `PERFORMANCE.md`
pour la méthodologie de validation à grande échelle (200+ enseignants).
"""
from datetime import datetime

from sqlalchemy import (
    Column, Integer, String, Boolean, ForeignKey, UniqueConstraint, Table, DateTime, Index
)
from sqlalchemy.orm import relationship
from .database import Base


class Etablissement(Base):
    """Un établissement scolaire = un tenant. Toutes les données
    métier (classes, enseignants, emplois du temps...) sont rattachées à
    un et un seul établissement."""
    __tablename__ = "etablissements"
    id = Column(Integer, primary_key=True)
    nom = Column(String, nullable=False)
    code = Column(String, unique=True, nullable=False, index=True)  # identifiant court, ex: "lycee-jean-moulin"
    adresse = Column(String, nullable=True)
    statut = Column(String, default="actif")  # actif | suspendu
    date_creation = Column(DateTime, default=datetime.utcnow)


# --- Rôles disponibles (RBAC) — GLOBAUX, partagés entre établissements ---
# libelle attendu : "admin", "proviseur", "censeur", "secretaire", "enseignant"
class Role(Base):
    __tablename__ = "roles"
    id = Column(Integer, primary_key=True)
    libelle = Column(String, unique=True, nullable=False)
    description = Column(String, nullable=True)

    permissions = relationship("Permission", secondary="role_permissions", back_populates="roles")


class Permission(Base):
    """Permission granulaire (ex: 'classes.manage', 'schedule.generate').
    Voir app/permissions_catalog.py pour la liste complète des codes."""
    __tablename__ = "permissions"
    id = Column(Integer, primary_key=True)
    code = Column(String, unique=True, nullable=False)
    libelle = Column(String, nullable=False)

    roles = relationship("Role", secondary="role_permissions", back_populates="permissions")


role_permissions = Table(
    "role_permissions",
    Base.metadata,
    Column("role_id", Integer, ForeignKey("roles.id"), primary_key=True),
    Column("permission_id", Integer, ForeignKey("permissions.id"), primary_key=True),
)


class Utilisateur(Base):
    __tablename__ = "utilisateurs"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    email = Column(String, unique=True, nullable=False, index=True)
    mot_de_passe_hash = Column(String, nullable=False)
    nom = Column(String, nullable=False)
    prenom = Column(String, nullable=False)
    role_id = Column(Integer, ForeignKey("roles.id"), nullable=False)
    statut = Column(String, default="actif")  # actif | suspendu
    # Lien optionnel vers la fiche enseignant si le compte correspond à un professeur
    enseignant_id = Column(Integer, ForeignKey("enseignants.id"), nullable=True)
    derniere_connexion = Column(DateTime, nullable=True)
    # Compteur de notifications non consultées (badge de l'icône mobile).
    badge_count = Column(Integer, default=0)

    etablissement = relationship("Etablissement")
    role = relationship("Role")
    enseignant = relationship("Enseignant")


class JournalActivite(Base):
    __tablename__ = "journaux_activite"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=True, index=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"), nullable=True)
    action = Column(String, nullable=False)          # ex: "CREATE", "UPDATE", "DELETE", "LOGIN", "GENERATE"
    entite = Column(String, nullable=False)           # ex: "EmploiDuTemps", "Classe", "Utilisateur"
    entite_id = Column(Integer, nullable=True)
    details = Column(String, nullable=True)
    date_heure = Column(DateTime, default=datetime.utcnow, index=True)

    utilisateur = relationship("Utilisateur")


class PushToken(Base):
    """Token de notification push (Expo), associé à un compte utilisateur
    (donc implicitement à son établissement via `utilisateur_id`)."""
    __tablename__ = "push_tokens"
    id = Column(Integer, primary_key=True)
    utilisateur_id = Column(Integer, ForeignKey("utilisateurs.id"), nullable=False, index=True)
    token = Column(String, unique=True, nullable=False)
    plateforme = Column(String, default="expo")  # "expo" | "ios" | "android"
    date_creation = Column(DateTime, default=datetime.utcnow)

    utilisateur = relationship("Utilisateur")


# --- Table d'association Enseignant <-> Matière (habilitations) ---
enseignant_matiere = Table(
    "enseignant_matieres",
    Base.metadata,
    Column("enseignant_id", Integer, ForeignKey("enseignants.id"), primary_key=True),
    Column("matiere_id", Integer, ForeignKey("matieres.id"), primary_key=True),
)


class AnneeScolaire(Base):
    __tablename__ = "annees_scolaires"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    libelle = Column(String, nullable=False)
    statut = Column(String, default="active")  # active | archivee

    classes = relationship("Classe", back_populates="annee_scolaire")

    __table_args__ = (UniqueConstraint("etablissement_id", "libelle", name="uq_etablissement_annee"),)


class Niveau(Base):
    __tablename__ = "niveaux"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    libelle = Column(String, nullable=False)   # ex: "Seconde", "Première", "Terminale"
    ordre = Column(Integer, default=0)


class Filiere(Base):
    __tablename__ = "filieres"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    libelle = Column(String, nullable=False)   # ex: "Générale", "STI2D"
    niveau_id = Column(Integer, ForeignKey("niveaux.id"))


class Classe(Base):
    __tablename__ = "classes"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    libelle = Column(String, nullable=False)   # ex: "2ndeA"
    effectif = Column(Integer, default=30)
    niveau_id = Column(Integer, ForeignKey("niveaux.id"))
    filiere_id = Column(Integer, ForeignKey("filieres.id"), nullable=True)
    annee_scolaire_id = Column(Integer, ForeignKey("annees_scolaires.id"), index=True)

    annee_scolaire = relationship("AnneeScolaire", back_populates="classes")
    volumes_horaires = relationship("VolumeHoraire", back_populates="classe")


class Enseignant(Base):
    __tablename__ = "enseignants"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    nom = Column(String, nullable=False)
    prenom = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=True)
    volume_max_hebdo = Column(Integer, default=18)

    matieres = relationship("Matiere", secondary=enseignant_matiere, back_populates="enseignants")
    disponibilites = relationship("Disponibilite", back_populates="enseignant")


class Matiere(Base):
    __tablename__ = "matieres"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    libelle = Column(String, nullable=False)
    code = Column(String, nullable=True)
    couleur = Column(String, default="#3B82F6")
    necessite_salle_specialisee = Column(Boolean, default=False)
    type_salle_requis = Column(String, nullable=True)  # ex: "labo", "info", "eps"

    enseignants = relationship("Enseignant", secondary=enseignant_matiere, back_populates="matieres")

    __table_args__ = (UniqueConstraint("etablissement_id", "code", name="uq_etablissement_matiere_code"),)


class Salle(Base):
    __tablename__ = "salles"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    libelle = Column(String, nullable=False)
    capacite = Column(Integer, default=35)
    type = Column(String, default="standard")  # standard | labo | info | eps | atelier


class VolumeHoraire(Base):
    __tablename__ = "volumes_horaires"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    classe_id = Column(Integer, ForeignKey("classes.id"), index=True)
    matiere_id = Column(Integer, ForeignKey("matieres.id"))
    heures_semaine = Column(Integer, nullable=False)  # nombre de séances d'1h / semaine

    classe = relationship("Classe", back_populates="volumes_horaires")
    matiere = relationship("Matiere")

    __table_args__ = (UniqueConstraint("classe_id", "matiere_id", name="uq_classe_matiere"),)


class CreneauHoraire(Base):
    """Grille horaire officielle (trame commune à toutes les classes d'un
    même établissement — chaque établissement définit la sienne)."""
    __tablename__ = "creneaux_horaires"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    jour = Column(String, nullable=False)   # Lundi, Mardi, ...
    heure_debut = Column(String, nullable=False)  # "08:00"
    heure_fin = Column(String, nullable=False)    # "09:00"
    ordre = Column(Integer, nullable=False)        # ordre chronologique global (0, 1, 2, ...)


class Disponibilite(Base):
    """Créneau marqué indisponible ou préféré par un enseignant."""
    __tablename__ = "disponibilites"
    id = Column(Integer, primary_key=True)
    enseignant_id = Column(Integer, ForeignKey("enseignants.id"), index=True)
    creneau_id = Column(Integer, ForeignKey("creneaux_horaires.id"), index=True)
    type = Column(String, default="indisponible")  # indisponible | preferee

    enseignant = relationship("Enseignant", back_populates="disponibilites")
    creneau = relationship("CreneauHoraire")

    __table_args__ = (
        # Accélère la construction de l'ensemble des indisponibilités par
        # le moteur de génération (une requête filtrée par type, groupée
        # implicitement par enseignant/créneau).
        Index("ix_disponibilites_enseignant_creneau_type", "enseignant_id", "creneau_id", "type"),
    )


class EmploiDuTemps(Base):
    """Séance planifiée — résultat du moteur de génération ou édition manuelle."""
    __tablename__ = "emplois_du_temps"
    id = Column(Integer, primary_key=True)
    etablissement_id = Column(Integer, ForeignKey("etablissements.id"), nullable=False, index=True)
    annee_scolaire_id = Column(Integer, ForeignKey("annees_scolaires.id"), index=True)
    classe_id = Column(Integer, ForeignKey("classes.id"))
    enseignant_id = Column(Integer, ForeignKey("enseignants.id"))
    matiere_id = Column(Integer, ForeignKey("matieres.id"))
    salle_id = Column(Integer, ForeignKey("salles.id"))
    creneau_id = Column(Integer, ForeignKey("creneaux_horaires.id"))
    statut = Column(String, default="genere")  # genere | manuel | valide | verrouille

    classe = relationship("Classe")
    enseignant = relationship("Enseignant")
    matiere = relationship("Matiere")
    salle = relationship("Salle")
    creneau = relationship("CreneauHoraire")

    __table_args__ = (
        UniqueConstraint("annee_scolaire_id", "classe_id", "creneau_id", name="uq_classe_creneau"),
        UniqueConstraint("annee_scolaire_id", "enseignant_id", "creneau_id", name="uq_enseignant_creneau"),
        UniqueConstraint("annee_scolaire_id", "salle_id", "creneau_id", name="uq_salle_creneau"),
        # Index dédiés pour la détection de conflits et le scan en masse
        # (app/conflicts.py) : ces requêtes filtrent par paire
        # (ressource, créneau) sans forcément connaître classe_id ou
        # annee_scolaire_id en tête, donc les contraintes UNIQUE ci-dessus
        # (qui commencent par annee_scolaire_id) ne suffisent pas seules.
        Index("ix_edt_enseignant_creneau", "enseignant_id", "creneau_id"),
        Index("ix_edt_salle_creneau", "salle_id", "creneau_id"),
        Index("ix_edt_classe_creneau", "classe_id", "creneau_id"),
    )
