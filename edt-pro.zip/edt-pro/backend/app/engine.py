"""
Moteur de génération automatique de l'emploi du temps.

Modélisation : programmation par contraintes (CP-SAT / Google OR-Tools).

Principe :
- Chaque "séance" à planifier correspond à une heure de cours d'une matière
  pour une classe donnée (une matière avec heures_semaine=3 génère 3 séances).
- Pour chaque séance, une variable booléenne y[s, creneau, enseignant, salle]
  vaut 1 si la séance s est placée à ce créneau, avec cet enseignant et
  cette salle.
- Seules les combinaisons valides sont créées (enseignant habilité et
  disponible, salle compatible), ce qui limite fortement le nombre de
  variables.

Contraintes dures :
  1. Chaque séance est affectée exactement une fois.
  2. Un enseignant ne peut être affecté à deux séances sur le même créneau.
  3. Une salle ne peut accueillir deux séances sur le même créneau.
  4. Une classe ne peut avoir deux séances sur le même créneau.
  5. Les disponibilités "indisponible" des enseignants sont respectées.
  6. Une matière nécessitant une salle spécialisée n'est placée que dans
     une salle du type requis.

Objectif (heuristique simplifiée) :
  - Favoriser les créneaux les plus tôt dans la semaine pour limiter les
    trous dans l'emploi du temps des classes (compaction).
  - Bonus si un créneau "préféré" déclaré par l'enseignant est respecté.
"""
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from ortools.sat.python import cp_model
from sqlalchemy.orm import Session

from . import models


@dataclass
class Session_:
    """Une occurrence horaire (1h) à planifier pour (classe, matiere)."""
    id: int
    classe_id: int
    matiere_id: int


def _compatible_rooms(matiere: models.Matiere, salles: List[models.Salle]) -> List[int]:
    if matiere.necessite_salle_specialisee and matiere.type_salle_requis:
        rooms = [s.id for s in salles if s.type == matiere.type_salle_requis]
        # Repli : si aucune salle spécialisée n'existe, on autorise les salles standards
        return rooms if rooms else [s.id for s in salles]
    return [s.id for s in salles]


def generate_schedule(db: Session, annee_scolaire_id: int, max_time_seconds: int = 60) -> dict:
    """Lance la génération et enregistre le résultat en base.

    Retourne un rapport (dict) exploitable par l'API / le frontend.

    Cloisonnement multi-établissements : l'établissement est dérivé de
    l'année scolaire elle-même (jamais d'un paramètre fourni par
    l'appelant) et **toutes** les requêtes de référentiels (salles,
    enseignants, matières, créneaux) sont filtrées par cet établissement
    — sans quoi le moteur mélangerait les ressources de plusieurs écoles.
    """
    t0 = time.time()

    annee = db.query(models.AnneeScolaire).get(annee_scolaire_id)
    if not annee:
        return {
            "status": "INFEASIBLE", "seances_planifiees": 0, "seances_totales": 0,
            "temps_calcul_s": round(time.time() - t0, 2),
            "message": "Année scolaire introuvable.",
        }
    etablissement_id = annee.etablissement_id

    classes = db.query(models.Classe).filter(
        models.Classe.annee_scolaire_id == annee_scolaire_id,
        models.Classe.etablissement_id == etablissement_id,
    ).all()
    volumes = db.query(models.VolumeHoraire).filter(
        models.VolumeHoraire.classe_id.in_([c.id for c in classes])
    ).all()
    salles = db.query(models.Salle).filter(models.Salle.etablissement_id == etablissement_id).all()
    creneaux = db.query(models.CreneauHoraire).filter(
        models.CreneauHoraire.etablissement_id == etablissement_id
    ).order_by(models.CreneauHoraire.ordre).all()
    matieres = {
        m.id: m for m in db.query(models.Matiere).filter(models.Matiere.etablissement_id == etablissement_id).all()
    }
    enseignants = db.query(models.Enseignant).filter(models.Enseignant.etablissement_id == etablissement_id).all()

    if not classes or not volumes or not salles or not creneaux:
        return {
            "status": "INFEASIBLE",
            "seances_planifiees": 0,
            "seances_totales": 0,
            "temps_calcul_s": round(time.time() - t0, 2),
            "message": "Données insuffisantes : vérifier classes, volumes horaires, salles et créneaux.",
        }

    # --- 1. Construction de la liste des séances à planifier ---
    sessions: List[Session_] = []
    sid = 0
    for v in volumes:
        for _ in range(v.heures_semaine):
            sessions.append(Session_(id=sid, classe_id=v.classe_id, matiere_id=v.matiere_id))
            sid += 1

    # --- 2. Enseignants habilités par matière ---
    profs_par_matiere: Dict[int, List[int]] = defaultdict(list)
    for e in enseignants:
        for m in e.matieres:
            profs_par_matiere[m.id].append(e.id)

    # --- 3. Indisponibilités enseignants (restreintes aux enseignants de
    # cet établissement, déjà filtrés ci-dessus) ---
    enseignant_ids = [e.id for e in enseignants]
    indispos: Dict[int, set] = defaultdict(set)
    for d in db.query(models.Disponibilite).filter(
        models.Disponibilite.type == "indisponible",
        models.Disponibilite.enseignant_id.in_(enseignant_ids),
    ).all():
        indispos[d.enseignant_id].add(d.creneau_id)

    preferences: Dict[int, set] = defaultdict(set)
    for d in db.query(models.Disponibilite).filter(
        models.Disponibilite.type == "preferee",
        models.Disponibilite.enseignant_id.in_(enseignant_ids),
    ).all():
        preferences[d.enseignant_id].add(d.creneau_id)

    # --- 4. Modèle CP-SAT ---
    model = cp_model.CpModel()
    y = {}  # (session_id, creneau_id, enseignant_id, salle_id) -> BoolVar
    var_index: Dict[int, List[Tuple]] = defaultdict(list)  # session_id -> liste de clés

    missing_teacher_subjects = set()

    for s in sessions:
        matiere = matieres[s.matiere_id]
        profs_possibles = profs_par_matiere.get(s.matiere_id, [])
        if not profs_possibles:
            missing_teacher_subjects.add(matiere.libelle)
            continue
        salles_compatibles = _compatible_rooms(matiere, salles)

        for c in creneaux:
            for e_id in profs_possibles:
                if c.id in indispos.get(e_id, set()):
                    continue
                for salle_id in salles_compatibles:
                    key = (s.id, c.id, e_id, salle_id)
                    y[key] = model.NewBoolVar(f"y_{s.id}_{c.id}_{e_id}_{salle_id}")
                    var_index[s.id].append(key)

    if missing_teacher_subjects:
        return {
            "status": "INFEASIBLE",
            "seances_planifiees": 0,
            "seances_totales": len(sessions),
            "temps_calcul_s": round(time.time() - t0, 2),
            "message": (
                "Aucun enseignant habilité pour les matières : "
                + ", ".join(sorted(missing_teacher_subjects))
                + ". Veuillez associer un enseignant à ces matières."
            ),
        }

    # Contrainte 1 : chaque séance affectée au plus une fois (relâchée si infaisable
    # pour permettre un rapport partiel — on utilisera <= 1 puis on comptera le total)
    for s in sessions:
        keys = var_index.get(s.id, [])
        if keys:
            model.Add(sum(y[k] for k in keys) <= 1)

    # Contrainte 2 : un enseignant ne peut être affecté à 2 séances sur le même créneau
    par_enseignant_creneau: Dict[Tuple[int, int], List] = defaultdict(list)
    for key in y:
        _, c_id, e_id, _ = key
        par_enseignant_creneau[(e_id, c_id)].append(y[key])
    for group in par_enseignant_creneau.values():
        model.Add(sum(group) <= 1)

    # Contrainte 3 : une salle ne peut accueillir 2 séances sur le même créneau
    par_salle_creneau: Dict[Tuple[int, int], List] = defaultdict(list)
    for key in y:
        _, c_id, _, salle_id = key
        par_salle_creneau[(salle_id, c_id)].append(y[key])
    for group in par_salle_creneau.values():
        model.Add(sum(group) <= 1)

    # Contrainte 4 : une classe ne peut avoir 2 séances sur le même créneau
    par_classe_creneau: Dict[Tuple[int, int], List] = defaultdict(list)
    for s in sessions:
        for key in var_index.get(s.id, []):
            _, c_id, _, _ = key
            par_classe_creneau[(s.classe_id, c_id)].append(y[key])
    for group in par_classe_creneau.values():
        model.Add(sum(group) <= 1)

    # --- 5. Objectif : maximiser le nombre de séances placées (priorité absolue),
    #        puis compacter (favoriser les créneaux tôt dans la semaine) et
    #        respecter les préférences enseignants.
    placement_terms = []
    compaction_terms = []
    preference_terms = []

    for s in sessions:
        for key in var_index.get(s.id, []):
            _, c_id, e_id, _ = key
            var = y[key]
            placement_terms.append(var)
            ordre = next(c.ordre for c in creneaux if c.id == c_id)
            compaction_terms.append(var * ordre)
            if c_id in preferences.get(e_id, set()):
                preference_terms.append(var)

    W_PLACEMENT = 1000   # priorité maximale : placer un maximum de séances
    W_COMPACTION = 1
    W_PREFERENCE = 5

    model.Maximize(
        W_PLACEMENT * sum(placement_terms)
        - W_COMPACTION * sum(compaction_terms)
        + W_PREFERENCE * sum(preference_terms)
    )

    # --- 6. Résolution ---
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = max_time_seconds
    solver.parameters.num_search_workers = 8
    status = solver.Solve(model)

    status_name = solver.StatusName(status)

    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return {
            "status": status_name,
            "seances_planifiees": 0,
            "seances_totales": len(sessions),
            "temps_calcul_s": round(time.time() - t0, 2),
            "message": "Aucune solution trouvée dans le temps imparti. Essayez d'augmenter le temps de calcul ou de vérifier les contraintes.",
        }

    # --- 7. Sauvegarde du résultat ---
    db.query(models.EmploiDuTemps).filter(
        models.EmploiDuTemps.annee_scolaire_id == annee_scolaire_id,
        models.EmploiDuTemps.etablissement_id == etablissement_id,
    ).delete()

    placees = 0
    for s in sessions:
        for key in var_index.get(s.id, []):
            if solver.Value(y[key]) == 1:
                _, c_id, e_id, salle_id = key
                seance = models.EmploiDuTemps(
                    etablissement_id=etablissement_id,
                    annee_scolaire_id=annee_scolaire_id,
                    classe_id=s.classe_id,
                    enseignant_id=e_id,
                    matiere_id=s.matiere_id,
                    salle_id=salle_id,
                    creneau_id=c_id,
                    statut="genere",
                )
                db.add(seance)
                placees += 1
                break

    db.commit()

    message = "Génération terminée avec succès."
    if placees < len(sessions):
        message = (
            f"Génération partielle : {placees}/{len(sessions)} séances placées. "
            "Certaines contraintes (disponibilités, salles spécialisées, nombre "
            "d'enseignants) empêchent de placer toutes les séances."
        )

    return {
        "status": status_name,
        "seances_planifiees": placees,
        "seances_totales": len(sessions),
        "temps_calcul_s": round(time.time() - t0, 2),
        "message": message,
    }
