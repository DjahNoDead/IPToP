"""
Script de peuplement de la base avec un jeu de données de démonstration :
un établissement, 2 classes, 5 matières, 6 enseignants, 4 salles, une
grille de 25 créneaux (5 jours x 5 heures), les volumes horaires
associés, le catalogue de permissions + rôles standards (globaux), et
des comptes de démonstration pour chaque rôle.

Usage :
    python -m app.seed
"""
from .database import SessionLocal, engine, Base
from . import models
from .auth import hash_password
from .permissions_catalog import garantir_catalogue_global

JOURS = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"]
HEURES = [("08:00", "09:00"), ("09:00", "10:00"), ("10:00", "11:00"),
          ("11:00", "12:00"), ("14:00", "15:00")]

ETABLISSEMENT_CODE = "lycee-demo"


def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # Nettoyage (démo idempotente) — supprime uniquement l'établissement
    # de démonstration et tout ce qui lui est rattaché ; ne touche jamais
    # au catalogue global de rôles/permissions (partagé, garanti par
    # garantir_catalogue_global ci-dessous).
    ancien = db.query(models.Etablissement).filter(models.Etablissement.code == ETABLISSEMENT_CODE).first()
    if ancien:
        for model in [models.JournalActivite, models.PushToken, models.Utilisateur,
                      models.EmploiDuTemps, models.Disponibilite, models.VolumeHoraire,
                      models.CreneauHoraire, models.Salle, models.Classe,
                      models.Filiere, models.Niveau, models.AnneeScolaire]:
            if hasattr(model, "etablissement_id"):
                db.query(model).filter(model.etablissement_id == ancien.id).delete()
        enseignant_ids = [
            row[0] for row in db.query(models.Enseignant.id).filter(
                models.Enseignant.etablissement_id == ancien.id
            ).all()
        ]
        if enseignant_ids:
            db.execute(models.enseignant_matiere.delete().where(
                models.enseignant_matiere.c.enseignant_id.in_(enseignant_ids)
            ))
        db.query(models.Enseignant).filter(models.Enseignant.etablissement_id == ancien.id).delete()
        db.query(models.Matiere).filter(models.Matiere.etablissement_id == ancien.id).delete()
        db.query(models.Etablissement).filter(models.Etablissement.id == ancien.id).delete()
        db.commit()

    # --- Catalogue global (rôles + permissions), idempotent ---
    garantir_catalogue_global(db)
    roles = {r.libelle: r for r in db.query(models.Role).all()}

    # --- Établissement de démonstration ---
    etablissement = models.Etablissement(nom="Lycée Démo", code=ETABLISSEMENT_CODE, statut="actif")
    db.add(etablissement)
    db.commit()
    db.refresh(etablissement)
    etab_id = etablissement.id

    annee = models.AnneeScolaire(etablissement_id=etab_id, libelle="2026-2027", statut="active")
    db.add(annee)
    db.commit()

    niveau = models.Niveau(etablissement_id=etab_id, libelle="Seconde", ordre=1)
    db.add(niveau)
    db.commit()

    classe_a = models.Classe(etablissement_id=etab_id, libelle="2ndeA", effectif=30,
                              niveau_id=niveau.id, annee_scolaire_id=annee.id)
    classe_b = models.Classe(etablissement_id=etab_id, libelle="2ndeB", effectif=28,
                              niveau_id=niveau.id, annee_scolaire_id=annee.id)
    db.add_all([classe_a, classe_b])
    db.commit()

    matieres_def = [
        ("Mathématiques", "MATH", "#3B82F6", False, None),
        ("Français", "FR", "#EF4444", False, None),
        ("Physique-Chimie", "PC", "#10B981", True, "labo"),
        ("Anglais", "ANG", "#F59E0B", False, None),
        ("EPS", "EPS", "#8B5CF6", True, "eps"),
    ]
    matieres = {}
    for libelle, code, couleur, specialisee, type_salle in matieres_def:
        m = models.Matiere(etablissement_id=etab_id, libelle=libelle, code=code, couleur=couleur,
                            necessite_salle_specialisee=specialisee, type_salle_requis=type_salle)
        db.add(m)
        matieres[code] = m
    db.commit()

    profs_def = [
        ("Dupont", "Claire", ["MATH"]),
        ("Martin", "Julien", ["FR"]),
        ("Bernard", "Sophie", ["PC"]),
        ("Petit", "Marc", ["ANG"]),
        ("Robert", "Nadia", ["EPS"]),
        ("Moreau", "Alain", ["MATH", "PC"]),  # enseignant polyvalent
    ]
    profs = {}
    for nom, prenom, codes in profs_def:
        e = models.Enseignant(etablissement_id=etab_id, nom=nom, prenom=prenom, volume_max_hebdo=18)
        e.matieres = [matieres[c] for c in codes]
        db.add(e)
        profs[nom] = e
    db.commit()

    salles_def = [
        ("Salle 101", 35, "standard"),
        ("Salle 102", 35, "standard"),
        ("Labo Sciences", 30, "labo"),
        ("Gymnase", 60, "eps"),
    ]
    for libelle, cap, type_ in salles_def:
        db.add(models.Salle(etablissement_id=etab_id, libelle=libelle, capacite=cap, type=type_))
    db.commit()

    ordre = 0
    for jour in JOURS:
        for debut, fin in HEURES:
            db.add(models.CreneauHoraire(etablissement_id=etab_id, jour=jour, heure_debut=debut,
                                          heure_fin=fin, ordre=ordre))
            ordre += 1
    db.commit()

    volumes_def = {"MATH": 4, "FR": 4, "PC": 3, "ANG": 3, "EPS": 2}
    for classe in [classe_a, classe_b]:
        for code, heures in volumes_def.items():
            db.add(models.VolumeHoraire(
                etablissement_id=etab_id, classe_id=classe.id,
                matiere_id=matieres[code].id, heures_semaine=heures,
            ))
    db.commit()

    # --- Comptes de démonstration ---
    comptes_def = [
        ("admin@lycee-demo.fr", "Admin123!", "Système", "Admin", "admin", None),
        ("proviseur@lycee-demo.fr", "Proviseur123!", "Girard", "Hélène", "proviseur", None),
        ("secretariat@lycee-demo.fr", "Secretaire123!", "Lambert", "Paul", "secretaire", None),
        ("censeur@lycee-demo.fr", "Censeur123!", "Fontaine", "Michel", "censeur", None),
        ("claire.dupont@lycee-demo.fr", "Enseignant123!", "Dupont", "Claire", "enseignant", profs["Dupont"].id),
    ]
    for email, pwd, nom, prenom, role_libelle, ens_id in comptes_def:
        u = models.Utilisateur(
            etablissement_id=etab_id, email=email, mot_de_passe_hash=hash_password(pwd),
            nom=nom, prenom=prenom, role_id=roles[role_libelle].id, enseignant_id=ens_id,
        )
        db.add(u)
    db.commit()

    db.close()
    print("✅ Données de démonstration insérées avec succès.")
    print(f"   Établissement : Lycée Démo (code={ETABLISSEMENT_CODE}, id={etab_id})")
    print(f"   Année scolaire : 2026-2027 (id={annee.id})")
    print("   Classes : 2ndeA, 2ndeB")
    print("   Comptes de démonstration (mot de passe entre parenthèses) :")
    for email, pwd, *_ in comptes_def:
        print(f"     - {email} ({pwd})")
    print(f"   Pour lancer la génération : POST /schedules/generate/{annee.id}")
    print()
    print("   Pour créer un DEUXIÈME établissement (tester le cloisonnement) :")
    print("     POST /etablissements/onboard")


if __name__ == "__main__":
    seed()
