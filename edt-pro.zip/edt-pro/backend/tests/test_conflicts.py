"""Tests unitaires — app/conflicts.py"""
from app import models, conflicts


def _ajouter_seance(db, d, creneau_idx, salle=None):
    """Ajoute une séance existante en base pour préparer un scénario de conflit."""
    seance = models.EmploiDuTemps(
        etablissement_id=d["etablissement"].id,
        annee_scolaire_id=d["annee"].id,
        classe_id=d["classe"].id,
        enseignant_id=d["prof_maths"].id,
        matiere_id=d["maths"].id,
        salle_id=(salle or d["salle_standard"]).id,
        creneau_id=d["creneaux"][creneau_idx].id,
        statut="manuel",
    )
    db.add(seance)
    db.commit()
    db.refresh(seance)
    return seance


def test_aucun_conflit_sur_grille_vide(db_session, donnees_base):
    d = donnees_base
    resultat = conflicts.detecter_conflits(
        db_session, d["annee"].id, d["classe"].id, d["prof_maths"].id,
        d["maths"].id, d["salle_standard"].id, d["creneaux"][0].id,
    )
    assert resultat == []


def test_double_reservation_enseignant(db_session, donnees_base):
    d = donnees_base
    _ajouter_seance(db_session, d, creneau_idx=0)

    # Même enseignant, même créneau, salle différente -> conflit bloquant
    resultat = conflicts.detecter_conflits(
        db_session, d["annee"].id, d["classe"].id, d["prof_maths"].id,
        d["maths"].id, d["salle_labo"].id, d["creneaux"][0].id,
    )
    types = [c.type for c in resultat]
    assert "enseignant_double_reservation" in types
    assert any(c.gravite == "bloquant" for c in resultat if c.type == "enseignant_double_reservation")


def test_double_reservation_salle(db_session, donnees_base):
    d = donnees_base
    _ajouter_seance(db_session, d, creneau_idx=0, salle=d["salle_standard"])

    resultat = conflicts.detecter_conflits(
        db_session, d["annee"].id, d["classe"].id, d["prof_pc"].id,
        d["pc"].id, d["salle_standard"].id, d["creneaux"][0].id,
    )
    types = [c.type for c in resultat]
    assert "salle_double_reservation" in types


def test_indisponibilite_enseignant_respectee(db_session, donnees_base):
    d = donnees_base
    dispo = models.Disponibilite(
        enseignant_id=d["prof_maths"].id, creneau_id=d["creneaux"][1].id, type="indisponible",
    )
    db_session.add(dispo)
    db_session.commit()

    resultat = conflicts.detecter_conflits(
        db_session, d["annee"].id, d["classe"].id, d["prof_maths"].id,
        d["maths"].id, d["salle_standard"].id, d["creneaux"][1].id,
    )
    types = [c.type for c in resultat]
    assert "enseignant_indisponible" in types


def test_salle_incompatible_matiere_specialisee(db_session, donnees_base):
    d = donnees_base
    # PC nécessite une salle "labo" ; on tente de la placer en salle standard
    resultat = conflicts.detecter_conflits(
        db_session, d["annee"].id, d["classe"].id, d["prof_pc"].id,
        d["pc"].id, d["salle_standard"].id, d["creneaux"][0].id,
    )
    types = [c.type for c in resultat]
    assert "salle_incompatible" in types
    conflit = next(c for c in resultat if c.type == "salle_incompatible")
    assert conflit.gravite == "avertissement"  # non bloquant


def test_exclude_seance_id_permet_l_auto_modification(db_session, donnees_base):
    """Modifier une séance existante sans changer son créneau ne doit pas
    générer de faux conflit avec elle-même."""
    d = donnees_base
    seance = _ajouter_seance(db_session, d, creneau_idx=0)

    resultat = conflicts.detecter_conflits(
        db_session, d["annee"].id, d["classe"].id, d["prof_maths"].id,
        d["maths"].id, d["salle_standard"].id, d["creneaux"][0].id,
        exclude_seance_id=seance.id,
    )
    bloquants = [c for c in resultat if c.gravite == "bloquant"]
    assert bloquants == []


def test_scanner_conflits_annee_detecte_les_seances_en_conflit(db_session, donnees_base):
    d = donnees_base
    # Deux séances forcées sur le même créneau/enseignant (contournement direct de la BDD,
    # simulateur d'un import de données incohérent)
    s1 = models.EmploiDuTemps(
        etablissement_id=d["etablissement"].id,
        annee_scolaire_id=d["annee"].id, classe_id=d["classe"].id,
        enseignant_id=d["prof_maths"].id, matiere_id=d["maths"].id,
        salle_id=d["salle_standard"].id, creneau_id=d["creneaux"][0].id, statut="manuel",
    )
    db_session.add(s1)
    db_session.commit()

    resultats = conflicts.scanner_conflits_annee(db_session, d["annee"].id)
    assert isinstance(resultats, list)  # pas de conflit ici : une seule séance valide
    assert resultats == []
