"""
Fixtures pytest partagées.

Chaque test utilise une base SQLite en mémoire fraîche (aucun état
partagé entre tests), et l'API FastAPI est testée via TestClient avec la
dépendance get_db substituée pour pointer vers cette base isolée.
"""
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app import models
from app.permissions_catalog import garantir_catalogue_global
from app.main import app
from fastapi.testclient import TestClient


@pytest.fixture()
def db_session():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(bind=engine)
    TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.close()


@pytest.fixture()
def client(db_session):
    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db
    yield TestClient(app)
    app.dependency_overrides.clear()


@pytest.fixture()
def etablissement(db_session):
    """Un établissement de test, avec le catalogue global de rôles et
    permissions garanti présent."""
    garantir_catalogue_global(db_session)
    etab = models.Etablissement(nom="Lycée de Test", code="lycee-test")
    db_session.add(etab)
    db_session.commit()
    db_session.refresh(etab)
    return etab


@pytest.fixture()
def donnees_base(db_session, etablissement):
    """Jeu de données minimal réutilisé par plusieurs tests : 1 classe,
    2 matières, 2 enseignants, 2 salles, 1 grille de créneaux réduite —
    toutes rattachées au même établissement de test."""
    etab_id = etablissement.id

    annee = models.AnneeScolaire(etablissement_id=etab_id, libelle="2026-2027")
    db_session.add(annee)
    db_session.commit()

    niveau = models.Niveau(etablissement_id=etab_id, libelle="Seconde", ordre=1)
    db_session.add(niveau)
    db_session.commit()

    classe = models.Classe(etablissement_id=etab_id, libelle="2ndeA", effectif=30,
                            niveau_id=niveau.id, annee_scolaire_id=annee.id)
    db_session.add(classe)
    db_session.commit()

    maths = models.Matiere(etablissement_id=etab_id, libelle="Mathématiques", code="MATH",
                            necessite_salle_specialisee=False)
    pc = models.Matiere(etablissement_id=etab_id, libelle="Physique-Chimie", code="PC",
                         necessite_salle_specialisee=True, type_salle_requis="labo")
    db_session.add_all([maths, pc])
    db_session.commit()

    prof_maths = models.Enseignant(etablissement_id=etab_id, nom="Dupont", prenom="Claire", volume_max_hebdo=18)
    prof_maths.matieres = [maths]
    prof_pc = models.Enseignant(etablissement_id=etab_id, nom="Bernard", prenom="Sophie", volume_max_hebdo=18)
    prof_pc.matieres = [pc]
    db_session.add_all([prof_maths, prof_pc])
    db_session.commit()

    salle_standard = models.Salle(etablissement_id=etab_id, libelle="Salle 101", capacite=35, type="standard")
    salle_labo = models.Salle(etablissement_id=etab_id, libelle="Labo Sciences", capacite=30, type="labo")
    db_session.add_all([salle_standard, salle_labo])
    db_session.commit()

    creneaux = []
    for i, (jour, heure) in enumerate([
        ("Lundi", "08:00"), ("Lundi", "09:00"), ("Mardi", "08:00"), ("Mardi", "09:00"),
    ]):
        c = models.CreneauHoraire(etablissement_id=etab_id, jour=jour, heure_debut=heure,
                                   heure_fin=f"{int(heure[:2])+1:02d}:00", ordre=i)
        db_session.add(c)
        creneaux.append(c)
    db_session.commit()

    vh1 = models.VolumeHoraire(etablissement_id=etab_id, classe_id=classe.id, matiere_id=maths.id, heures_semaine=2)
    vh2 = models.VolumeHoraire(etablissement_id=etab_id, classe_id=classe.id, matiere_id=pc.id, heures_semaine=1)
    db_session.add_all([vh1, vh2])
    db_session.commit()

    return {
        "etablissement": etablissement, "annee": annee, "niveau": niveau, "classe": classe,
        "maths": maths, "pc": pc,
        "prof_maths": prof_maths, "prof_pc": prof_pc,
        "salle_standard": salle_standard, "salle_labo": salle_labo,
        "creneaux": creneaux,
    }
