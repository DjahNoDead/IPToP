"""
Tests d'intégration de l'API — onboarding d'établissement, authentification,
permissions granulaires, cloisonnement multi-établissements, pagination,
parcours complet jusqu'à la génération (mode synchrone forcé pour ne pas
dépendre d'un Redis disponible pendant les tests).

⚠️ Nécessite fastapi, httpx, ortools installés — voir requirements-dev.txt.
Non exécuté dans l'environnement de rédaction (pas d'accès réseau) :
à lancer avec `pytest tests/test_api.py -v`.
"""
import itertools

_compteur_code = itertools.count()


def _onboard_and_login(client, code=None, email=None, password="Admin123!"):
    """Crée un nouvel établissement + son admin, puis se connecte.
    `code`/`email` sont générés automatiquement si non fournis, pour que
    chaque test puisse créer son propre établissement isolé sans
    collision (un même processus pytest partage parfois l'état entre
    tests selon l'ordre d'exécution)."""
    suffixe = next(_compteur_code)
    code = code or f"lycee-test-{suffixe}"
    email = email or f"admin{suffixe}@test.fr"

    res = client.post("/etablissements/onboard", json={
        "etablissement_nom": "Lycée de Test", "etablissement_code": code,
        "admin_email": email, "admin_mot_de_passe": password,
        "admin_nom": "Test", "admin_prenom": "Admin",
    })
    assert res.status_code == 200, res.text

    res = client.post("/auth/login", data={"username": email, "password": password})
    assert res.status_code == 200, res.text
    token = res.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}


def test_onboarding_puis_login(client):
    headers = _onboard_and_login(client)
    res = client.get("/auth/me", headers=headers)
    assert res.status_code == 200
    assert res.json()["role"]["libelle"] == "admin"
    assert res.json()["etablissement_id"] is not None


def test_onboarding_refuse_code_deja_utilise(client):
    _onboard_and_login(client, code="lycee-unique")
    res = client.post("/etablissements/onboard", json={
        "etablissement_nom": "Autre Lycée", "etablissement_code": "lycee-unique",
        "admin_email": "autre@test.fr", "admin_mot_de_passe": "X123!",
        "admin_nom": "A", "admin_prenom": "B",
    })
    assert res.status_code == 400


def test_login_refuse_mauvais_mot_de_passe(client):
    headers = _onboard_and_login(client)
    me = client.get("/auth/me", headers=headers).json()
    res = client.post("/auth/login", data={"username": me["email"], "password": "mauvais"})
    assert res.status_code == 401


def test_endpoint_protege_sans_token_refuse(client):
    res = client.post("/classes", json={
        "libelle": "2ndeA", "effectif": 30, "niveau_id": 1, "annee_scolaire_id": 1,
    })
    assert res.status_code == 401


def test_lecture_referentiels_exige_authentification(client):
    """Les listes de référentiels (classes, enseignants...) ne sont plus
    accessibles sans authentification — nécessaire pour déterminer
    l'établissement dont les données doivent être renvoyées."""
    res = client.get("/classes")
    assert res.status_code == 401
    res = client.get("/enseignants")
    assert res.status_code == 401


def _creer_referentiel_complet(client, headers):
    """Crée un jeu de données complet (classe, matière, enseignant,
    salle, créneaux) pour un établissement déjà onboardé, et retourne
    les objets créés."""
    annee = client.post("/annees-scolaires", json={"libelle": "2026-2027"}, headers=headers).json()
    niveau = client.post("/niveaux", json={"libelle": "Seconde", "ordre": 1}, headers=headers).json()
    classe = client.post("/classes", json={
        "libelle": "2ndeA", "effectif": 30, "niveau_id": niveau["id"], "annee_scolaire_id": annee["id"],
    }, headers=headers).json()
    matiere = client.post("/matieres", json={
        "libelle": "Mathématiques", "code": "MATH", "necessite_salle_specialisee": False,
    }, headers=headers).json()
    enseignant = client.post("/enseignants", json={
        "nom": "Dupont", "prenom": "Claire", "volume_max_hebdo": 18, "matiere_ids": [matiere["id"]],
    }, headers=headers).json()
    salle = client.post("/salles", json={"libelle": "Salle 101", "capacite": 35, "type": "standard"}, headers=headers).json()
    client.post("/volumes-horaires", json={
        "classe_id": classe["id"], "matiere_id": matiere["id"], "heures_semaine": 2,
    }, headers=headers)
    for i, (jour, heure) in enumerate([("Lundi", "08:00"), ("Lundi", "09:00")]):
        client.post("/creneaux", json={
            "jour": jour, "heure_debut": heure, "heure_fin": "09:00" if heure == "08:00" else "10:00", "ordre": i,
        }, headers=headers)
    return {"annee": annee, "niveau": niveau, "classe": classe, "matiere": matiere,
            "enseignant": enseignant, "salle": salle}


def test_parcours_complet_jusqu_a_generation(client):
    headers = _onboard_and_login(client)
    d = _creer_referentiel_complet(client, headers)

    res = client.post(f"/schedules/generate/{d['annee']['id']}?mode=sync&max_time_seconds=10", headers=headers)
    assert res.status_code == 200, res.text
    data = res.json()
    assert data["mode"] == "sync"
    assert data["report"]["seances_planifiees"] == 2

    res = client.get(f"/schedules/classe/{d['classe']['id']}", headers=headers)
    assert res.status_code == 200
    assert len(res.json()) == 2


def test_permission_referentiels_manage_requise_pour_creer_classe(client):
    """Un rôle sans la permission referentiels.manage (ex: censeur) ne peut
    pas créer de classe, même authentifié."""
    admin_headers = _onboard_and_login(client)
    d = _creer_referentiel_complet(client, admin_headers)

    res = client.post("/users", json={
        "email": "censeur@test.fr", "mot_de_passe": "Censeur123!",
        "nom": "Fontaine", "prenom": "Michel", "role": "censeur",
    }, headers=admin_headers)
    assert res.status_code == 200, res.text

    login_res = client.post("/auth/login", data={"username": "censeur@test.fr", "password": "Censeur123!"})
    censeur_headers = {"Authorization": f"Bearer {login_res.json()['access_token']}"}

    res = client.post("/classes", json={
        "libelle": "2ndeB", "effectif": 30, "niveau_id": d["niveau"]["id"], "annee_scolaire_id": d["annee"]["id"],
    }, headers=censeur_headers)
    assert res.status_code == 403


def test_echange_de_deux_seances(client):
    """Vérifie que deux séances existantes échangent bien leurs créneaux
    (glisser-déposer d'une séance sur une case déjà occupée)."""
    headers = _onboard_and_login(client)

    annee = client.post("/annees-scolaires", json={"libelle": "2026-2027"}, headers=headers).json()
    niveau = client.post("/niveaux", json={"libelle": "Seconde", "ordre": 1}, headers=headers).json()
    classe = client.post("/classes", json={
        "libelle": "2ndeA", "effectif": 30, "niveau_id": niveau["id"], "annee_scolaire_id": annee["id"],
    }, headers=headers).json()
    maths = client.post("/matieres", json={"libelle": "Mathématiques", "code": "MATH"}, headers=headers).json()
    fr = client.post("/matieres", json={"libelle": "Français", "code": "FR"}, headers=headers).json()
    prof_maths = client.post("/enseignants", json={
        "nom": "Dupont", "prenom": "Claire", "matiere_ids": [maths["id"]],
    }, headers=headers).json()
    prof_fr = client.post("/enseignants", json={
        "nom": "Martin", "prenom": "Julien", "matiere_ids": [fr["id"]],
    }, headers=headers).json()
    salle = client.post("/salles", json={"libelle": "Salle 101", "capacite": 35}, headers=headers).json()
    creneau_1 = client.post("/creneaux", json={
        "jour": "Lundi", "heure_debut": "08:00", "heure_fin": "09:00", "ordre": 0,
    }, headers=headers).json()
    creneau_2 = client.post("/creneaux", json={
        "jour": "Lundi", "heure_debut": "09:00", "heure_fin": "10:00", "ordre": 1,
    }, headers=headers).json()

    seance_maths = client.post("/schedules/seance", json={
        "annee_scolaire_id": annee["id"], "classe_id": classe["id"], "enseignant_id": prof_maths["id"],
        "matiere_id": maths["id"], "salle_id": salle["id"], "creneau_id": creneau_1["id"],
    }, headers=headers).json()
    seance_fr = client.post("/schedules/seance", json={
        "annee_scolaire_id": annee["id"], "classe_id": classe["id"], "enseignant_id": prof_fr["id"],
        "matiere_id": fr["id"], "salle_id": salle["id"], "creneau_id": creneau_2["id"],
    }, headers=headers).json()

    res = client.post("/schedules/seance/swap", json={
        "seance_id_1": seance_maths["id"], "seance_id_2": seance_fr["id"],
    }, headers=headers)
    assert res.status_code == 200, res.text
    resultat = res.json()
    maj_maths = next(s for s in resultat if s["id"] == seance_maths["id"])
    maj_fr = next(s for s in resultat if s["id"] == seance_fr["id"])
    assert maj_maths["creneau_id"] == creneau_2["id"]
    assert maj_fr["creneau_id"] == creneau_1["id"]


def test_echange_refuse_si_seance_verrouillee(client):
    headers = _onboard_and_login(client)

    annee = client.post("/annees-scolaires", json={"libelle": "2026-2027"}, headers=headers).json()
    niveau = client.post("/niveaux", json={"libelle": "Seconde", "ordre": 1}, headers=headers).json()
    classe = client.post("/classes", json={
        "libelle": "2ndeA", "effectif": 30, "niveau_id": niveau["id"], "annee_scolaire_id": annee["id"],
    }, headers=headers).json()
    maths = client.post("/matieres", json={"libelle": "Mathématiques", "code": "MATH"}, headers=headers).json()
    prof = client.post("/enseignants", json={
        "nom": "Dupont", "prenom": "Claire", "matiere_ids": [maths["id"]],
    }, headers=headers).json()
    salle = client.post("/salles", json={"libelle": "Salle 101", "capacite": 35}, headers=headers).json()
    creneau_1 = client.post("/creneaux", json={
        "jour": "Lundi", "heure_debut": "08:00", "heure_fin": "09:00", "ordre": 0,
    }, headers=headers).json()
    creneau_2 = client.post("/creneaux", json={
        "jour": "Lundi", "heure_debut": "09:00", "heure_fin": "10:00", "ordre": 1,
    }, headers=headers).json()

    s1 = client.post("/schedules/seance", json={
        "annee_scolaire_id": annee["id"], "classe_id": classe["id"], "enseignant_id": prof["id"],
        "matiere_id": maths["id"], "salle_id": salle["id"], "creneau_id": creneau_1["id"],
    }, headers=headers).json()
    s2 = client.post("/schedules/seance", json={
        "annee_scolaire_id": annee["id"], "classe_id": classe["id"], "enseignant_id": prof["id"],
        "matiere_id": maths["id"], "salle_id": salle["id"], "creneau_id": creneau_2["id"],
    }, headers=headers, params={"force": "true"}).json()

    client.patch(f"/schedules/seance/{s1['id']}/verrouiller", headers=headers)

    res = client.post("/schedules/seance/swap", json={
        "seance_id_1": s1["id"], "seance_id_2": s2["id"],
    }, headers=headers)
    assert res.status_code == 423


def test_role_personnalise_avec_permissions_a_la_carte(client):
    """Vérifie qu'un rôle créé dynamiquement (hors des 5 rôles standards)
    peut se voir attribuer des permissions à la carte."""
    headers = _onboard_and_login(client)

    res = client.post("/roles", params={
        "libelle": "coordonnateur_niveau", "description": "Coordination pédagogique",
    }, headers=headers)
    assert res.status_code == 200, res.text
    role = res.json()

    res = client.put(f"/roles/{role['id']}/permissions", json={
        "permission_codes": ["schedule.view", "dashboard.view"],
    }, headers=headers)
    assert res.status_code == 200
    codes = {p["code"] for p in res.json()["permissions"]}
    assert codes == {"schedule.view", "dashboard.view"}


# ===========================================================================
# CLOISONNEMENT MULTI-ÉTABLISSEMENTS
# ===========================================================================
def test_cloisonnement_liste_classes_entre_etablissements(client):
    """Un établissement ne doit jamais voir les classes d'un autre."""
    headers_a = _onboard_and_login(client)
    headers_b = _onboard_and_login(client)

    d_a = _creer_referentiel_complet(client, headers_a)
    client.post("/annees-scolaires", json={"libelle": "2026-2027"}, headers=headers_b)  # étab B a ses propres données

    res_b = client.get("/classes", headers=headers_b)
    assert res_b.status_code == 200
    ids_b = {c["id"] for c in res_b.json()}
    assert d_a["classe"]["id"] not in ids_b


def test_cloisonnement_acces_direct_par_id_refuse(client):
    """Un utilisateur de l'établissement B ne peut pas consulter une
    classe de l'établissement A en devinant son id (404, pas 403, pour
    ne pas confirmer son existence)."""
    headers_a = _onboard_and_login(client)
    headers_b = _onboard_and_login(client)

    d_a = _creer_referentiel_complet(client, headers_a)

    res = client.get(f"/schedules/classe/{d_a['classe']['id']}", headers=headers_b)
    assert res.status_code == 404


def test_cloisonnement_generation_ne_mélange_pas_les_ressources(client):
    """La génération pour l'établissement A ne doit utiliser QUE les
    salles/enseignants de l'établissement A, même si l'établissement B a
    été créé (et peuplé) juste avant dans le même process de test."""
    headers_b = _onboard_and_login(client)
    _creer_referentiel_complet(client, headers_b)  # données de B, créées AVANT celles de A

    headers_a = _onboard_and_login(client)
    d_a = _creer_referentiel_complet(client, headers_a)

    res = client.post(f"/schedules/generate/{d_a['annee']['id']}?mode=sync&max_time_seconds=10", headers=headers_a)
    assert res.status_code == 200, res.text
    rapport = res.json()["report"]
    # Doit réussir à placer les 2 séances de l'établissement A sans être
    # perturbé par l'existence de l'établissement B.
    assert rapport["seances_planifiees"] == 2

    seances = client.get(f"/schedules/classe/{d_a['classe']['id']}", headers=headers_a).json()
    for s in seances:
        assert s["etablissement_id"] == d_a["classe"]["etablissement_id"]


def test_cloisonnement_sauvegarde_ne_contient_que_son_etablissement(client):
    headers_a = _onboard_and_login(client)
    headers_b = _onboard_and_login(client)
    d_a = _creer_referentiel_complet(client, headers_a)
    _creer_referentiel_complet(client, headers_b)

    res = client.post("/admin/backup", headers=headers_a)
    assert res.status_code == 200
    payload = res.json()
    classes_sauvegardees = payload["tables"]["classes"]
    assert len(classes_sauvegardees) == 1
    assert classes_sauvegardees[0]["libelle"] == d_a["classe"]["libelle"]


# ===========================================================================
# PAGINATION
# ===========================================================================
def test_pagination_enseignants_avec_x_total_count(client):
    headers = _onboard_and_login(client)
    matiere = client.post("/matieres", json={"libelle": "Mathématiques", "code": "MATH"}, headers=headers).json()
    for i in range(5):
        client.post("/enseignants", json={
            "nom": f"Prof{i}", "prenom": "Test", "matiere_ids": [matiere["id"]],
        }, headers=headers)

    res = client.get("/enseignants?limit=2", headers=headers)
    assert res.status_code == 200
    assert len(res.json()) == 2
    assert res.headers["x-total-count"] == "5"

    res_page_2 = client.get("/enseignants?skip=2&limit=2", headers=headers)
    assert len(res_page_2.json()) == 2
    assert {e["id"] for e in res.json()}.isdisjoint({e["id"] for e in res_page_2.json()})
