"""
Tests du moteur de génération — app/engine.py

⚠️ Ces tests nécessitent le paquet `ortools` installé (voir requirements.txt).
Ils n'ont pas pu être exécutés dans l'environnement de rédaction de ce
projet (absence d'accès réseau pour l'installation des dépendances) :
à lancer avec `pytest tests/test_engine.py -v` dans votre environnement.
"""
import pytest

from app import models, conflicts
from app.engine import generate_schedule


def test_generation_place_toutes_les_seances_cas_simple(db_session, donnees_base):
    d = donnees_base
    rapport = generate_schedule(db_session, d["annee"].id, max_time_seconds=20)

    assert rapport["status"] in ("OPTIMAL", "FEASIBLE")
    # 2 séances de maths + 1 séance de PC = 3 séances à placer
    assert rapport["seances_totales"] == 3
    assert rapport["seances_planifiees"] == 3


def test_generation_respecte_les_contraintes_dures(db_session, donnees_base):
    d = donnees_base
    generate_schedule(db_session, d["annee"].id, max_time_seconds=20)

    seances = db_session.query(models.EmploiDuTemps).filter(
        models.EmploiDuTemps.annee_scolaire_id == d["annee"].id
    ).all()

    # Aucune séance ne doit présenter de conflit bloquant après génération
    resultats = conflicts.scanner_conflits_annee(db_session, d["annee"].id)
    bloquants = [
        r for r in resultats
        if any(c["gravite"] == "bloquant" for c in r["conflits"])
    ]
    assert bloquants == []

    # La séance de Physique-Chimie doit être placée dans le laboratoire (salle spécialisée)
    seance_pc = next(s for s in seances if s.matiere_id == d["pc"].id)
    assert seance_pc.salle_id == d["salle_labo"].id


def test_generation_infeasible_si_aucun_enseignant_habilite(db_session, donnees_base):
    d = donnees_base
    # On retire l'habilitation du professeur de PC : plus aucun enseignant
    # n'est en mesure de dispenser cette matière.
    d["prof_pc"].matieres = []
    db_session.commit()

    rapport = generate_schedule(db_session, d["annee"].id, max_time_seconds=10)

    assert rapport["status"] == "INFEASIBLE"
    assert rapport["seances_planifiees"] == 0
    assert "habilité" in rapport["message"].lower()


def test_generation_sans_donnees_retourne_infeasible(db_session, etablissement):
    """Aucune classe / volume horaire en base -> message explicite, pas de crash."""
    annee = models.AnneeScolaire(etablissement_id=etablissement.id, libelle="2099-2100")
    db_session.add(annee)
    db_session.commit()

    rapport = generate_schedule(db_session, annee.id, max_time_seconds=5)
    assert rapport["status"] == "INFEASIBLE"
    assert rapport["seances_planifiees"] == 0
