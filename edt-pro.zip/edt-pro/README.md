# EDT-Pro — Projet complet

Implémentation intégrale du cahier des charges : API REST sécurisée
(JWT + permissions granulaires), **multi-établissements** (cloisonnement
strict des données par école), moteur de génération automatique
(OR-Tools CP-SAT) synchrone **et asynchrone** (Redis/RQ), édition
manuelle par **glisser-déposer natif** avec détection de conflits,
exports PDF/Excel, tableau de bord, sauvegarde/restauration
automatisées, versions **web, desktop et mobile**, tests automatisés, et
optimisations de performance validées pour les grands établissements
(200+ enseignants — voir la section [Performance à grande échelle](#performance-à-grande-échelle-200-enseignants)).

## Arborescence

> 🚀 **Déploiement en production sur un VPS Ubuntu avec nom de domaine** :
> voir le guide complet [`DEPLOYMENT.md`](./DEPLOYMENT.md) (Docker, Nginx,
> HTTPS via Let's Encrypt, sauvegardes, mise à jour).

```
edt-pro/
├── backend/
│   ├── app/
│   │   ├── main.py               # API FastAPI (tous les endpoints)
│   │   ├── models.py              # Modèle de données multi-établissements + index de perf
│   │   ├── schemas.py             # Schémas Pydantic (dont onboarding d'établissement)
│   │   ├── auth.py                # JWT, RBAC + permissions à la carte
│   │   ├── permissions_catalog.py # Catalogue des permissions, rôles standards & onboarding
│   │   ├── conflicts.py            # Détection de conflits (édition manuelle)
│   │   ├── exports.py              # Génération PDF (ReportLab) / Excel (OpenPyXL)
│   │   ├── engine.py               # Moteur de génération CP-SAT (OR-Tools)
│   │   ├── queue_config.py          # Connexion Redis / file RQ
│   │   ├── tasks.py                 # Tâche de génération asynchrone
│   │   ├── worker.py                 # Point d'entrée du worker RQ
│   │   ├── notifications.py           # Envoi de notifications push (Expo Push API)
│   │   ├── backup.py                  # Sauvegarde / restauration JSON
│   │   ├── scheduler.py               # Planification des sauvegardes (APScheduler)
│   │   ├── database.py                 # Connexion base de données
│   │   └── seed.py                      # Données de démonstration
│   ├── tests/                            # Tests automatisés (pytest)
│   │   ├── conftest.py
│   │   ├── test_conflicts.py
│   │   ├── test_engine.py
│   │   └── test_api.py
│   ├── requirements.txt
│   ├── requirements-dev.txt
│   ├── pytest.ini
│   └── Dockerfile
├── frontend/
│   └── index.html                  # Interface web : glisser-déposer natif, exports
├── desktop/                          # Application bureau (pywebview)
│   ├── app.py
│   ├── requirements.txt
│   └── README.md
├── mobile/                            # Application mobile (React Native / Expo)
│   ├── App.js
│   ├── screens/                          # Connexion, calendrier EDT, disponibilités
│   ├── services/                          # API + cache hors-ligne + notifications push
│   └── README.md
└── docker-compose.yml                  # API + PostgreSQL + Redis + worker
```

## Démarrage rapide (local, sans Docker)

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

python -m app.seed          # données + comptes de démonstration
uvicorn app.main:app --reload --port 8000
```

Pour la **génération asynchrone**, lancez en plus un worker (processus
séparé, nécessite un serveur Redis local — `redis-server`) :

```bash
python -m app.worker
```

> Sans Redis disponible, l'API bascule automatiquement en génération
> **synchrone** (voir `mode=auto` sur `/schedules/generate/{id}`) —
> pratique en développement, transparent pour l'utilisateur.

Ouvrez `frontend/index.html`, connectez-vous avec un compte de
démonstration, puis **glissez une séance** vers un créneau libre pour la
déplacer (détection de conflits en direct), ou cliquez dessus pour
changer sa matière/enseignant/salle.

## Démarrage avec Docker (stack complète : API + PostgreSQL + Redis + worker)

```bash
docker compose up --build
docker compose exec api python -m app.seed
```

Pour absorber la charge d'un gros établissement, scalez le nombre de
workers :
```bash
docker compose up --scale worker=3
```

## Génération asynchrone (Redis / RQ)

- `POST /schedules/generate/{annee_id}?mode=async` — dépose une tâche
  dans la file RQ, retourne immédiatement un `job_id`.
- `GET /schedules/generate/status/{job_id}` — interroge l'avancement
  (`queued` → `started` → `finished`/`failed`), avec le rapport complet
  une fois terminé.
- `mode=sync` force le mode synchrone (petits établissements) ;
  `mode=auto` (par défaut) bascule automatiquement selon la disponibilité
  de Redis.
- Le frontend (`Générer (async)`) illustre le polling de statut.

## Permissions granulaires (RBAC à la carte)

Le contrôle d'accès repose désormais sur une table `permissions` et une
table d'association `role_permissions`, plutôt que sur des rôles codés
en dur — un administrateur peut composer de nouveaux rôles sans
redéploiement.

- `GET /permissions` — liste le catalogue des permissions
- `GET /roles` — liste les rôles et leurs permissions actuelles
- `POST /roles` — crée un rôle personnalisé (ex. `coordonnateur_niveau`)
- `PUT /roles/{id}/permissions` — définit les permissions d'un rôle

### Catalogue par défaut

| Permission | admin | proviseur | censeur | secrétaire | enseignant |
|---|:---:|:---:|:---:|:---:|:---:|
| `referentiels.manage` | ✅ | ✅ | ❌ | ✅ | ❌ |
| `disponibilites.manage_own` | ✅ | ✅ | ❌ | ✅ | ✅ |
| `disponibilites.manage_all` | ✅ | ✅ | ❌ | ✅ | ❌ |
| `schedule.generate` | ✅ | ✅ | ❌ | ✅ | ❌ |
| `schedule.edit` | ✅ | ✅ | ✅ | ✅ | ❌ |
| `schedule.view` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `dashboard.view` | ✅ | ✅ | ✅ | ✅ | ❌ |
| `exports.use` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `journal.view` | ✅ | ✅ | ❌ | ❌ | ❌ |
| `users.manage` | ✅ | ❌ | ❌ | ❌ | ❌ |
| `roles.manage` | ✅ | ❌ | ❌ | ❌ | ❌ |
| `backup.manage` | ✅ | ❌ | ❌ | ❌ | ❌ |

Voir `app/permissions_catalog.py` pour modifier ces affectations par
défaut (appliquées par `app.seed`).

## Multi-établissements (multi-tenant)

L'application gère **plusieurs établissements sur une même instance**,
avec cloisonnement strict des données.

### Onboarding d'un nouvel établissement

```bash
curl -X POST http://localhost:8000/etablissements/onboard \
  -H "Content-Type: application/json" \
  -d '{
    "etablissement_nom": "Lycée Jean Moulin",
    "etablissement_code": "lycee-jean-moulin",
    "admin_email": "admin@jean-moulin.fr",
    "admin_mot_de_passe": "MotDePasseFort123!",
    "admin_nom": "Dupuis",
    "admin_prenom": "Marie"
  }'
```

Endpoint public (pas d'authentification requise — équivalent d'une
inscription), qui crée l'établissement **et** son premier compte
administrateur en une seule opération. Les comptes suivants se créent
ensuite via `POST /users`, réservé aux administrateurs de CET
établissement. Le script `app.seed` fait cette opération automatiquement
pour l'établissement de démonstration (`lycee-demo`).

### Garanties de cloisonnement

- **Aucun endpoint n'accepte `etablissement_id` en entrée** : il est
  systématiquement dérivé de `current_user.etablissement_id` (le JWT),
  jamais fourni par le client — impossible d'injecter un accès vers un
  autre établissement via le corps d'une requête.
- **Tous les endpoints de lecture exigent une authentification** (ce
  n'était pas le cas avant l'introduction du multi-tenant : les
  référentiels et emplois du temps étaient techniquement accessibles
  sans token — c'est corrigé).
- **Accès par identifiant** (`GET/PUT/DELETE .../{id}`) : vérifié via
  `get_owned_or_404()` dans `app/main.py`, qui renvoie **404** (jamais
  403) si la ressource appartient à un autre établissement — pour ne
  jamais confirmer son existence à un tiers.
- **Moteur de génération, exports, sauvegarde/restauration** : chacun a
  fait l'objet d'un audit spécifique (voir `app/engine.py`,
  `app/exports.py`, `app/backup.py`) — ces modules interrogeaient
  auparavant certains référentiels (salles, enseignants, créneaux) sans
  filtre, ce qui aurait mélangé les données de plusieurs établissements
  dès l'ajout de la table `etablissements`. Corrigé et couvert par des
  tests dédiés (`tests/test_api.py::test_cloisonnement_*`).

### Ce qui reste global (partagé entre tous les établissements)

`Role`, `Permission` et `role_permissions` sont des tables **globales**,
pas cloisonnées par établissement : la taxonomie RBAC (les 5 rôles
standards + le catalogue de permissions) est partagée par toute la
plateforme, pour des raisons de simplicité. Concrètement :
- Un rôle personnalisé créé par un établissement (`POST /roles`) est
  visible et réutilisable par les administrateurs des autres
  établissements.
- Cette limite est assumée pour ce MVP ; une évolution possible consiste
  à ajouter un `etablissement_id` nullable sur `Role` (NULL = rôle
  système partagé, non-NULL = rôle propre à un établissement) — non
  implémenté ici pour rester dans un périmètre raisonnable.

### Migration d'une base existante (mono-établissement → multi)

Ce projet utilise `Base.metadata.create_all()` (création de schéma
simple, pas de véritable système de migration) — adapté à un démarrage
from scratch. **Si vous avez déjà des données en production** issues
d'une version antérieure mono-établissement, une migration est
nécessaire pour leur assigner un `etablissement_id` (colonne désormais
`NOT NULL` sur une douzaine de tables). Recommandation : introduire
[Alembic](https://alembic.sqlalchemy.org/) pour gérer cette transition
(créer l'établissement existant, `UPDATE ... SET etablissement_id = ...`
sur chaque table concernée, puis poser la contrainte `NOT NULL`) plutôt
que de le faire à la main en SQL.

## Performance à grande échelle (200+ enseignants)

Deux limites identifiées lors d'un audit dédié ont été corrigées :

### 1. Requêtes N+1 dans la détection de conflits

`app/conflicts.py::scanner_conflits_annee` (utilisé par le scan de
conflits et par le tableau de bord) appelait auparavant
`detecter_conflits` **séance par séance**, soit ~6 requêtes SQL par
séance — pour un établissement avec ~900 séances/semaine (200
enseignants), cela représentait plusieurs milliers de requêtes à chaque
appel. La version actuelle charge l'intégralité des référentiels
nécessaires en **6 requêtes fixes au total**, quel que soit le nombre de
séances, puis effectue toute la détection en mémoire (dictionnaires
indexés par `(ressource, créneau)`).

### 2. Index de base de données

Ajoutés dans `app/models.py` sur les colonnes systématiquement filtrées :
- `etablissement_id` sur toutes les tables multi-tenant
- `(enseignant_id, creneau_id)`, `(salle_id, creneau_id)`,
  `(classe_id, creneau_id)` sur `emplois_du_temps` — utilisés par le
  scan de conflits et les contrôles de double-réservation
- `(enseignant_id, creneau_id, type)` sur `disponibilites` — utilisé par
  le moteur de génération pour construire l'ensemble des indisponibilités

### 3. Pagination

Les listes potentiellement volumineuses (`/enseignants`, `/classes`,
`/users`, `/schedules/{annee_scolaire_id}`) acceptent désormais
`skip`/`limit` (défaut 200, plafonné à 1000) et exposent le total exact
via l'en-tête `X-Total-Count` — le corps de la réponse reste un tableau
simple (pas de changement de format, pour ne pas casser les clients déjà
construits sur ce projet — frontend web, app mobile).

```bash
curl -i "http://localhost:8000/enseignants?skip=0&limit=50" -H "Authorization: Bearer $TOKEN"
# X-Total-Count: 214
```

### Ce qui n'a volontairement pas été fait

- Pas de cache applicatif (Redis n'est utilisé que pour la file de
  génération) : les listes de référentiels sont relues à chaque requête.
  Pour un établissement de 200 enseignants, le volume de données reste
  trop faible pour que ce soit nécessaire — à réévaluer avec des mesures
  réelles avant d'ajouter cette complexité.
- Pas de tests de charge automatisés (ex. Locust) inclus dans ce livrable
  — recommandé avant une mise en production sur un grand établissement,
  avec un jeu de données représentatif (200 enseignants, 40+ classes).

## Notifications push (backend)

- `POST /notifications/register-token` — enregistre le token Expo Push
  de l'utilisateur connecté (appelé par l'app mobile après connexion).
- `DELETE /notifications/unregister-token?token=...` — désinscrit un
  appareil.
- `POST /notifications/reset-badge` — remet à zéro le compteur `badge_count`
  de l'utilisateur connecté (appelé par l'app mobile à la consultation de
  son emploi du temps).
- Déclenchées automatiquement (`app/notifications.py`) lors de la
  création, modification, suppression ou échange d'une séance, et à
  l'issue d'une génération automatique (mode synchrone) — chaque
  enseignant concerné reçoit une notification sur ses appareils
  enregistrés. Échoue silencieusement (journalisé) si le service Expo
  est indisponible, sans jamais bloquer l'opération métier.
- Le badge de l'icône mobile est **piloté côté serveur** : `badge_count`
  (table `utilisateurs`) est incrémenté à chaque notification envoyée et
  transmis dans le payload push, plutôt qu'un comptage purement local —
  cela garantit un badge correct même si l'app était fermée.

## Sauvegarde & restauration

- **Automatique** : une sauvegarde JSON est déclenchée chaque nuit à
  02h00 (configurable via `BACKUP_SCHEDULE_HOUR`) **pour chaque
  établissement actif de la plateforme séparément**, avec purge
  au-delà de 30 sauvegardes conservées par établissement
  (`BACKUP_RETENTION_COUNT`). Démarré automatiquement à l'événement
  `startup` de l'API (`app/scheduler.py`).
- **Manuelle** : `POST /admin/backup` déclenche une sauvegarde immédiate
  des données de **votre établissement uniquement** et retourne le
  fichier à télécharger ; `GET /admin/backups` liste les sauvegardes de
  votre établissement disponibles sur le serveur.
- **Restauration** : `POST /admin/restore` (upload du fichier JSON)
  remplace les données de **votre établissement uniquement** — opération
  destructive, réservée à la permission `backup.manage`. Refuse
  explicitement (403) si le fichier fourni appartient à un autre
  établissement (protection contre une restauration croisée).
- Format portable JSON (SQLite ↔ PostgreSQL). Pour une sauvegarde binaire
  complète en production PostgreSQL, `pg_dump`/`pg_restore` restent
  recommandés en complément.

## Édition manuelle par glisser-déposer

L'interface web (`frontend/index.html`) utilise l'API **HTML5 Drag and
Drop** native (`draggable`, `dragstart`/`dragover`/`drop`) :

- Glisser une séance vers un **créneau libre** → déplacement immédiat,
  avec validation des conflits côté serveur avant enregistrement (si
  conflits bloquants, une confirmation permet de forcer le déplacement).
- Glisser une séance vers un **créneau déjà occupé** → **échange
  (swap)** automatique des deux séances (chacune reprend le créneau de
  l'autre), avec la même validation de conflits pour les deux séances
  simultanément. `POST /schedules/seance/swap`.
- Cliquer sur une séance → modale permettant de changer matière,
  enseignant ou salle, avec affichage en direct des conflits
  bloquants/avertissements, et bouton de verrouillage (🔒) pour
  préserver la séance lors d'une régénération automatique ultérieure.

## Exports

- `GET /exports/pdf/classe/{classe_id}` / `/exports/pdf/enseignant/{id}`
- `GET /exports/excel/{annee_scolaire_id}` — classeur multi-feuilles

## Versions desktop et mobile

- **Desktop** (`desktop/`) : application bureau autonome (pywebview),
  base SQLite locale, fonctionnement 100% hors-ligne, packageable en
  exécutable via PyInstaller. Voir `desktop/README.md`.
- **Mobile** (`mobile/`) : application React Native (Expo), périmètre
  volontairement réduit (consultation de son EDT + déclaration de
  disponibilités), composants natifs (pas de WebView). Inclut :
  **notifications push** (Expo Notifications, déclenchées par le backend
  à chaque changement de créneau), **mode hors-ligne** (cache local +
  file de synchronisation automatique via AsyncStorage/NetInfo), et une
  **vue calendrier native** (react-native-calendars) plutôt qu'une simple
  liste. Voir `mobile/README.md`.

## Tests automatisés

```bash
cd backend
pip install -r requirements-dev.txt
pytest -v
```

- `tests/test_conflicts.py` — tests unitaires de la détection de
  conflits (double réservation enseignant/salle/classe, indisponibilité,
  compatibilité de salle, exclusion de la séance en cours d'édition).
- `tests/test_engine.py` — tests du moteur CP-SAT (placement complet sur
  un cas simple, respect des contraintes dures, cas infaisable explicite).
- `tests/test_api.py` — tests d'intégration (onboarding d'établissement,
  authentification, permissions granulaires, parcours complet jusqu'à la
  génération, échange de deux séances, création de rôle personnalisé,
  **cloisonnement multi-établissements** — un établissement ne voit
  jamais les données d'un autre, ni par liste ni par accès direct par id,
  ni via une sauvegarde —, et **pagination** avec vérification de
  l'en-tête `X-Total-Count`).

Chaque test utilise une base SQLite **en mémoire**, isolée et
reconstruite à chaque test (fixture `db_session` dans `conftest.py`).

## Vérification technique de cette livraison

Tous les fichiers Python (backend + tests + desktop) ont été vérifiés
syntaxiquement (`py_compile`), ainsi que le JavaScript du frontend
(`node --check`). **Ce sandbox ne dispose pas d'accès réseau** pour
installer les dépendances (`fastapi`, `ortools`, `redis`, `rq`,
`apscheduler`, `pytest`, npm packages mobiles, etc.) et exécuter le
projet ou la suite de tests de bout en bout — merci de les lancer dans
votre environnement (`pytest -v` en particulier) et de signaler toute
anomalie pour correction immédiate.

## Ce qu'il reste pour une version production complète

- Gestion des vacances/jours fériés et des périodes d'examens (modèles
  `vacances`/`examens` du cahier des charges, non encore implémentés)
- Synchronisation offline/online pour la version desktop (actuellement
  mono-poste, base locale indépendante)
- Notifications push mobile lors d'un changement d'emploi du temps
- CI/CD (GitHub Actions) exécutant `pytest` et le linting à chaque
  pull request
