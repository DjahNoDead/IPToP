/**
 * Configuration globale exécutée avant chaque fichier de test.
 *
 * Les modules natifs (AsyncStorage, NetInfo, expo-notifications,
 * expo-device, expo-constants) n'ont pas d'implémentation JS pure
 * utilisable telle quelle sous Jest (environnement Node, pas de VM
 * iOS/Android) : on les remplace par des mocks en mémoire, suffisants
 * pour tester la logique métier de nos services (api.js, storage.js,
 * notifications.js) indépendamment du runtime natif.
 */

// --- AsyncStorage : mock officiel en mémoire fourni par le package ---
jest.mock("@react-native-async-storage/async-storage", () =>
  require("@react-native-async-storage/async-storage/jest/async-storage-mock")
);

// --- expo-notifications ---
jest.mock("expo-notifications", () => ({
  setNotificationHandler: jest.fn(),
  setNotificationChannelAsync: jest.fn(() => Promise.resolve()),
  getPermissionsAsync: jest.fn(() => Promise.resolve({ status: "granted" })),
  requestPermissionsAsync: jest.fn(() => Promise.resolve({ status: "granted" })),
  getExpoPushTokenAsync: jest.fn(() => Promise.resolve({ data: "ExponentPushToken[test-token]" })),
  setBadgeCountAsync: jest.fn(() => Promise.resolve(true)),
  getBadgeCountAsync: jest.fn(() => Promise.resolve(0)),
  addNotificationReceivedListener: jest.fn(() => ({ remove: jest.fn() })),
  addNotificationResponseReceivedListener: jest.fn(() => ({ remove: jest.fn() })),
  AndroidImportance: { DEFAULT: 3 },
}));

// --- expo-device : simule un appareil physique par défaut (les tests
// de refus sur simulateur redéfinissent isDevice localement) ---
jest.mock("expo-device", () => ({ isDevice: true }));

// --- expo-constants ---
jest.mock("expo-constants", () => ({
  expoConfig: { extra: { eas: { projectId: "test-project-id" } } },
}));

// --- @react-native-community/netinfo ---
jest.mock("@react-native-community/netinfo", () => ({
  addEventListener: jest.fn(() => jest.fn()),
  fetch: jest.fn(() => Promise.resolve({ isConnected: true })),
}));

// --- fetch global : chaque test redéfinit son propre comportement via
// global.fetch = jest.fn(...), ceci n'est qu'un filet de sécurité pour
// éviter un throw "fetch is not defined" si un test l'oublie ---
if (!global.fetch) {
  global.fetch = jest.fn(() =>
    Promise.reject(new Error("global.fetch non mocké pour ce test"))
  );
}
