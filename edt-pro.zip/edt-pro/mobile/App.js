/**
 * EDT-Pro Mobile — application React Native (Expo).
 *
 * Périmètre volontairement limité, conformément au cahier des charges
 * (section Déploiement) : consultation de son propre emploi du temps
 * (vue calendrier native), déclaration de ses disponibilités. L'édition
 * manuelle avancée et la génération automatique restent réservées aux
 * interfaces web/desktop.
 *
 * Fonctionnalités transverses assemblées ici :
 * - Notifications push (Expo Notifications) : enregistrement du token à
 *   la connexion, écoute des notifications reçues/tapées pour rafraîchir
 *   automatiquement l'écran d'emploi du temps concerné.
 * - Mode hors-ligne : cache local (AsyncStorage, voir services/storage.js)
 *   et file d'attente de synchronisation (voir services/api.js),
 *   rejouée automatiquement au retour de connectivité.
 * - Vue calendrier native (react-native-calendars) plutôt qu'une simple
 *   liste, avec bascule vers une vue "Semaine" compacte — voir
 *   screens/ScheduleCalendarScreen.js.
 * - Badge sur l'icône de l'app : piloté par le serveur (compteur par
 *   utilisateur, transmis dans le payload push), remis à 0 à la
 *   consultation de l'écran d'emploi du temps.
 * - Arbitrage des conflits de synchronisation hors-ligne — voir
 *   screens/SyncConflictsScreen.js.
 */
import React, { useEffect, useRef } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import LoginScreen from "./screens/LoginScreen";
import ScheduleCalendarScreen from "./screens/ScheduleCalendarScreen";
import DisponibilitesScreen from "./screens/DisponibilitesScreen";
import SyncConflictsScreen from "./screens/SyncConflictsScreen";
import {
  configurerGestionnaireNotifications,
  ecouterNotifications,
} from "./services/notifications";

const Stack = createNativeStackNavigator();

export default function App() {
  const navigationRef = useRef(null);

  useEffect(() => {
    configurerGestionnaireNotifications();

    // Une notification reçue ou tapée (changement d'emploi du temps,
    // régénération) ramène l'utilisateur sur son EDT, qui se rechargera
    // automatiquement (voir ScheduleCalendarScreen::charger) et remettra
    // le badge à zéro (useFocusEffect -> reinitialiserBadge).
    const desabonner = ecouterNotifications(
      () => {}, // notification reçue app ouverte : gérée par le handler global (bannière système)
      (data) => {
        if (navigationRef.current && data?.type) {
          navigationRef.current.navigate("EmploiDuTemps");
        }
      }
    );
    return desabonner;
  }, []);

  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="EmploiDuTemps" component={ScheduleCalendarScreen} />
        <Stack.Screen
          name="Disponibilites"
          component={DisponibilitesScreen}
          options={{ headerShown: true, title: "Disponibilités" }}
        />
        <Stack.Screen
          name="SyncConflicts"
          component={SyncConflictsScreen}
          options={{ headerShown: true, title: "Conflits de synchronisation" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
