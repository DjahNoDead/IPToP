import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  apiFetch, apiGetCached, apiMutateOrQueue, traiterFileAttente,
  reessayerConflit, ignorerConflit,
} from "../services/api";
import { obtenirFileAttente, obtenirConflits, mettreEnCache } from "../services/storage";

const API_BASE_URL = "http://localhost:8000"; // valeur de mobile/config.js

/** Construit un objet Response minimal, suffisant pour nos usages. */
function reponse(status, corpsJson) {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => corpsJson,
  };
}

beforeEach(async () => {
  await AsyncStorage.clear();
  await AsyncStorage.setItem("access_token", "token-valide");
  await AsyncStorage.setItem("refresh_token", "refresh-valide");
  global.fetch = jest.fn();
});

describe("apiFetch", () => {
  test("transmet le token d'accès dans l'en-tête Authorization", async () => {
    global.fetch.mockResolvedValueOnce(reponse(200, { ok: true }));

    await apiFetch("/creneaux");

    expect(global.fetch).toHaveBeenCalledWith(
      `${API_BASE_URL}/creneaux`,
      expect.objectContaining({ headers: expect.objectContaining({ Authorization: "Bearer token-valide" }) })
    );
  });

  test("rafraîchit le token et rejoue la requête après un 401", async () => {
    global.fetch
      .mockResolvedValueOnce(reponse(401, {}))                                   // 1er appel : rejeté
      .mockResolvedValueOnce(reponse(200, { access_token: "nouveau-token" }))     // /auth/refresh
      .mockResolvedValueOnce(reponse(200, { ok: true }));                        // rejeu avec le nouveau token

    const res = await apiFetch("/creneaux");

    expect(res.ok).toBe(true);
    expect(global.fetch).toHaveBeenNthCalledWith(
      3, `${API_BASE_URL}/creneaux`,
      expect.objectContaining({ headers: expect.objectContaining({ Authorization: "Bearer nouveau-token" }) })
    );
    expect(await AsyncStorage.getItem("access_token")).toBe("nouveau-token");
  });

  test("lève SESSION_EXPIREE si le rafraîchissement échoue aussi", async () => {
    global.fetch
      .mockResolvedValueOnce(reponse(401, {}))
      .mockResolvedValueOnce(reponse(401, {})); // /auth/refresh échoue également

    await expect(apiFetch("/creneaux")).rejects.toThrow("SESSION_EXPIREE");
  });
});

describe("apiGetCached", () => {
  test("succès réseau : renvoie les données et met à jour le cache", async () => {
    global.fetch.mockResolvedValueOnce(reponse(200, [{ id: 1 }]));

    const resultat = await apiGetCached("/creneaux", "creneaux");

    expect(resultat.horsLigne).toBe(false);
    expect(resultat.data).toEqual([{ id: 1 }]);
  });

  test("échec réseau avec cache disponible : renvoie le cache et horsLigne=true", async () => {
    await mettreEnCache("creneaux", [{ id: 99, jour: "Vendredi" }]);
    global.fetch.mockRejectedValueOnce(new Error("Network request failed"));

    const resultat = await apiGetCached("/creneaux", "creneaux");

    expect(resultat.horsLigne).toBe(true);
    expect(resultat.data).toEqual([{ id: 99, jour: "Vendredi" }]);
  });

  test("échec réseau sans cache disponible : propage l'erreur", async () => {
    global.fetch.mockRejectedValueOnce(new Error("Network request failed"));

    await expect(apiGetCached("/creneaux", "cle_jamais_mise_en_cache")).rejects.toThrow();
  });
});

describe("apiMutateOrQueue", () => {
  test("succès réseau : envoyeImmediatement=true, rien en file", async () => {
    global.fetch.mockResolvedValueOnce(reponse(201, { id: 1 }));

    const resultat = await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 });

    expect(resultat.envoyeImmediatement).toBe(true);
    expect(await obtenirFileAttente()).toHaveLength(0);
  });

  test("échec réseau : mise en file avec envoyeImmediatement=false", async () => {
    global.fetch.mockRejectedValueOnce(new Error("Network request failed"));

    const resultat = await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 });

    expect(resultat.envoyeImmediatement).toBe(false);
    const file = await obtenirFileAttente();
    expect(file).toHaveLength(1);
    expect(file[0].path).toBe("/disponibilites");
  });

  test("erreur serveur (5xx) : traitée comme un échec réseau, mise en file", async () => {
    global.fetch.mockResolvedValueOnce(reponse(503, {}));

    const resultat = await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 });

    expect(resultat.envoyeImmediatement).toBe(false);
    expect(await obtenirFileAttente()).toHaveLength(1);
  });

  test("le contexte fourni est conservé dans l'action mise en file", async () => {
    global.fetch.mockRejectedValueOnce(new Error("Network request failed"));

    await apiMutateOrQueue(
      "POST", "/disponibilites", { creneau_id: 1 },
      { jour: "Lundi", heure_debut: "08:00" }
    );

    const [action] = await obtenirFileAttente();
    expect(action.contexte).toEqual({ jour: "Lundi", heure_debut: "08:00" });
  });
});

describe("traiterFileAttente", () => {
  test("action acceptée (2xx) : retirée de la file, comptée en succès", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 }); // échoue faute de réseau -> mise en file

    global.fetch.mockResolvedValueOnce(reponse(200, { ok: true }));

    const resultat = await traiterFileAttente();

    expect(resultat.succes).toBe(1);
    expect(resultat.conflits).toBe(0);
    expect(await obtenirFileAttente()).toHaveLength(0);
  });

  test("conflit définitif (409, sans contexte exploitable) : déplacé vers les conflits", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 }); // pas de contexte fourni ici

    global.fetch.mockResolvedValueOnce(
      reponse(409, { detail: "Créneau déjà indisponible pour cet enseignant" })
    );

    const resultat = await traiterFileAttente();

    expect(resultat.succes).toBe(0);
    expect(resultat.conflits).toBe(1);
    expect(await obtenirFileAttente()).toHaveLength(0);

    const conflits = await obtenirConflits();
    expect(conflits).toHaveLength(1);
    expect(conflits[0].messageErreur).toBe("Créneau déjà indisponible pour cet enseignant");
  });

  test("erreur transitoire (5xx) : action laissée en file, boucle interrompue", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 });

    global.fetch.mockRejectedValueOnce(new Error("Network request failed"));

    const resultat = await traiterFileAttente();

    expect(resultat.succes).toBe(0);
    expect(resultat.conflits).toBe(0);
    expect(await obtenirFileAttente()).toHaveLength(1); // toujours là, retentée plus tard
    expect(await obtenirConflits()).toHaveLength(0);
  });

  test("404 avec contexte jour/heure correspondant à un nouveau créneau : résolution automatique", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue(
      "POST", "/disponibilites", { enseignant_id: 1, creneau_id: 42, type: "indisponible" },
      { jour: "Lundi", heure_debut: "08:00" }
    );

    // Rejeu : le créneau #42 n'existe plus (404)...
    global.fetch.mockResolvedValueOnce(reponse(404, { detail: "Créneau introuvable" }));
    // ...mais /creneaux renvoie un créneau équivalent (même jour/heure, nouvel id 99)...
    global.fetch.mockResolvedValueOnce(reponse(200, [
      { id: 99, jour: "Lundi", heure_debut: "08:00", heure_fin: "09:00" },
      { id: 100, jour: "Mardi", heure_debut: "09:00", heure_fin: "10:00" },
    ]));
    // ...et la nouvelle tentative avec creneau_id=99 réussit.
    global.fetch.mockResolvedValueOnce(reponse(200, { ok: true }));

    const resultat = await traiterFileAttente();

    expect(resultat.succes).toBe(1);
    expect(resultat.resolusAutomatiquement).toBe(1);
    expect(resultat.conflits).toBe(0);
    expect(await obtenirFileAttente()).toHaveLength(0);
    expect(await obtenirConflits()).toHaveLength(0);

    // Vérifie que la requête de résolution a bien utilisé le nouvel identifiant
    const dernierAppel = global.fetch.mock.calls[global.fetch.mock.calls.length - 1];
    expect(JSON.parse(dernierAppel[1].body).creneau_id).toBe(99);
  });

  test("404 sans créneau équivalent trouvé : bascule en conflit manuel", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue(
      "POST", "/disponibilites", { enseignant_id: 1, creneau_id: 42, type: "indisponible" },
      { jour: "Lundi", heure_debut: "08:00" }
    );

    global.fetch.mockResolvedValueOnce(reponse(404, { detail: "Créneau introuvable" }));
    global.fetch.mockResolvedValueOnce(reponse(200, [
      { id: 100, jour: "Mardi", heure_debut: "09:00", heure_fin: "10:00" }, // aucun Lundi 08:00
    ]));

    const resultat = await traiterFileAttente();

    expect(resultat.succes).toBe(0);
    expect(resultat.resolusAutomatiquement).toBe(0);
    expect(resultat.conflits).toBe(1);
    expect(await obtenirConflits()).toHaveLength(1);
  });
});

describe("Résolution manuelle des conflits (SyncConflictsScreen)", () => {
  test("reessayerConflit remet l'action en file active", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 });
    global.fetch.mockResolvedValueOnce(reponse(409, { detail: "conflit" }));
    await traiterFileAttente();

    const [conflit] = await obtenirConflits();
    await reessayerConflit(conflit);

    expect(await obtenirFileAttente()).toHaveLength(1);
    expect(await obtenirConflits()).toHaveLength(0);
  });

  test("ignorerConflit écarte définitivement le conflit", async () => {
    global.fetch.mockRejectedValueOnce(new Error("offline"));
    await apiMutateOrQueue("POST", "/disponibilites", { creneau_id: 1 });
    global.fetch.mockResolvedValueOnce(reponse(409, { detail: "conflit" }));
    await traiterFileAttente();

    const [conflit] = await obtenirConflits();
    await ignorerConflit(conflit.id);

    expect(await obtenirConflits()).toHaveLength(0);
    expect(await obtenirFileAttente()).toHaveLength(0);
  });
});
