import * as Notifications from "expo-notifications";
import * as Device from "expo-device";

jest.mock("../services/api", () => ({
  apiFetch: jest.fn(),
}));
import { apiFetch } from "../services/api";

import {
  configurerGestionnaireNotifications,
  enregistrerPourNotifications,
  desenregistrerNotifications,
  reinitialiserBadge,
  ecouterNotifications,
} from "../services/notifications";

beforeEach(() => {
  jest.clearAllMocks();
  Device.isDevice = true;
});

describe("configurerGestionnaireNotifications", () => {
  test("définit un gestionnaire de notification sans lever d'exception", () => {
    expect(() => configurerGestionnaireNotifications()).not.toThrow();
  });
});

describe("enregistrerPourNotifications", () => {
  test("retourne null sur simulateur/émulateur (Device.isDevice=false)", async () => {
    Device.isDevice = false;

    const token = await enregistrerPourNotifications();

    expect(token).toBeNull();
    expect(Notifications.getExpoPushTokenAsync).not.toHaveBeenCalled();
    expect(apiFetch).not.toHaveBeenCalled();
  });

  test("retourne null si la permission est refusée", async () => {
    Notifications.getPermissionsAsync.mockResolvedValueOnce({ status: "denied" });
    Notifications.requestPermissionsAsync.mockResolvedValueOnce({ status: "denied" });

    const token = await enregistrerPourNotifications();

    expect(token).toBeNull();
    expect(apiFetch).not.toHaveBeenCalled();
  });

  test("permission accordée : récupère le token et l'enregistre côté backend", async () => {
    Notifications.getPermissionsAsync.mockResolvedValueOnce({ status: "granted" });
    Notifications.getExpoPushTokenAsync.mockResolvedValueOnce({ data: "ExponentPushToken[abc]" });
    apiFetch.mockResolvedValueOnce({ ok: true });

    const token = await enregistrerPourNotifications();

    expect(token).toBe("ExponentPushToken[abc]");
    expect(apiFetch).toHaveBeenCalledWith(
      "/notifications/register-token",
      expect.objectContaining({
        method: "POST",
        body: expect.stringContaining("ExponentPushToken[abc]"),
      })
    );
  });

  test("permission non accordée d'emblée mais accordée après la demande : récupère quand même le token", async () => {
    Notifications.getPermissionsAsync.mockResolvedValueOnce({ status: "undetermined" });
    Notifications.requestPermissionsAsync.mockResolvedValueOnce({ status: "granted" });
    Notifications.getExpoPushTokenAsync.mockResolvedValueOnce({ data: "ExponentPushToken[xyz]" });
    apiFetch.mockResolvedValueOnce({ ok: true });

    const token = await enregistrerPourNotifications();

    expect(token).toBe("ExponentPushToken[xyz]");
  });

  test("l'échec de l'enregistrement côté backend n'empêche pas de retourner le token", async () => {
    Notifications.getPermissionsAsync.mockResolvedValueOnce({ status: "granted" });
    Notifications.getExpoPushTokenAsync.mockResolvedValueOnce({ data: "ExponentPushToken[abc]" });
    apiFetch.mockRejectedValueOnce(new Error("hors-ligne"));

    const token = await enregistrerPourNotifications();

    expect(token).toBe("ExponentPushToken[abc]"); // le token local reste valide même si le serveur est injoignable
  });
});

describe("desenregistrerNotifications", () => {
  test("appelle l'endpoint de désinscription avec le token encodé", async () => {
    apiFetch.mockResolvedValueOnce({ ok: true });

    await desenregistrerNotifications("ExponentPushToken[abc def]");

    expect(apiFetch).toHaveBeenCalledWith(
      expect.stringContaining("/notifications/unregister-token?token="),
      expect.objectContaining({ method: "DELETE" })
    );
  });

  test("ne fait rien si aucun token n'est fourni", async () => {
    await desenregistrerNotifications(null);
    expect(apiFetch).not.toHaveBeenCalled();
  });

  test("n'échoue pas si l'appel réseau échoue (best effort)", async () => {
    apiFetch.mockRejectedValueOnce(new Error("hors-ligne"));
    await expect(desenregistrerNotifications("token")).resolves.not.toThrow();
  });
});

describe("reinitialiserBadge", () => {
  test("remet le badge à 0 localement et informe le serveur", async () => {
    apiFetch.mockResolvedValueOnce({ ok: true });

    await reinitialiserBadge();

    expect(Notifications.setBadgeCountAsync).toHaveBeenCalledWith(0);
    expect(apiFetch).toHaveBeenCalledWith("/notifications/reset-badge", expect.objectContaining({ method: "POST" }));
  });

  test("ne lève pas d'exception si le serveur est injoignable (badge déjà à 0 localement)", async () => {
    apiFetch.mockRejectedValueOnce(new Error("hors-ligne"));

    await expect(reinitialiserBadge()).resolves.not.toThrow();
    expect(Notifications.setBadgeCountAsync).toHaveBeenCalledWith(0);
  });
});

describe("ecouterNotifications", () => {
  test("transmet les données de la notification reçue à onRecue", () => {
    let callbackEnregistre;
    Notifications.addNotificationReceivedListener.mockImplementationOnce((cb) => {
      callbackEnregistre = cb;
      return { remove: jest.fn() };
    });

    const onRecue = jest.fn();
    ecouterNotifications(onRecue, jest.fn());

    callbackEnregistre({ request: { content: { data: { type: "schedule_change" } } } });

    expect(onRecue).toHaveBeenCalledWith({ type: "schedule_change" });
  });

  test("transmet les données au tap sur une notification à onTap", () => {
    let callbackEnregistre;
    Notifications.addNotificationResponseReceivedListener.mockImplementationOnce((cb) => {
      callbackEnregistre = cb;
      return { remove: jest.fn() };
    });

    const onTap = jest.fn();
    ecouterNotifications(jest.fn(), onTap);

    callbackEnregistre({ notification: { request: { content: { data: { type: "schedule_regenerated" } } } } });

    expect(onTap).toHaveBeenCalledWith({ type: "schedule_regenerated" });
  });

  test("la fonction de désabonnement retire les deux écouteurs", () => {
    const removeRecue = jest.fn();
    const removeTap = jest.fn();
    Notifications.addNotificationReceivedListener.mockReturnValueOnce({ remove: removeRecue });
    Notifications.addNotificationResponseReceivedListener.mockReturnValueOnce({ remove: removeTap });

    const desabonner = ecouterNotifications(jest.fn(), jest.fn());
    desabonner();

    expect(removeRecue).toHaveBeenCalled();
    expect(removeTap).toHaveBeenCalled();
  });
});
