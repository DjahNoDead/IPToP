import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  mettreEnCache, lireCache, viderCache,
  ajouterAFileAttente, obtenirFileAttente, retirerDeFileAttente, viderFileAttente,
  ajouterConflit, obtenirConflits, retirerConflit,
} from "../services/storage";

beforeEach(async () => {
  await AsyncStorage.clear();
});

describe("Cache local (mettreEnCache / lireCache)", () => {
  test("retourne null si rien n'est en cache", async () => {
    const resultat = await lireCache("cle_inexistante");
    expect(resultat).toBeNull();
  });

  test("mettreEnCache puis lireCache restitue la valeur et un horodatage", async () => {
    await mettreEnCache("creneaux", [{ id: 1, jour: "Lundi" }]);
    const resultat = await lireCache("creneaux");

    expect(resultat).not.toBeNull();
    expect(resultat.valeur).toEqual([{ id: 1, jour: "Lundi" }]);
    expect(typeof resultat.misAJourLe).toBe("string");
    expect(new Date(resultat.misAJourLe).toString()).not.toBe("Invalid Date");
  });

  test("viderCache supprime uniquement la clé ciblée", async () => {
    await mettreEnCache("a", 1);
    await mettreEnCache("b", 2);
    await viderCache("a");

    expect(await lireCache("a")).toBeNull();
    expect((await lireCache("b")).valeur).toBe(2);
  });

  test("des clés de cache distinctes n'interfèrent pas entre elles", async () => {
    await mettreEnCache("matieres", ["Maths"]);
    await mettreEnCache("salles", ["Salle 101"]);

    expect((await lireCache("matieres")).valeur).toEqual(["Maths"]);
    expect((await lireCache("salles")).valeur).toEqual(["Salle 101"]);
  });
});

describe("File d'attente hors-ligne", () => {
  test("la file est vide au départ", async () => {
    expect(await obtenirFileAttente()).toEqual([]);
  });

  test("ajouterAFileAttente attribue un identifiant unique et un horodatage", async () => {
    const file = await ajouterAFileAttente({ method: "POST", path: "/disponibilites", body: { creneau_id: 1 } });

    expect(file).toHaveLength(1);
    expect(file[0].id).toBeTruthy();
    expect(file[0].ajouteLe).toBeTruthy();
    expect(file[0].method).toBe("POST");
    expect(file[0].path).toBe("/disponibilites");
  });

  test("deux actions ajoutées successivement ont des identifiants différents", async () => {
    await ajouterAFileAttente({ method: "POST", path: "/a", body: {} });
    await ajouterAFileAttente({ method: "POST", path: "/b", body: {} });
    const file = await obtenirFileAttente();

    expect(file).toHaveLength(2);
    expect(file[0].id).not.toBe(file[1].id);
  });

  test("retirerDeFileAttente ne retire que l'action ciblée", async () => {
    await ajouterAFileAttente({ method: "POST", path: "/a", body: {} });
    await ajouterAFileAttente({ method: "POST", path: "/b", body: {} });
    const [premiere] = await obtenirFileAttente();

    const restante = await retirerDeFileAttente(premiere.id);

    expect(restante).toHaveLength(1);
    expect(restante[0].path).toBe("/b");
  });

  test("le contexte optionnel (jour/heure) est conservé", async () => {
    await ajouterAFileAttente({
      method: "POST", path: "/disponibilites", body: { creneau_id: 5 },
      contexte: { jour: "Lundi", heure_debut: "08:00" },
    });
    const [action] = await obtenirFileAttente();

    expect(action.contexte).toEqual({ jour: "Lundi", heure_debut: "08:00" });
  });

  test("viderFileAttente vide entièrement la file", async () => {
    await ajouterAFileAttente({ method: "POST", path: "/a", body: {} });
    await viderFileAttente();

    expect(await obtenirFileAttente()).toEqual([]);
  });
});

describe("Conflits de synchronisation", () => {
  test("aucun conflit au départ", async () => {
    expect(await obtenirConflits()).toEqual([]);
  });

  test("ajouterConflit mémorise l'action et le message d'erreur", async () => {
    const action = { id: "abc123", method: "POST", path: "/disponibilites", body: { creneau_id: 9 } };
    const conflits = await ajouterConflit(action, "Créneau introuvable");

    expect(conflits).toHaveLength(1);
    expect(conflits[0].messageErreur).toBe("Créneau introuvable");
    expect(conflits[0].path).toBe("/disponibilites");
    expect(conflits[0].detecteLe).toBeTruthy();
  });

  test("retirerConflit ne retire que le conflit ciblé", async () => {
    await ajouterConflit({ id: "1", method: "POST", path: "/a", body: {} }, "erreur A");
    await ajouterConflit({ id: "2", method: "POST", path: "/b", body: {} }, "erreur B");

    const restants = await retirerConflit("1");

    expect(restants).toHaveLength(1);
    expect(restants[0].id).toBe("2");
  });
});
