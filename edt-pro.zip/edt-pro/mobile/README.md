# EDT-Pro Mobile

Application React Native (Expo), scindée volontairement à un périmètre
réduit conforme au cahier des charges : **consultation de son emploi du
temps** (vue calendrier native) et **déclaration de ses disponibilités**
(avec prise en charge du mode hors-ligne). La génération automatique,
l'édition manuelle et l'administration restent réservées aux interfaces
web et desktop.

## Arborescence

```
mobile/
├── App.js                          # Navigation + notifications
├── config.js                        # Adresse de l'API
├── app.json                          # Config Expo (plugin notifications)
├── package.json
├── jest.config.js                     # (config Jest embarquée dans package.json)
├── jest.setup.js                       # Mocks des modules natifs pour les tests
├── screens/
│   ├── LoginScreen.js                 # Connexion + enregistrement du token push
│   ├── ScheduleCalendarScreen.js       # Vue Agenda/Semaine/Mois + badge + hors-ligne
│   ├── DisponibilitesScreen.js          # Déclaration de disponibilités (hors-ligne)
│   └── SyncConflictsScreen.js             # Arbitrage des conflits de synchronisation
├── components/
│   ├── OfflineBanner.js                  # Bandeau "hors-ligne" / "en attente" / conflits
│   ├── WeekGridView.js                     # Vue Semaine compacte (grille horizontale)
│   └── MonthCalendarView.js                  # Vue Mois (calendrier + détail du jour)
├── services/
│   ├── api.js                              # Client API + cache + file d'attente + auto-résolution
│   ├── storage.js                           # Cache local, file de synchronisation & conflits
│   └── notifications.js                      # Enregistrement / écoute des push Expo + badge
├── utils/
│   └── weekDates.js                            # Projections récurrent → Agenda/Semaine/Mois
└── __tests__/
    ├── storage.test.js                           # Cache, file d'attente, conflits
    ├── api.test.js                                 # Auth, cache réseau, résolution auto/manuelle
    └── notifications.test.js                         # Permissions, token, badge, écouteurs
```

## Fonctionnalités

### 1. Notifications push (Expo Notifications)

À la connexion, l'app demande la permission et enregistre le token Expo
Push auprès du backend (`POST /notifications/register-token`). Le
serveur envoie une notification à l'enseignant concerné à chaque
création, modification, suppression ou échange d'une séance qui le
concerne, ainsi qu'à la fin d'une régénération automatique (voir
`backend/app/notifications.py`). Taper sur une notification ramène
directement sur l'écran d'emploi du temps, qui se recharge
automatiquement.

> Les notifications push ne fonctionnent pas sur simulateur/émulateur —
> testez sur un appareil physique avec l'app **Expo Go**.

### 2. Mode hors-ligne (cache + synchronisation automatique)

- **Lecture** : chaque appel réseau réussi (emploi du temps, créneaux,
  matières, salles) est mis en cache local (AsyncStorage). En l'absence
  de réseau, l'écran affiche automatiquement les dernières données
  connues, avec un bandeau indiquant qu'elles datent d'une consultation
  antérieure.
- **Écriture** : une déclaration de disponibilité effectuée hors-ligne
  est mise en file d'attente locale plutôt que rejetée. Dès que la
  connexion revient (détectée via `@react-native-community/netinfo`),
  la file est rejouée automatiquement contre l'API.
- **Résolution des conflits de synchronisation** : si une action en file
  est rejetée par le serveur au moment du rejeu, une **résolution
  automatique** est d'abord tentée pour le cas le plus fréquent — le
  créneau visé par une disponibilité (404, ex. la grille horaire a été
  régénérée entretemps) : l'app recherche parmi les créneaux actuels
  celui qui correspond toujours au même jour/heure et rejoue l'action
  avec son nouvel identifiant, sans aucune intervention de l'utilisateur
  (voir `services/api.js::tenterResolutionAutomatique`). Si cette
  résolution échoue, ou pour tout autre conflit métier (400/409/422/423),
  l'action est déplacée vers l'écran **Conflits de synchronisation**
  (`screens/SyncConflictsScreen.js`, accessible depuis le bandeau
  hors-ligne) où l'utilisateur choisit de la **réessayer** ou de
  l'**ignorer**. Les erreurs réseau/serveur (5xx, absence de connexion)
  restent en revanche en file pour une nouvelle tentative automatique —
  seul un rejet métier confirmé déclenche cet arbitrage.

### 3. Vue calendrier native (react-native-calendars)

L'emploi du temps est structuré par jour de semaine récurrent (Lundi,
Mardi...), alors que `react-native-calendars` attend des dates
calendaires réelles. `utils/weekDates.js` projette chaque créneau sur la
période affichée pour peupler les composants `Agenda`/`Calendar`
(navigation par balayage, points de repère sur les jours ayant cours).

Trois affichages, accessibles par un bouton de bascule en haut de
l'écran :
- **Agenda** : liste verticale jour par jour (vue par défaut).
- **Semaine** : grille compacte horizontale (`components/WeekGridView.js`,
  jours en colonnes, heures en lignes) pour une vision d'ensemble de la
  semaine sur un seul écran, sans défilement.
- **Mois** : calendrier mensuel (`components/MonthCalendarView.js`) avec
  un point sur chaque jour ayant cours ; l'emploi du temps récurrent est
  projeté sur toutes les occurrences réelles du mois affiché
  (`utils/weekDates.js::seancesVersMois`), et le détail du jour
  sélectionné s'affiche sous le calendrier.

### 4. Badge sur l'icône de l'application

Le compteur affiché sur l'icône (nombre de changements non consultés)
est **piloté par le serveur** plutôt que par un comptage local : chaque
notification envoyée incrémente un compteur `badge_count` propre à
l'utilisateur en base (`backend/app/models.py`), transmis dans le champ
`badge` du payload Expo Push. C'est ce mécanisme standard iOS/Android qui
permet à l'icône d'afficher le bon nombre même si l'application était
fermée au moment de la notification — un comptage purement local en
AsyncStorage ne le pourrait pas. Le badge est remis à zéro
(`POST /notifications/reset-badge`) dès que l'utilisateur consulte
l'écran d'emploi du temps.

## Démarrage

```bash
cd mobile
npm install
# Ajustez API_BASE_URL dans config.js selon votre environnement
npx expo start
```

Scannez le QR code avec **Expo Go** (iOS/Android), ou lancez un
émulateur :

```bash
npx expo start --android
npx expo start --ios
```

## Comptes de test

`claire.dupont@lycee-demo.fr` / `Enseignant123!` (créé par
`python -m app.seed` côté backend, lié à une fiche enseignant).

## Vérification technique

Tous les fichiers ont été vérifiés syntaxiquement avec le compilateur
TypeScript en mode JavaScript/JSX (`tsc --noEmit --jsx react --allowJs`),
qui valide correctement la syntaxe JSX contrairement à un simple
`node --check`. **`npm install` n'a pas pu être exécuté** dans
l'environnement de rédaction (pas d'accès réseau) : testez le
comportement runtime dans votre environnement et signalez toute
anomalie.

## Tests automatisés

```bash
cd mobile
npm install
npm test
```

Les services `api.js`, `storage.js` et `notifications.js` — la logique
métier indépendante du rendu UI — sont couverts par des tests Jest
(préréglage `jest-expo`) :

- **`__tests__/storage.test.js`** : cache local (écriture/lecture/purge),
  file d'attente (ajout, retrait, contexte conservé), conflits de
  synchronisation.
- **`__tests__/api.test.js`** : rafraîchissement automatique du token
  (401 → refresh → rejeu), repli sur cache (`apiGetCached`), mise en file
  en cas d'échec réseau (`apiMutateOrQueue`), et surtout `traiterFileAttente`
  dans ses quatre cas : succès, conflit définitif, erreur transitoire, et
  **résolution automatique** (créneau équivalent retrouvé ou non).
- **`__tests__/notifications.test.js`** : refus sur simulateur, permission
  refusée/accordée, enregistrement du token, remise à zéro du badge,
  écoute des notifications reçues/tapées.

Les modules natifs (AsyncStorage, expo-notifications, expo-device,
NetInfo) sont mockés dans `jest.setup.js` — ces tests s'exécutent donc
en Node pur, sans simulateur ni appareil physique.

⚠️ Comme pour le reste du projet, ces tests n'ont pas pu être exécutés
dans l'environnement de rédaction (pas d'accès réseau pour `npm install`).
Lancez `npm test` dans votre environnement et signalez toute anomalie.

## Prochaines étapes suggérées

- Tests de rendu (React Native Testing Library) sur les écrans
  eux-mêmes (`ScheduleCalendarScreen`, `SyncConflictsScreen`), en
  complément des tests de logique métier déjà en place
- Résolution automatique étendue à d'autres types d'actions que les
  disponibilités (généralisation de `tenterResolutionAutomatique`)
- CI (GitHub Actions) exécutant `npm test` à chaque pull request, en
  miroir du `pytest` déjà prévu côté backend
