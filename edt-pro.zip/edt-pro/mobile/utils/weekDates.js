/**
 * L'emploi du temps est structuré par jour de semaine récurrent
 * (Lundi, Mardi, ...), pas par date calendaire. Pour l'afficher dans un
 * composant `react-native-calendars` (qui attend des clés de date
 * "YYYY-MM-DD"), on projette chaque créneau sur la semaine affichée.
 */
const JOURS_SEMAINE = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

function pad(n) {
  return String(n).padStart(2, "0");
}

export function dateVersCleISO(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** Retourne le lundi de la semaine contenant `date` (par défaut : aujourd'hui). */
export function lundiDeLaSemaine(date = new Date()) {
  const d = new Date(date);
  const jour = d.getDay(); // 0 = dimanche
  const decalage = jour === 0 ? -6 : 1 - jour;
  d.setDate(d.getDate() + decalage);
  d.setHours(0, 0, 0, 0);
  return d;
}

/**
 * Calcule la date réelle (semaine affichée) correspondant à un nom de
 * jour français ("Lundi", "Mardi", ...).
 */
export function dateDuJourDansLaSemaine(nomJour, lundiReference) {
  const indexCible = JOURS_SEMAINE.indexOf(nomJour); // 1=Lundi ... 6=Samedi, 0=Dimanche
  const decalageDepuisLundi = indexCible === 0 ? 6 : indexCible - 1;
  const d = new Date(lundiReference);
  d.setDate(d.getDate() + decalageDepuisLundi);
  return d;
}

/**
 * Transforme une liste de séances (avec creneau_id référençant jour +
 * heure) en objet `items` attendu par le composant Agenda de
 * react-native-calendars : { "2026-07-20": [ {...}, ... ], ... }
 */
export function seancesVersItemsAgenda(seances, creneauxParId, matieresParId, sallesParId, semaineReference = new Date()) {
  const lundi = lundiDeLaSemaine(semaineReference);
  const items = {};

  for (const seance of seances) {
    const creneau = creneauxParId[seance.creneau_id];
    if (!creneau) continue;
    const date = dateDuJourDansLaSemaine(creneau.jour, lundi);
    const cle = dateVersCleISO(date);

    if (!items[cle]) items[cle] = [];
    const matiere = matieresParId[seance.matiere_id];
    const salle = sallesParId[seance.salle_id];
    items[cle].push({
      id: seance.id,
      name: matiere ? matiere.libelle : "Cours",
      height: 70,
      heure: `${creneau.heure_debut} - ${creneau.heure_fin}`,
      salle: salle ? salle.libelle : "",
      couleur: matiere ? matiere.couleur : "#3B82F6",
      seance,
    });
  }

  // Trie chaque journée par heure de début
  Object.values(items).forEach(liste => liste.sort((a, b) => a.heure.localeCompare(b.heure)));
  return items;
}

/** Renseigne les points de repère (jours ayant au moins un cours) pour le calendrier. */
export function marquerJoursAvecCours(items) {
  const marked = {};
  Object.keys(items).forEach(cle => {
    if (items[cle].length > 0) {
      marked[cle] = { marked: true, dotColor: "#3B82F6" };
    }
  });
  return marked;
}

const JOURS_OUVRES = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

/**
 * Construit une grille compacte { heures: string[], jours: string[],
 * grille: { [heure]: { [jour]: item } } } pour un affichage type
 * "vue Semaine" horizontale (par opposition à l'Agenda, qui liste les
 * séances jour par jour verticalement). Ne conserve que les jours
 * effectivement utilisés par au moins une séance de la grille horaire
 * (`creneauxParId`), dans l'ordre Lundi → Samedi.
 */
export function seancesVersGrilleSemaine(seances, creneauxParId, matieresParId, sallesParId) {
  const heuresSet = new Set();
  const joursSet = new Set();
  const grille = {};

  for (const seance of seances) {
    const creneau = creneauxParId[seance.creneau_id];
    if (!creneau) continue;
    const heureCle = creneau.heure_debut;
    heuresSet.add(heureCle);
    joursSet.add(creneau.jour);

    if (!grille[heureCle]) grille[heureCle] = {};
    const matiere = matieresParId[seance.matiere_id];
    const salle = sallesParId[seance.salle_id];
    grille[heureCle][creneau.jour] = {
      id: seance.id,
      nom: matiere ? matiere.libelle : "Cours",
      salle: salle ? salle.libelle : "",
      couleur: matiere ? matiere.couleur : "#3B82F6",
      seance,
    };
  }

  const heures = Array.from(heuresSet).sort();
  const jours = JOURS_OUVRES.filter(j => joursSet.has(j));
  return { heures, jours, grille };
}

/** Retourne la liste des dates (Date) d'un mois calendaire donné. */
function joursDuMois(annee, moisIndex) {
  const dates = [];
  const d = new Date(annee, moisIndex, 1);
  while (d.getMonth() === moisIndex) {
    dates.push(new Date(d));
    d.setDate(d.getDate() + 1);
  }
  return dates;
}

/**
 * Projette l'emploi du temps récurrent (Lundi, Mardi...) sur toutes les
 * occurrences réelles du mois affiché, pour peupler une vue "Mois"
 * (`components/MonthCalendarView.js`, composant `Calendar` de
 * react-native-calendars) : chaque lundi du mois affiché un point si une
 * séance a lieu le lundi, etc. Retourne :
 * - `marked` : points de repère pour le composant Calendar
 * - `items` : { "2026-07-06": [ {...séances du jour...} ] } pour afficher
 *   le détail du jour sélectionné sous le calendrier.
 */
export function seancesVersMois(seances, creneauxParId, matieresParId, sallesParId, moisReference = new Date()) {
  const dates = joursDuMois(moisReference.getFullYear(), moisReference.getMonth());

  const seancesParJourSemaine = {};
  for (const seance of seances) {
    const creneau = creneauxParId[seance.creneau_id];
    if (!creneau) continue;
    if (!seancesParJourSemaine[creneau.jour]) seancesParJourSemaine[creneau.jour] = [];
    seancesParJourSemaine[creneau.jour].push({ seance, creneau });
  }

  const items = {};
  const marked = {};
  for (const date of dates) {
    const nomJour = JOURS_SEMAINE[date.getDay()];
    const liste = seancesParJourSemaine[nomJour];
    if (!liste || liste.length === 0) continue;

    const cle = dateVersCleISO(date);
    marked[cle] = { marked: true, dotColor: "#3B82F6" };
    items[cle] = liste
      .map(({ seance, creneau }) => {
        const matiere = matieresParId[seance.matiere_id];
        const salle = sallesParId[seance.salle_id];
        return {
          id: seance.id,
          name: matiere ? matiere.libelle : "Cours",
          heure: `${creneau.heure_debut} - ${creneau.heure_fin}`,
          salle: salle ? salle.libelle : "",
          couleur: matiere ? matiere.couleur : "#3B82F6",
          seance,
        };
      })
      .sort((a, b) => a.heure.localeCompare(b.heure));
  }

  return { items, marked };
}
