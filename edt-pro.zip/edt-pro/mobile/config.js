// Adresse du backend EDT-Pro. En développement avec l'émulateur Android,
// utilisez généralement http://10.0.2.2:8000 (127.0.0.1 de la machine hôte
// n'est pas accessible directement depuis l'émulateur). Sur un appareil
// physique, utilisez l'adresse IP locale de votre machine, ou l'URL
// publique de votre déploiement cloud en production.
export const API_BASE_URL = "http://localhost:8000";
