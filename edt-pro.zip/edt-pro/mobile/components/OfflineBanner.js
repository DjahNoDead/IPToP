import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";

/**
 * Bandeau discret affiché en haut de l'écran lorsque :
 * - les données affichées proviennent du cache local (pas de réseau) ;
 * - et/ou des actions locales sont en attente de synchronisation ;
 * - et/ou des conflits de synchronisation nécessitent un arbitrage
 *   manuel (voir screens/SyncConflictsScreen.js, ouvert via `onPressConflits`).
 */
export default function OfflineBanner({ horsLigne, misAJourLe, enAttente, conflits = 0, onPressConflits }) {
  const heureCache = misAJourLe
    ? new Date(misAJourLe).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })
    : null;

  return (
    <View style={styles.container}>
      {horsLigne && (
        <Text style={styles.texte}>
          📴 Mode hors-ligne{heureCache ? ` — données du ${heureCache}` : ""}
        </Text>
      )}
      {enAttente > 0 && (
        <Text style={styles.texte}>
          ⏳ {enAttente} action{enAttente > 1 ? "s" : ""} en attente de synchronisation
        </Text>
      )}
      {conflits > 0 && (
        <TouchableOpacity onPress={onPressConflits}>
          <Text style={styles.texteConflit}>
            ⚠️ {conflits} conflit{conflits > 1 ? "s" : ""} de synchronisation — toucher pour arbitrer
          </Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: "#fef9c3", paddingHorizontal: 16, paddingVertical: 6 },
  texte: { color: "#854d0e", fontSize: 12, fontWeight: "600" },
  texteConflit: { color: "#991b1b", fontSize: 12, fontWeight: "700", marginTop: 2, textDecorationLine: "underline" },
});
