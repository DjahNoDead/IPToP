import React from "react";
import { View, Text, ScrollView, StyleSheet, TouchableOpacity } from "react-native";

/**
 * Vue compacte de l'emploi du temps : grille horizontale jours × heures,
 * en alternative à l'Agenda (liste verticale jour par jour). Utile pour
 * une vision d'ensemble rapide de la semaine sur un seul écran.
 *
 * `donnees` = { heures, jours, grille } — voir
 * utils/weekDates.js::seancesVersGrilleSemaine.
 */
export default function WeekGridView({ donnees, onPressSeance }) {
  const { heures, jours, grille } = donnees;

  if (heures.length === 0 || jours.length === 0) {
    return (
      <View style={styles.vide}>
        <Text style={styles.videTexte}>Aucun cours planifié pour le moment.</Text>
      </View>
    );
  }

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
      <View>
        {/* En-tête des jours */}
        <View style={styles.ligne}>
          <View style={[styles.cellule, styles.celluleHoraire]}>
            <Text style={styles.enteteTexte}></Text>
          </View>
          {jours.map(jour => (
            <View key={jour} style={[styles.cellule, styles.entete]}>
              <Text style={styles.enteteTexte}>{jour.slice(0, 3)}</Text>
            </View>
          ))}
        </View>

        {/* Lignes horaires */}
        <ScrollView>
          {heures.map(heure => (
            <View key={heure} style={styles.ligne}>
              <View style={[styles.cellule, styles.celluleHoraire]}>
                <Text style={styles.heureTexte}>{heure}</Text>
              </View>
              {jours.map(jour => {
                const item = grille[heure]?.[jour];
                return (
                  <TouchableOpacity
                    key={jour}
                    style={styles.cellule}
                    disabled={!item}
                    onPress={() => item && onPressSeance && onPressSeance(item.seance)}
                  >
                    {item ? (
                      <View style={[styles.bloc, { backgroundColor: item.couleur }]}>
                        <Text style={styles.blocTitre} numberOfLines={2}>{item.nom}</Text>
                        {!!item.salle && <Text style={styles.blocSalle} numberOfLines={1}>{item.salle}</Text>}
                      </View>
                    ) : (
                      <Text style={styles.videCellule}>—</Text>
                    )}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </ScrollView>
      </View>
    </ScrollView>
  );
}

const LARGEUR_COLONNE = 92;
const LARGEUR_HORAIRE = 56;

const styles = StyleSheet.create({
  ligne: { flexDirection: "row" },
  cellule: {
    width: LARGEUR_COLONNE, minHeight: 64, borderWidth: 0.5, borderColor: "#e2e8f0",
    padding: 4, justifyContent: "center", alignItems: "center",
  },
  celluleHoraire: { width: LARGEUR_HORAIRE, backgroundColor: "#f8fafc" },
  entete: { backgroundColor: "#f1f5f9", minHeight: 32 },
  enteteTexte: { fontWeight: "700", color: "#1e293b", fontSize: 12 },
  heureTexte: { fontSize: 11, color: "#64748b", fontWeight: "600" },
  bloc: { borderRadius: 6, padding: 6, width: "100%", height: "100%", justifyContent: "center" },
  blocTitre: { color: "#fff", fontWeight: "700", fontSize: 11 },
  blocSalle: { color: "#fff", fontSize: 10, marginTop: 2, opacity: 0.9 },
  videCellule: { color: "#cbd5e1" },
  vide: { padding: 40, alignItems: "center" },
  videTexte: { color: "#64748b" },
});
