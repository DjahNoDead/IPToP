import React, { useState } from "react";
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from "react-native";
import { Calendar } from "react-native-calendars";
import { dateVersCleISO } from "../utils/weekDates";

/**
 * Vue Mois compacte : un calendrier mensuel (composant `Calendar` de
 * react-native-calendars) avec un point sur chaque jour comportant au
 * moins une séance, et le détail du jour sélectionné affiché juste
 * en-dessous (par défaut : aujourd'hui).
 *
 * `donneesMois` = { items, marked } — voir
 * utils/weekDates.js::seancesVersMois. `onChangeMois` est appelé quand
 * l'utilisateur navigue vers un autre mois (l'écran parent recalcule
 * alors `donneesMois` pour le nouveau mois affiché, l'emploi du temps
 * étant récurrent et non attaché à des dates fixes en base).
 */
export default function MonthCalendarView({ donneesMois, onChangeMois, onPressSeance }) {
  const [dateSelectionnee, setDateSelectionnee] = useState(dateVersCleISO(new Date()));
  const items = donneesMois.items[dateSelectionnee] || [];

  const markedDates = {
    ...donneesMois.marked,
    [dateSelectionnee]: {
      ...(donneesMois.marked[dateSelectionnee] || {}),
      selected: true,
      selectedColor: "#3B82F6",
    },
  };

  return (
    <View style={styles.container}>
      <Calendar
        current={dateSelectionnee}
        markedDates={markedDates}
        onDayPress={(jour) => setDateSelectionnee(jour.dateString)}
        onMonthChange={(mois) => onChangeMois && onChangeMois(new Date(mois.year, mois.month - 1, 1))}
        theme={{ todayTextColor: "#3B82F6", arrowColor: "#3B82F6", dotColor: "#3B82F6", selectedDayBackgroundColor: "#3B82F6" }}
      />

      <FlatList
        data={items}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.liste}
        renderItem={({ item }) => (
          <TouchableOpacity onPress={() => onPressSeance && onPressSeance(item.seance)}>
            <View style={[styles.card, { borderLeftColor: item.couleur }]}>
              <Text style={styles.cardTitle}>{item.name}</Text>
              <Text style={styles.cardSub}>{item.heure}</Text>
              {!!item.salle && <Text style={styles.cardSub}>📍 {item.salle}</Text>}
            </View>
          </TouchableOpacity>
        )}
        ListEmptyComponent={<Text style={styles.vide}>Aucun cours ce jour.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  liste: { padding: 16, paddingTop: 8 },
  card: { backgroundColor: "#f8fafc", borderLeftWidth: 4, borderRadius: 8, padding: 12, marginBottom: 10 },
  cardTitle: { fontWeight: "700", fontSize: 15, marginBottom: 4 },
  cardSub: { color: "#64748b", fontSize: 13 },
  vide: { textAlign: "center", color: "#64748b", marginTop: 24 },
});
