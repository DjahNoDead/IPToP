/**
 * Service de notifications push (Expo Notifications).
 *
 * - `enregistrerPourNotifications()` : demande la permission, récupère
 *   le token Expo Push de l'appareil, et l'enregistre côté backend
 *   (POST /notifications/register-token). À appeler après la connexion.
 * - `configurerGestionnaireNotifications()` : définit le comportement
 *   d'affichage des notifications reçues au premier plan. Le badge de
 *   l'icône est piloté par le champ `badge` du payload envoyé par le
 *   serveur (compteur par utilisateur, voir backend/app/notifications.py)
 *   — c'est ce qui permet à l'OS de mettre à jour le badge même lorsque
 *   l'application est fermée, sans logique locale à maintenir.
 * - `ecouterNotifications(onRecue, onTap)` : abonne l'app aux
 *   notifications reçues (app ouverte) et aux taps sur une notification
 *   (app en arrière-plan/fermée) — utile pour rafraîchir l'écran EDT
 *   automatiquement.
 * - `reinitialiserBadge()` : à appeler quand l'utilisateur consulte son
 *   emploi du temps (remet le compteur à 0 côté serveur et sur l'icône).
 */
import { Platform } from "react-native";
import * as Notifications from "expo-notifications";
import * as Device from "expo-device";
import Constants from "expo-constants";
import { apiFetch } from "./api";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true, // applique le nombre transmis dans le payload ("badge")
  }),
});

export function configurerGestionnaireNotifications() {
  if (Platform.OS === "android") {
    Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#3B82F6",
    });
  }
}

/**
 * Demande la permission et enregistre le token auprès du backend.
 * Retourne le token, ou null si refusé / indisponible (ex: simulateur).
 */
export async function enregistrerPourNotifications() {
  if (!Device.isDevice) {
    console.log("Notifications push indisponibles sur simulateur/émulateur.");
    return null;
  }

  const { status: statutExistant } = await Notifications.getPermissionsAsync();
  let statutFinal = statutExistant;
  if (statutExistant !== "granted") {
    const { status } = await Notifications.requestPermissionsAsync();
    statutFinal = status;
  }
  if (statutFinal !== "granted") {
    console.log("Permission de notification refusée par l'utilisateur.");
    return null;
  }

  const projectId = Constants?.expoConfig?.extra?.eas?.projectId;
  const tokenResponse = await Notifications.getExpoPushTokenAsync(
    projectId ? { projectId } : undefined
  );
  const token = tokenResponse.data;

  try {
    await apiFetch("/notifications/register-token", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token, plateforme: Platform.OS }),
    });
  } catch (e) {
    console.warn("Échec de l'enregistrement du token push côté serveur :", e.message);
  }

  return token;
}

export async function desenregistrerNotifications(token) {
  if (!token) return;
  try {
    await apiFetch(`/notifications/unregister-token?token=${encodeURIComponent(token)}`, {
      method: "DELETE",
    });
  } catch (e) {
    console.warn("Échec de la désinscription du token push :", e.message);
  }
}

/**
 * Remet à zéro le badge de l'icône : côté serveur (source de vérité,
 * pour que la prochaine notification reparte de 0) et immédiatement sur
 * l'appareil (retour visuel instantané, y compris hors-ligne).
 */
export async function reinitialiserBadge() {
  try {
    await Notifications.setBadgeCountAsync(0);
  } catch (e) {
    // API indisponible sur certaines plateformes/simulateurs — sans conséquence
  }
  try {
    await apiFetch("/notifications/reset-badge", { method: "POST" });
  } catch (e) {
    // Hors-ligne : le badge visuel est déjà à 0 ; le serveur sera
    // resynchronisé à la prochaine requête authentifiée réussie.
  }
}

/**
 * Abonne l'app aux événements de notification. Retourne une fonction de
 * désabonnement à appeler au démontage du composant racine.
 */
export function ecouterNotifications(onRecue, onTap) {
  const abonnementRecue = Notifications.addNotificationReceivedListener((notification) => {
    onRecue && onRecue(notification.request.content.data);
  });
  const abonnementTap = Notifications.addNotificationResponseReceivedListener((reponse) => {
    onTap && onTap(reponse.notification.request.content.data);
  });
  return () => {
    abonnementRecue.remove();
    abonnementTap.remove();
  };
}
