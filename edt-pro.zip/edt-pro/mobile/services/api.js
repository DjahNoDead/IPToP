/**
 * Client API centralisé pour l'app mobile.
 *
 * - `apiGetCached(path, cleCache)` : tente l'appel réseau ; en cas
 *   d'échec (pas de connexion, timeout, 5xx), retombe sur le cache
 *   local et signale `horsLigne: true` à l'appelant.
 * - `apiPostOrQueue(path, body)` : tente l'appel réseau ; en cas
 *   d'échec, met la requête en file d'attente locale pour rejeu
 *   automatique ultérieur (ex: déclaration de disponibilité en zone
 *   blanche).
 * - `traiterFileAttente()` : à appeler au retour de connectivité
 *   (écouté via NetInfo dans App.js) pour rejouer les actions en attente.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import { API_BASE_URL } from "../config";
import {
  mettreEnCache, lireCache,
  ajouterAFileAttente, obtenirFileAttente, retirerDeFileAttente,
  ajouterConflit, retirerConflit,
} from "./storage";

async function getAccessToken() {
  return AsyncStorage.getItem("access_token");
}

async function refreshAccessToken() {
  const refreshToken = await AsyncStorage.getItem("refresh_token");
  if (!refreshToken) return null;
  try {
    const res = await fetch(`${API_BASE_URL}/auth/refresh`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    await AsyncStorage.setItem("access_token", data.access_token);
    return data.access_token;
  } catch {
    return null;
  }
}

/** Requête authentifiée brute, avec rafraîchissement automatique du token. */
export async function apiFetch(path, options = {}) {
  let token = await getAccessToken();
  let res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: { ...(options.headers || {}), Authorization: `Bearer ${token}` },
  });
  if (res.status === 401) {
    token = await refreshAccessToken();
    if (!token) throw new Error("SESSION_EXPIREE");
    res = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers: { ...(options.headers || {}), Authorization: `Bearer ${token}` },
    });
  }
  return res;
}

/**
 * GET avec repli sur cache local. Retourne toujours
 * { data, horsLigne, misAJourLe }.
 */
export async function apiGetCached(path, cleCache) {
  try {
    const res = await apiFetch(path);
    if (!res.ok) throw new Error(`HTTP_${res.status}`);
    const data = await res.json();
    await mettreEnCache(cleCache, data);
    return { data, horsLigne: false, misAJourLe: new Date().toISOString() };
  } catch (e) {
    const cache = await lireCache(cleCache);
    if (cache) {
      return { data: cache.valeur, horsLigne: true, misAJourLe: cache.misAJourLe };
    }
    throw e; // ni réseau, ni cache disponible
  }
}

/**
 * POST/PUT/DELETE avec mise en file d'attente automatique en cas
 * d'échec réseau (mais pas en cas d'erreur métier 4xx/409, qui doit
 * être traitée immédiatement par l'appelant). `contexte` (optionnel) est
 * mémorisé avec l'action pour permettre une résolution automatique en
 * cas d'identifiant devenu invalide au moment du rejeu — voir
 * `tenterResolutionAutomatique` plus bas.
 */
export async function apiMutateOrQueue(method, path, body, contexte) {
  try {
    const res = await apiFetch(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (res.status >= 500 || res.status === 0) throw new Error("SERVEUR_INDISPONIBLE");
    return { envoyeImmediatement: true, response: res };
  } catch (e) {
    if (e.message === "SESSION_EXPIREE") throw e; // ne pas mettre en file une session expirée
    await ajouterAFileAttente({ method, path, body, contexte });
    return { envoyeImmediatement: false };
  }
}

/**
 * Codes de statut HTTP indiquant que l'action n'est plus valide côté
 * serveur (et ne le deviendra pas en réessayant telle quelle) : la
 * ressource visée a pu être supprimée, la règle métier a changé, etc.
 */
const CODES_CONFLIT_DEFINITIF = [400, 404, 409, 422, 423];

async function extraireMessageErreur(res) {
  try {
    const corps = await res.json();
    if (typeof corps.detail === "string") return corps.detail;
    if (corps.detail?.message) return corps.detail.message;
    return `Erreur ${res.status}`;
  } catch {
    return `Erreur ${res.status}`;
  }
}

/**
 * Tente une résolution automatique lorsqu'une action de type
 * "disponibilité" échoue parce que le créneau visé n'existe plus
 * (ex: la grille horaire a été régénérée entretemps avec de nouveaux
 * identifiants). `action.contexte` (capturé au moment de la mise en
 * file, voir DisponibilitesScreen) mémorise le jour et l'heure visés
 * indépendamment de l'identifiant technique — on recherche parmi les
 * créneaux actuels celui qui correspond toujours à ce jour/heure, et on
 * rejoue l'action avec son nouvel identifiant.
 *
 * Retourne `true` si la résolution automatique a réussi (action déjà
 * traitée, à ne pas remettre en file ni en conflit), `false` sinon.
 */
async function tenterResolutionAutomatique(action) {
  if (action.path !== "/disponibilites" || !action.contexte?.jour || !action.contexte?.heure_debut) {
    return false;
  }
  try {
    const creneauxRes = await apiFetch("/creneaux");
    if (!creneauxRes.ok) return false;
    const creneaux = await creneauxRes.json();

    const equivalent = creneaux.find(
      c => c.jour === action.contexte.jour && c.heure_debut === action.contexte.heure_debut
    );
    if (!equivalent || equivalent.id === action.body.creneau_id) return false;

    const nouveauCorps = { ...action.body, creneau_id: equivalent.id };
    const res = await apiFetch(action.path, {
      method: action.method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(nouveauCorps),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/**
 * Rejoue toutes les actions en attente (appelé au retour de
 * connectivité). Pour chaque action :
 * - succès (2xx) → retirée de la file ;
 * - conflit "identifiant devenu invalide" (404) → tentative de
 *   résolution automatique par correspondance jour/heure
 *   (`tenterResolutionAutomatique`) ; si elle réussit, l'action est
 *   considérée synchronisée sans intervention de l'utilisateur ;
 * - conflit définitif restant (4xx métier, voir CODES_CONFLIT_DEFINITIF)
 *   → retirée de la file ET déplacée vers les conflits de synchronisation
 *   pour arbitrage manuel (voir screens/SyncConflictsScreen.js) ;
 * - erreur transitoire (5xx, ou aucun réseau) → laissée en file, la
 *   boucle s'arrête pour retenter au prochain retour de connectivité.
 */
export async function traiterFileAttente(onProgress) {
  const file = await obtenirFileAttente();
  let succes = 0, conflits = 0, resolusAutomatiquement = 0;
  for (const action of file) {
    try {
      const res = await apiFetch(action.path, {
        method: action.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(action.body),
      });
      if (res.ok) {
        await retirerDeFileAttente(action.id);
        succes += 1;
      } else if (res.status === 404 && await tenterResolutionAutomatique(action)) {
        await retirerDeFileAttente(action.id);
        succes += 1;
        resolusAutomatiquement += 1;
      } else if (CODES_CONFLIT_DEFINITIF.includes(res.status)) {
        const messageErreur = await extraireMessageErreur(res);
        await retirerDeFileAttente(action.id);
        await ajouterConflit(action, messageErreur);
        conflits += 1;
      }
      // Autres codes (5xx) : action laissée telle quelle en file, on
      // continue avec la suivante mais on retentera celle-ci plus tard.
    } catch {
      break; // toujours pas de réseau : on arrête, on retentera plus tard
    }
    if (onProgress) onProgress({ succes, conflits, resolusAutomatiquement, total: file.length });
  }
  return { succes, conflits, resolusAutomatiquement };
}

/**
 * Remet un conflit résolu (ex: l'utilisateur a corrigé la donnée
 * ailleurs) dans la file active pour une nouvelle tentative.
 */
export async function reessayerConflit(conflit) {
  await retirerConflit(conflit.id);
  await ajouterAFileAttente({ method: conflit.method, path: conflit.path, body: conflit.body, contexte: conflit.contexte });
}

/** Écarte définitivement un conflit sans le rejouer. */
export async function ignorerConflit(conflitId) {
  await retirerConflit(conflitId);
}
