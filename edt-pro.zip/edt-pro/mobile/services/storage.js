/**
 * Service de cache local et de file d'attente hors-ligne.
 *
 * Principe :
 * - Chaque réponse API significative (emploi du temps, créneaux,
 *   référentiels) est mise en cache après un appel réussi.
 * - En cas d'échec réseau, l'écran affiche les dernières données
 *   connues (avec un indicateur "hors-ligne" et l'horodatage de mise
 *   à jour) plutôt qu'un écran d'erreur bloquant.
 * - Les actions de mutation effectuées hors-ligne (déclaration de
 *   disponibilité) sont mises en file et rejouées automatiquement au
 *   retour de la connexion (voir services/api.js::traiterFileAttente).
 */
import AsyncStorage from "@react-native-async-storage/async-storage";

const PREFIX_CACHE = "edt_cache:";
const CLE_FILE_ATTENTE = "edt_offline_queue";

export async function mettreEnCache(cle, valeur) {
  try {
    const enveloppe = { valeur, misAJourLe: new Date().toISOString() };
    await AsyncStorage.setItem(PREFIX_CACHE + cle, JSON.stringify(enveloppe));
  } catch (e) {
    console.warn("Échec de la mise en cache locale :", e);
  }
}

/** Retourne { valeur, misAJourLe } ou null si rien en cache. */
export async function lireCache(cle) {
  try {
    const brut = await AsyncStorage.getItem(PREFIX_CACHE + cle);
    return brut ? JSON.parse(brut) : null;
  } catch (e) {
    console.warn("Échec de la lecture du cache local :", e);
    return null;
  }
}

export async function viderCache(cle) {
  await AsyncStorage.removeItem(PREFIX_CACHE + cle);
}

// --------------------------- File d'attente hors-ligne ---------------------------
/**
 * Ajoute une action à rejouer plus tard (ex: déclaration de
 * disponibilité effectuée sans connexion). `action` décrit la requête à
 * refaire : { method, path, body, contexte? }. `contexte` (optionnel)
 * capture des informations indépendantes de l'identifiant technique visé
 * (ex: { jour: "Lundi", heure_debut: "08:00" } pour un créneau) afin de
 * permettre une résolution automatique si cet identifiant devient
 * invalide d'ici le rejeu (voir services/api.js::tenterResolutionAutomatique).
 */
export async function ajouterAFileAttente(action) {
  const file = await obtenirFileAttente();
  file.push({ ...action, id: `${Date.now()}_${Math.random().toString(36).slice(2)}`, ajouteLe: new Date().toISOString() });
  await AsyncStorage.setItem(CLE_FILE_ATTENTE, JSON.stringify(file));
  return file;
}

export async function obtenirFileAttente() {
  try {
    const brut = await AsyncStorage.getItem(CLE_FILE_ATTENTE);
    return brut ? JSON.parse(brut) : [];
  } catch (e) {
    return [];
  }
}

export async function retirerDeFileAttente(actionId) {
  const file = await obtenirFileAttente();
  const nouvelle = file.filter(a => a.id !== actionId);
  await AsyncStorage.setItem(CLE_FILE_ATTENTE, JSON.stringify(nouvelle));
  return nouvelle;
}

export async function viderFileAttente() {
  await AsyncStorage.removeItem(CLE_FILE_ATTENTE);
}

// --------------------------- Conflits de synchronisation ---------------------------
/**
 * Une action en file peut devenir invalide entre le moment où elle a
 * été effectuée hors-ligne et celui de sa tentative de rejeu (ex: le
 * créneau visé a été supprimé côté serveur entretemps). Un tel rejet
 * "métier" (4xx) ne se résoudra jamais par une simple nouvelle tentative
 * automatique : l'action est donc déplacée ici pour un arbitrage
 * explicite par l'utilisateur (réessayer après correction, ou ignorer).
 */
const CLE_CONFLITS = "edt_sync_conflicts";

export async function ajouterConflit(action, messageErreur) {
  const conflits = await obtenirConflits();
  conflits.push({ ...action, messageErreur, detecteLe: new Date().toISOString() });
  await AsyncStorage.setItem(CLE_CONFLITS, JSON.stringify(conflits));
  return conflits;
}

export async function obtenirConflits() {
  try {
    const brut = await AsyncStorage.getItem(CLE_CONFLITS);
    return brut ? JSON.parse(brut) : [];
  } catch (e) {
    return [];
  }
}

export async function retirerConflit(conflitId) {
  const conflits = await obtenirConflits();
  const nouvelle = conflits.filter(c => c.id !== conflitId);
  await AsyncStorage.setItem(CLE_CONFLITS, JSON.stringify(nouvelle));
  return nouvelle;
}
