import React, { useCallback, useState } from "react";
import { SafeAreaView, View, Text, FlatList, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { useFocusEffect } from "@react-navigation/native";
import { obtenirConflits } from "../services/storage";
import { reessayerConflit, ignorerConflit, traiterFileAttente } from "../services/api";

/**
 * Liste les actions effectuées hors-ligne que le serveur a définitivement
 * rejetées lors de leur rejeu automatique (ex: le créneau visé par une
 * déclaration de disponibilité a été supprimé entretemps). Pour chacune,
 * l'utilisateur choisit :
 * - **Réessayer** : la remet dans la file active pour une nouvelle
 *   tentative immédiate (utile si le problème a été corrigé côté serveur
 *   entretemps, ex: le créneau a été recréé) ;
 * - **Ignorer** : l'écarte définitivement sans la rejouer.
 */
export default function SyncConflictsScreen() {
  const [conflits, setConflits] = useState([]);

  const charger = useCallback(async () => {
    setConflits(await obtenirConflits());
  }, []);

  useFocusEffect(useCallback(() => { charger(); }, [charger]));

  const decrireAction = (conflit) => {
    if (conflit.path === "/disponibilites") {
      return `Déclaration de disponibilité (créneau #${conflit.body?.creneau_id})`;
    }
    return `${conflit.method} ${conflit.path}`;
  };

  const onReessayer = async (conflit) => {
    await reessayerConflit(conflit);
    const { succes } = await traiterFileAttente();
    if (succes > 0) {
      Alert.alert("Résolu", "L'action a bien été acceptée par le serveur cette fois.");
    } else {
      Alert.alert("Toujours refusé", "Le serveur a de nouveau rejeté cette action. Elle reste dans la liste des conflits.");
    }
    charger();
  };

  const onIgnorer = (conflit) => {
    Alert.alert(
      "Ignorer cette action ?",
      "Elle sera définitivement écartée et ne sera plus proposée.",
      [
        { text: "Annuler", style: "cancel" },
        { text: "Ignorer", style: "destructive", onPress: async () => { await ignorerConflit(conflit.id); charger(); } },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.hint}>
        Ces actions, effectuées hors-ligne, ont été refusées par le serveur
        lors de leur synchronisation automatique (donnée entretemps
        modifiée ou supprimée). Choisissez de les réessayer ou de les
        ignorer.
      </Text>
      <FlatList
        data={conflits}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={styles.cardTitle}>{decrireAction(item)}</Text>
            <Text style={styles.cardErreur}>⚠️ {item.messageErreur}</Text>
            <View style={styles.actions}>
              <TouchableOpacity style={styles.boutonReessayer} onPress={() => onReessayer(item)}>
                <Text style={styles.boutonTexteClair}>Réessayer</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.boutonIgnorer} onPress={() => onIgnorer(item)}>
                <Text style={styles.boutonTexteFonce}>Ignorer</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
        ListEmptyComponent={<Text style={styles.vide}>Aucun conflit de synchronisation en attente. 🎉</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f8fafc" },
  hint: { fontSize: 13, color: "#64748b", marginBottom: 16, lineHeight: 18 },
  card: { backgroundColor: "#fff", padding: 14, borderRadius: 8, marginBottom: 10, borderWidth: 1, borderColor: "#fee2e2" },
  cardTitle: { fontWeight: "700", marginBottom: 4, color: "#1e293b" },
  cardErreur: { color: "#991b1b", fontSize: 13, marginBottom: 10 },
  actions: { flexDirection: "row", gap: 8 },
  boutonReessayer: { backgroundColor: "#3B82F6", paddingVertical: 8, paddingHorizontal: 14, borderRadius: 6 },
  boutonIgnorer: { backgroundColor: "#f1f5f9", paddingVertical: 8, paddingHorizontal: 14, borderRadius: 6 },
  boutonTexteClair: { color: "#fff", fontWeight: "600", fontSize: 13 },
  boutonTexteFonce: { color: "#334155", fontWeight: "600", fontSize: 13 },
  vide: { textAlign: "center", color: "#64748b", marginTop: 40 },
});
