import React, { useEffect, useState, useCallback } from "react";
import { SafeAreaView, View, Text, FlatList, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from "react-native";
import { apiFetch, apiGetCached, apiMutateOrQueue } from "../services/api";
import OfflineBanner from "../components/OfflineBanner";

/**
 * Déclaration des disponibilités (créneaux indisponibles). Fonctionne
 * hors-ligne : la liste des créneaux provient du cache si le réseau est
 * indisponible, et chaque déclaration est mise en file d'attente locale
 * puis synchronisée automatiquement au retour de connexion (voir
 * services/api.js::traiterFileAttente, invoqué depuis
 * ScheduleCalendarScreen à la détection de reconnexion).
 */
export default function DisponibilitesScreen() {
  const [creneaux, setCreneaux] = useState([]);
  const [enseignantId, setEnseignantId] = useState(null);
  const [horsLigne, setHorsLigne] = useState(false);
  const [enAttenteIds, setEnAttenteIds] = useState(new Set());
  const [loading, setLoading] = useState(true);

  const charger = useCallback(async () => {
    setLoading(true);
    try {
      const me = await (await apiFetch("/auth/me")).json();
      setEnseignantId(me.enseignant_id);

      const res = await apiGetCached("/creneaux", "creneaux");
      setCreneaux(res.data);
      setHorsLigne(res.horsLigne);
    } catch (e) {
      Alert.alert("Erreur", "Impossible de charger les créneaux (ni réseau, ni cache disponible).");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { charger(); }, [charger]);

  const declarerIndisponible = async (creneau) => {
    if (!enseignantId) return;
    setEnAttenteIds(prev => new Set(prev).add(creneau.id));

    const { envoyeImmediatement } = await apiMutateOrQueue(
      "POST", "/disponibilites",
      { enseignant_id: enseignantId, creneau_id: creneau.id, type: "indisponible" },
      { jour: creneau.jour, heure_debut: creneau.heure_debut } // permet une résolution automatique si ce créneau est supprimé avant le rejeu
    );

    if (envoyeImmediatement) {
      Alert.alert("Enregistré", "Créneau marqué comme indisponible.");
    } else {
      Alert.alert(
        "Enregistré hors-ligne",
        "Pas de connexion actuellement : la déclaration sera envoyée automatiquement dès que le réseau reviendra."
      );
    }
  };

  if (loading) return <ActivityIndicator style={{ flex: 1 }} size="large" />;

  return (
    <SafeAreaView style={styles.container}>
      {horsLigne && <OfflineBanner horsLigne={horsLigne} misAJourLe={null} enAttente={0} />}
      <Text style={styles.title}>Mes disponibilités</Text>
      <Text style={styles.hint}>Touchez un créneau pour le marquer indisponible.</Text>
      <FlatList
        data={creneaux}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => declarerIndisponible(item)}>
            <Text style={styles.cardTitle}>{item.jour} {item.heure_debut} - {item.heure_fin}</Text>
            {enAttenteIds.has(item.id) && <Text style={styles.badge}>⏳ en attente de synchronisation</Text>}
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f8fafc" },
  title: { fontSize: 22, fontWeight: "700", color: "#1e293b" },
  hint: { fontSize: 13, color: "#64748b", marginBottom: 16, marginTop: 4 },
  card: { backgroundColor: "#fff", padding: 14, borderRadius: 8, marginBottom: 8, borderWidth: 1, borderColor: "#e2e8f0" },
  cardTitle: { fontWeight: "600" },
  badge: { color: "#854d0e", fontSize: 12, marginTop: 4 },
});
