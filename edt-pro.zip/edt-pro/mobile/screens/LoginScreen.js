import React, { useState } from "react";
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, ActivityIndicator, Alert, StyleSheet } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { API_BASE_URL } from "../config";
import { enregistrerPourNotifications } from "../services/notifications";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("claire.dupont@lycee-demo.fr");
  const [password, setPassword] = useState("Enseignant123!");
  const [loading, setLoading] = useState(false);

  const seConnecter = async () => {
    setLoading(true);
    try {
      const body = new URLSearchParams();
      body.append("username", email);
      body.append("password", password);
      const res = await fetch(`${API_BASE_URL}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body.toString(),
      });
      if (!res.ok) throw new Error("Email ou mot de passe incorrect");
      const data = await res.json();
      await AsyncStorage.setItem("access_token", data.access_token);
      await AsyncStorage.setItem("refresh_token", data.refresh_token);

      // Enregistrement du token de notification push (best-effort, ne bloque pas la connexion)
      enregistrerPourNotifications().catch(() => {});

      navigation.replace("EmploiDuTemps");
    } catch (e) {
      Alert.alert("Connexion impossible", e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>📅 EDT-Pro</Text>
      <TextInput style={styles.input} value={email} onChangeText={setEmail}
        placeholder="Email" autoCapitalize="none" keyboardType="email-address" />
      <TextInput style={styles.input} value={password} onChangeText={setPassword}
        placeholder="Mot de passe" secureTextEntry />
      <TouchableOpacity style={styles.button} onPress={seConnecter} disabled={loading}>
        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Se connecter</Text>}
      </TouchableOpacity>
      <Text style={styles.hint}>
        Compte de démonstration pré-rempli (enseignant). Fonctionne aussi
        hors-ligne après une première connexion réussie.
      </Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: "#f8fafc", justifyContent: "center" },
  title: { fontSize: 26, fontWeight: "700", marginBottom: 24, color: "#1e293b", textAlign: "center" },
  input: { borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 8, padding: 12, marginBottom: 12, backgroundColor: "#fff" },
  button: { backgroundColor: "#3B82F6", padding: 14, borderRadius: 8, alignItems: "center", marginTop: 8 },
  buttonText: { color: "#fff", fontWeight: "600" },
  hint: { fontSize: 12, color: "#64748b", marginTop: 20, textAlign: "center" },
});
