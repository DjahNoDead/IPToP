import React, { useEffect, useState, useCallback, useRef } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Alert } from "react-native";
import { Agenda } from "react-native-calendars";
import NetInfo from "@react-native-community/netinfo";
import { useFocusEffect } from "@react-navigation/native";
import { apiFetch, apiGetCached, traiterFileAttente } from "../services/api";
import {
  seancesVersItemsAgenda, marquerJoursAvecCours, dateVersCleISO,
  seancesVersGrilleSemaine, seancesVersMois,
} from "../utils/weekDates";
import { obtenirFileAttente, obtenirConflits } from "../services/storage";
import { reinitialiserBadge } from "../services/notifications";
import OfflineBanner from "../components/OfflineBanner";
import WeekGridView from "../components/WeekGridView";
import MonthCalendarView from "../components/MonthCalendarView";

export default function ScheduleCalendarScreen({ navigation }) {
  const [items, setItems] = useState({});
  const [markedDates, setMarkedDates] = useState({});
  const [grilleSemaine, setGrilleSemaine] = useState({ heures: [], jours: [], grille: {} });
  const [donneesMois, setDonneesMois] = useState({ items: {}, marked: {} });
  const [vue, setVue] = useState("agenda"); // "agenda" | "semaine" | "mois"
  const [horsLigne, setHorsLigne] = useState(false);
  const [misAJourLe, setMisAJourLe] = useState(null);
  const [enAttente, setEnAttente] = useState(0);
  const [nbConflits, setNbConflits] = useState(0);
  const [loading, setLoading] = useState(true);

  // Conservés en ref (et non en state) car lus par `charger`, qui doit
  // rester stable : un state capturé dans sa closure deviendrait périmé
  // après une reconnexion réseau si l'utilisateur avait entretemps
  // navigué vers un autre mois dans la vue Mois.
  const referentiels = useRef({ seances: [], creneauxParId: {}, matieresParId: {}, sallesParId: {} });
  const moisAfficheRef = useRef(new Date());

  const recalculerVueMois = useCallback((mois) => {
    const { seances, creneauxParId, matieresParId, sallesParId } = referentiels.current;
    setDonneesMois(seancesVersMois(seances, creneauxParId, matieresParId, sallesParId, mois));
  }, []);

  const charger = useCallback(async () => {
    setLoading(true);
    try {
      const me = await (await apiFetch("/auth/me")).json();
      if (!me.enseignant_id) {
        Alert.alert("Compte non lié", "Ce compte n'est pas rattaché à une fiche enseignant.");
        return;
      }

      const [seancesRes, creneauxRes, matieresRes, sallesRes] = await Promise.all([
        apiGetCached(`/schedules/enseignant/${me.enseignant_id}`, `seances_${me.enseignant_id}`),
        apiGetCached("/creneaux", "creneaux"),
        apiGetCached("/matieres", "matieres"),
        apiGetCached("/salles", "salles"),
      ]);

      const creneauxParId = Object.fromEntries(creneauxRes.data.map(c => [c.id, c]));
      const matieresParId = Object.fromEntries(matieresRes.data.map(m => [m.id, m]));
      const sallesParId = Object.fromEntries(sallesRes.data.map(s => [s.id, s]));
      referentiels.current = { seances: seancesRes.data, creneauxParId, matieresParId, sallesParId };

      const nouveauxItems = seancesVersItemsAgenda(seancesRes.data, creneauxParId, matieresParId, sallesParId);
      setItems(nouveauxItems);
      setMarkedDates(marquerJoursAvecCours(nouveauxItems));
      setGrilleSemaine(seancesVersGrilleSemaine(seancesRes.data, creneauxParId, matieresParId, sallesParId));
      recalculerVueMois(moisAfficheRef.current);
      setHorsLigne(seancesRes.horsLigne);
      setMisAJourLe(seancesRes.misAJourLe);
    } catch (e) {
      Alert.alert("Erreur", "Impossible de charger l'emploi du temps (ni réseau, ni cache disponible).");
    } finally {
      setLoading(false);
    }
  }, [recalculerVueMois]);

  const rafraichirIndicateurs = useCallback(async () => {
    const [file, conflits] = await Promise.all([obtenirFileAttente(), obtenirConflits()]);
    setEnAttente(file.length);
    setNbConflits(conflits.length);
  }, []);

  useEffect(() => {
    charger();
    rafraichirIndicateurs();

    // Synchronisation automatique dès que la connexion revient
    const unsubscribe = NetInfo.addEventListener(async (state) => {
      if (state.isConnected) {
        const { succes, conflits, resolusAutomatiquement } = await traiterFileAttente();
        if (succes > 0) {
          const detailAuto = resolusAutomatiquement > 0
            ? ` (dont ${resolusAutomatiquement} résolue(s) automatiquement en retrouvant le créneau équivalent)`
            : "";
          Alert.alert("Synchronisation", `${succes} action(s) en attente ont été synchronisées${detailAuto}.`);
        }
        if (conflits > 0) {
          Alert.alert(
            "Conflits de synchronisation",
            `${conflits} action(s) ont été refusées par le serveur et nécessitent votre arbitrage.`,
            [{ text: "Voir", onPress: () => navigation.navigate("SyncConflicts") }, { text: "Plus tard" }]
          );
        }
        rafraichirIndicateurs();
        charger();
      }
    });
    return () => unsubscribe();
  }, [charger, rafraichirIndicateurs, navigation]);

  // L'utilisateur consulte son EDT : on considère les changements "lus"
  // (remet le badge de l'icône à 0, côté serveur et sur l'appareil).
  useFocusEffect(useCallback(() => { reinitialiserBadge(); rafraichirIndicateurs(); }, [rafraichirIndicateurs]));

  const changerMoisAffiche = (nouveauMois) => {
    moisAfficheRef.current = nouveauMois;
    recalculerVueMois(nouveauMois);
  };

  const ouvrirDetailSeance = (seance) => {
    Alert.alert("Séance", `Créneau #${seance.creneau_id} — statut : ${seance.statut}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Mon emploi du temps</Text>
        <TouchableOpacity onPress={() => navigation.navigate("Disponibilites")}>
          <Text style={styles.lien}>Disponibilités</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.toggle}>
        {[
          { cle: "agenda", label: "Agenda" },
          { cle: "semaine", label: "Semaine" },
          { cle: "mois", label: "Mois" },
        ].map(({ cle, label }) => (
          <TouchableOpacity
            key={cle}
            style={[styles.toggleBouton, vue === cle && styles.toggleBoutonActif]}
            onPress={() => setVue(cle)}
          >
            <Text style={[styles.toggleTexte, vue === cle && styles.toggleTexteActif]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {(horsLigne || enAttente > 0 || nbConflits > 0) && (
        <OfflineBanner
          horsLigne={horsLigne}
          misAJourLe={misAJourLe}
          enAttente={enAttente}
          conflits={nbConflits}
          onPressConflits={() => navigation.navigate("SyncConflicts")}
        />
      )}

      {vue === "agenda" && (
        <Agenda
          items={items}
          markedDates={markedDates}
          selected={dateVersCleISO(new Date())}
          renderItem={(item) => (
            <TouchableOpacity onPress={() => ouvrirDetailSeance(item.seance)}>
              <View style={[styles.card, { borderLeftColor: item.couleur }]}>
                <Text style={styles.cardTitle}>{item.name}</Text>
                <Text style={styles.cardSub}>{item.heure}</Text>
                {!!item.salle && <Text style={styles.cardSub}>📍 {item.salle}</Text>}
              </View>
            </TouchableOpacity>
          )}
          renderEmptyData={() => (
            <View style={styles.card}><Text>Aucun cours ce jour.</Text></View>
          )}
          refreshing={loading}
          onRefresh={charger}
          theme={{ selectedDayBackgroundColor: "#3B82F6", todayTextColor: "#3B82F6", dotColor: "#3B82F6" }}
        />
      )}

      {vue === "semaine" && (
        <WeekGridView donnees={grilleSemaine} onPressSeance={ouvrirDetailSeance} />
      )}

      {vue === "mois" && (
        <MonthCalendarView
          donneesMois={donneesMois}
          onChangeMois={changerMoisAffiche}
          onPressSeance={ouvrirDetailSeance}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 16, paddingBottom: 8 },
  title: { fontSize: 20, fontWeight: "700", color: "#1e293b" },
  lien: { color: "#3B82F6", fontWeight: "600" },
  toggle: { flexDirection: "row", marginHorizontal: 16, marginBottom: 8, backgroundColor: "#f1f5f9", borderRadius: 8, padding: 3 },
  toggleBouton: { flex: 1, paddingVertical: 6, borderRadius: 6, alignItems: "center" },
  toggleBoutonActif: { backgroundColor: "#fff", shadowColor: "#000", shadowOpacity: 0.08, shadowRadius: 2, elevation: 1 },
  toggleTexte: { fontSize: 13, color: "#64748b", fontWeight: "600" },
  toggleTexteActif: { color: "#1e293b" },
  card: { backgroundColor: "#f8fafc", borderLeftWidth: 4, borderRadius: 8, padding: 12, marginRight: 10, marginTop: 12 },
  cardTitle: { fontWeight: "700", fontSize: 15, marginBottom: 4 },
  cardSub: { color: "#64748b", fontSize: 13 },
});
