"""
EDT-Pro Desktop — application bureau autonome.

Principe : la même API FastAPI et le même frontend web sont réutilisés
tels quels (aucune duplication de code métier), packagés dans une fenêtre
native légère via `pywebview`. L'API tourne en arrière-plan dans un
thread local ; les données sont stockées dans un fichier SQLite local
(`edt_pro_desktop.db`) pour un fonctionnement 100% hors-ligne.

Lancement (développement) :
    pip install -r requirements.txt
    python app.py

Packaging en exécutable autonome (Windows/macOS/Linux) :
    pip install pyinstaller
    pyinstaller --onefile --add-data "../frontend:frontend" --name EDT-Pro app.py

Ce choix (pywebview + Python) a été préféré à Electron/Tauri pour ce
MVP car il ne nécessite aucune toolchain supplémentaire (Node.js/Rust) :
le même environnement Python que le backend suffit. Pour une application
desktop plus riche (notifications natives, auto-update), une migration
vers Tauri reste recommandée en production — voir le cahier des charges,
section Déploiement.
"""
import os
import sys
import threading
import time

import uvicorn
import webview

# Permet d'importer le package `app` du backend (dossier voisin)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

# Base de données locale dédiée au mode desktop (isolée du serveur cloud)
os.environ.setdefault("DATABASE_URL", "sqlite:///./edt_pro_desktop.db")

FRONTEND_INDEX = os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html")
API_PORT = 8000


def _lancer_api():
    """Démarre le serveur API FastAPI dans un thread d'arrière-plan."""
    from app.main import app as fastapi_app  # import différé : nécessite DATABASE_URL déjà positionné
    uvicorn.run(fastapi_app, host="127.0.0.1", port=API_PORT, log_level="warning")


def main():
    api_thread = threading.Thread(target=_lancer_api, daemon=True)
    api_thread.start()
    time.sleep(1.5)  # laisse le serveur API démarrer avant d'ouvrir la fenêtre

    webview.create_window(
        "EDT-Pro — Gestion des emplois du temps",
        f"file://{os.path.abspath(FRONTEND_INDEX)}",
        width=1280,
        height=860,
        min_size=(1024, 700),
    )
    webview.start()


if __name__ == "__main__":
    main()
