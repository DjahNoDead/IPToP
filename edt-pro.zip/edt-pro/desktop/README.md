# EDT-Pro Desktop

Application bureau autonome (Windows / macOS / Linux), fonctionnant
100% hors-ligne grâce à une base SQLite locale.

## Démarrage

```bash
cd desktop
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
python -m app.seed --database sqlite:///./edt_pro_desktop.db   # optionnel : données de démo
python app.py
```

Une fenêtre native s'ouvre avec l'interface EDT-Pro complète (mêmes
fonctionnalités que la version web : génération, édition manuelle par
glisser-déposer, exports PDF/Excel).

## Packaging en exécutable autonome

```bash
pip install pyinstaller
pyinstaller --onefile --add-data "../frontend:frontend" --name EDT-Pro app.py
```

L'exécutable généré (`dist/EDT-Pro`) embarque l'API et l'interface ; il
peut être distribué sans installation Python préalable sur la machine
cible.

## Limites de ce MVP desktop

- Mode mono-utilisateur (pas de synchronisation multi-poste) : adapté à
  un usage local (ex. secrétariat sans connexion internet fiable).
- Pour une synchronisation avec le serveur central (mode hybride
  online/offline), prévoir une phase ultérieure de synchronisation
  différée (file d'événements à rejouer à la reconnexion).
