// Adresse de l'API EDT-Pro. En développement local, laissez la valeur
// par défaut. En production, remplacez par l'URL publique de votre API
// (ex: "https://api.mondomaine.fr") — voir DEPLOYMENT.md à la racine du
// projet pour le guide de déploiement complet sur VPS.
window.EDT_API_BASE_URL = "http://localhost:8000";
